'use strict';

const CACHE_KEY = 'watari_videos_v2';
const JOB_KEY = 'watari_hls_jobs_v1';
const MAX_PER_TAB = 90;
const MAX_AGE_MS = 2 * 60 * 60 * 1000;
const MAX_TABS = 25;
const videosByTab = new Map();
let saveTimer;

const ready = chrome.storage.session.get(CACHE_KEY).then((data) => {
  for (const [id, entries] of Object.entries(data[CACHE_KEY] || {})) {
    if (!Array.isArray(entries)) continue;
    const items = entries.filter(e => e?.url && Date.now() - e.seenAt < MAX_AGE_MS);
    if (items.length) videosByTab.set(Number(id), items);
  }
}).catch(() => {});

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
chrome.runtime.onInstalled.addListener(() => {
  void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

function isWebUrl(value) {
  try { return ['http:', 'https:'].includes(new URL(value).protocol); } catch { return false; }
}
function mediaType(url, mimeHeader = '') {
  if (!isWebUrl(url)) return null;
  const mime = String(mimeHeader).toLowerCase().split(';')[0].trim();
  if (/^(text\/html|application\/xhtml\+xml|application\/json|text\/plain)$/.test(mime)) return null;
  let path = new URL(url).pathname.toLowerCase();
  try { path = decodeURIComponent(path); } catch { /* 不正な%エンコードはそのまま */ }
  if (/\.(ts|m4s|cmfv|cmfa|aac|m4a|vtt|key|mp3)$/.test(path)) return null;
  if (/\.(m3u8|m3u)$/.test(path) || /^(application\/(vnd\.apple\.mpegurl|x-mpegurl)|audio\/mpegurl)$/.test(mime)) return 'hls';
  if (/\.mpd$/.test(path) || mime === 'application/dash+xml') return 'dash';
  if (/\.mp4$/.test(path) || mime === 'video/mp4') return 'mp4';
  if (/\.webm$/.test(path) || mime === 'video/webm') return 'webm';
  if (/\.mov$/.test(path) || mime === 'video/quicktime') return 'mov';
  if (/\.mkv$/.test(path) || mime === 'video/x-matroska') return 'mkv';
  return null;
}
function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const entries = [...videosByTab.entries()].slice(-MAX_TABS);
    void chrome.storage.session.set({ [CACHE_KEY]: Object.fromEntries(entries) }).catch(() => {});
  }, 350);
}
async function updateBadge(tabId) {
  const count = videosByTab.get(tabId)?.length || 0;
  try {
    await chrome.action.setBadgeText({ tabId, text: count ? String(Math.min(count, 99)) : '' });
    if (count) await chrome.action.setBadgeBackgroundColor({ tabId, color: '#444c61' });
  } catch { /* タブ終了済み */ }
}
async function record(tabId, item) {
  await ready;
  if (!Number.isInteger(tabId) || tabId < 0 || !item?.url) return;
  const type = mediaType(item.url, item.mime || '');
  if (!type) return;
  const now = Date.now();
  const entries = videosByTab.get(tabId) || [];
  let found = entries.find(e => e.url === item.url);
  if (!found) {
    found = { url: item.url, type, source: item.source || 'network', seenAt: now,
      playing: !!item.playing, width: item.width || 0, height: item.height || 0,
      thumbnail: '', label: '' };
    entries.unshift(found);
  } else {
    found.seenAt = now;
    found.playing ||= !!item.playing;
    if (item.width && item.height) { found.width = item.width; found.height = item.height; }
    if (item.source === 'page') found.source = 'page';
  }
  if (isWebUrl(item.thumbnail)) found.thumbnail = item.thumbnail;
  if (item.label) found.label = String(item.label).slice(0, 140);
  videosByTab.delete(tabId);
  videosByTab.set(tabId, entries.filter(e => now - e.seenAt < MAX_AGE_MS).slice(0, MAX_PER_TAB));
  scheduleSave();
  void updateBadge(tabId);
}
function removeDetected(tabId, url) {
  const items = videosByTab.get(tabId);
  if (!items) return;
  videosByTab.set(tabId, items.filter(item => item.url !== url));
  scheduleSave();
  void updateBadge(tabId);
}
chrome.webRequest.onBeforeRequest.addListener((d) => {
  if (d.tabId >= 0 && d.method === 'GET' && mediaType(d.url)) {
    void record(d.tabId, { url: d.url, source: 'network' });
  }
}, { urls: ['http://*/*', 'https://*/*'], types: ['media', 'xmlhttprequest', 'other'] });
chrome.webRequest.onHeadersReceived.addListener((d) => {
  if (d.tabId < 0 || d.method !== 'GET') return;
  const mime = (d.responseHeaders || []).find(h => h.name.toLowerCase() === 'content-type')?.value || '';
  if (d.statusCode >= 400 || /^(text\/html|application\/json|application\/xhtml\+xml)/i.test(mime)) {
    void ready.then(() => removeDetected(d.tabId, d.url));
    return;
  }
  if (mediaType(d.url, mime)) void record(d.tabId, { url: d.url, mime, source: 'network' });
}, { urls: ['http://*/*', 'https://*/*'], types: ['media', 'xmlhttprequest', 'other'] }, ['responseHeaders']);
chrome.tabs.onRemoved.addListener(tabId => { videosByTab.delete(tabId); scheduleSave(); });
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (change.status === 'loading' && change.url) {
    videosByTab.delete(tabId);
    scheduleSave();
    void updateBadge(tabId);
  }
});

const SETTINGS_KEY = 'watari_settings_v1';
const HISTORY_KEY = 'watari_download_history_v1';
const DEFAULT_FOLDER = 'VidDock';
let writeQueue = Promise.resolve();
function withLock(callback) {
  const task = writeQueue.then(callback, callback);
  writeQueue = task.catch(() => {});
  return task;
}
function normalizeFolder(raw) {
  if (typeof raw !== 'string') throw new Error('保存フォルダ名が不正です。');
  const folder = raw.trim().replace(/\\/g, '/');
  const parts = folder.split('/');
  if (!folder || folder.length > 150 || parts.some(p => !p || p === '.' || p === '..' || /[<>:"|?*\x00-\x1f]/.test(p) || /[. ]$/.test(p))) {
    throw new Error('Downloads内のフォルダ名を指定してください（例: VidDock/動画）。');
  }
  if (parts.some(p => /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?$/i.test(p)))
    throw new Error('Windowsで使えないフォルダ名が含まれています。');
  return parts.join('/');
}
async function getFolder() {
  const result = (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY];
  try { return normalizeFolder(result?.folder || DEFAULT_FOLDER); } catch { return DEFAULT_FOLDER; }
}
function identity(type, url) {
  const u = new URL(url); u.hash = '';
  if (/\.(mp4|mkv|mov|webm|m3u8|m3u)(?:$)/i.test(u.pathname)) u.search = '';
  else for (const name of ['token','expires','expire','signature','sig','auth','hdntl','hdnts']) u.searchParams.delete(name);
  return `${type}:${u.href}`;
}
async function historyGet() {
  const history = (await chrome.storage.local.get(HISTORY_KEY))[HISTORY_KEY];
  return history && typeof history === 'object' ? history : {};
}
async function putRecord(key, update) {
  return withLock(async () => {
    const history = await historyGet();
    history[key] = { ...(history[key] || {}), ...update, updatedAt: Date.now() };
    const keys = Object.keys(history).sort((a,b) => history[b].updatedAt - history[a].updatedAt);
    if (keys.length > 400) for (const k of keys.slice(400)) delete history[k];
    await chrome.storage.local.set({ [HISTORY_KEY]: history });
    return history[key];
  });
}
async function claim(key, data = {}) {
  return withLock(async () => {
    const history = await historyGet();
    const old = history[key];
    const expired = old && ((old.state === 'preparing' && Date.now() - old.updatedAt > 20 * 60 * 1000) ||
      (old.state === 'running' && Date.now() - old.updatedAt > 12 * 60 * 60 * 1000));
    if (old && !expired && ['preparing', 'running', 'done'].includes(old.state)) {
      return { ok: false, duplicate: true, state: old.state, record: old };
    }
    const newRecord = { ...data, state: 'preparing', percent: 0, updatedAt: Date.now() };
    history[key] = newRecord;
    await chrome.storage.local.set({ [HISTORY_KEY]: history });
    return { ok: true, record: newRecord };
  });
}
async function updateById(id, updates) {
  return withLock(async () => {
    const history = await historyGet();
    const key = Object.keys(history).find(k => history[k].downloadId === id);
    if (!key) return;
    history[key] = { ...history[key], ...updates, updatedAt: Date.now() };
    await chrome.storage.local.set({ [HISTORY_KEY]: history });
  });
}
chrome.downloads.onChanged.addListener(delta => {
  if (delta.state?.current === 'complete') void updateById(delta.id, { state: 'done', percent: 100, message: '保存しました' });
  if (delta.state?.current === 'interrupted') void updateById(delta.id, { state: 'failed', message: delta.error?.current || '保存に失敗しました' });
});
function safeName(raw) {
  return String(raw || 'video').replace(/[\\/:*?"<>|\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ')
    .replace(/[. ]+$/g, '').trim().slice(0, 100) || 'video';
}
function signatureType(bytes) {
  if (bytes.length >= 8) {
    const four = String.fromCharCode(...bytes.slice(4, 8));
    if (['ftyp', 'styp', 'moov', 'mdat'].includes(four)) return 'mp4';
  }
  if (bytes.length >= 4 && bytes[0] === 0x1a && bytes[1] === 0x45 && bytes[2] === 0xdf && bytes[3] === 0xa3) return 'webm';
  return null;
}
function looksLikeHtml(bytes) {
  const text = new TextDecoder().decode(bytes.slice(0, 350)).replace(/^\ufeff/, '').trimStart().toLowerCase();
  return /^(<!doctype\s+html|<html(?:\s|>)|<head(?:\s|>)|<body(?:\s|>)|<\?xml|\{\s*"(?:error|message|status)"\s*:)/.test(text);
}

// 動画拡張子でもログイン/エラーページを返す場合があるため、保存前に実体を少量検査する。
async function preflightVideo(url, type) {
  const ctl = new AbortController();
  const timeout = setTimeout(() => ctl.abort(), 16000);
  try {
    const response = await fetch(url, {
      method: 'GET', headers: { Range: 'bytes=0-1023' }, credentials: 'include',
      redirect: 'follow', cache: 'no-store', signal: ctl.signal
    });
    if (!response.ok) throw new Error(`サーバー応答: HTTP ${response.status}。URLが失効している可能性があります。`);
    const mime = (response.headers.get('content-type') || '').split(';')[0].toLowerCase().trim();
    if (mime === 'text/html' || mime === 'application/xhtml+xml' || mime === 'application/json') {
      throw new Error(`動画ではなく ${mime} が返りました。ログイン切れ・期限切れURL・サイトのアクセス制限を確認してください。`);
    }
    if (response.url && new URL(response.url).pathname.toLowerCase().endsWith('.html')) {
      throw new Error('動画URLがHTMLページへリダイレクトされました。');
    }
    if (!response.body) throw new Error('サーバーから動画データを確認できませんでした。');
    const reader = response.body.getReader();
    const { value } = await reader.read();
    void reader.cancel().catch(() => {});
    const bytes = (value || new Uint8Array()).slice(0, 1024);
    if (!bytes.length) throw new Error('動画データが空です。');
    if (looksLikeHtml(bytes)) throw new Error('動画ではなくHTML/エラーページが返りました。保存を中止しました。');
    const detected = signatureType(bytes);
    if (detected && ((detected === 'webm' && type !== 'webm' && type !== 'mkv') || (detected === 'mp4' && type === 'webm'))) {
      throw new Error('URLの拡張子と実際の動画形式が一致しません。');
    }
    if (!detected && !mime.startsWith('video/') && mime !== 'application/octet-stream' && mime !== 'binary/octet-stream') {
      throw new Error(`動画形式を確認できません（Content-Type: ${mime || '不明'}）。`);
    }
    return { mime, signature: detected };
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('検査がタイムアウトしました。サイトの通信制限を確認してください。');
    throw error;
  } finally { clearTimeout(timeout); }
}
const HELPER_API_ROOT = 'http://127.0.0.1:18763';
const HELPER_TIMEOUT_MS = 14000;
function isAllowedHelperPath(path, method) {
  if (method === 'GET' && (path === '/api/status' || path === '/api/settings' || path === '/api/update/check' || path === '/api/update/status' || /^\/api\/job\/[0-9a-f]{32}$/.test(path))) return true;
  if (method === 'POST' && (path === '/api/download' || path === '/api/settings' || path === '/api/update/apply')) return true;
  return false;
}
let nativeConnection = null;
async function nativeConnect() {
  if (!nativeConnection) nativeConnection = (async () => {
    try {
      const result = await chrome.runtime.sendNativeMessage('com.watari.video_helper', {action:'connect'});
      if (!result?.ok || !/^[a-f0-9]{48}$/i.test(result.token||'')) throw Error(result?.error||'自動接続に失敗しました。');
      await chrome.storage.local.set({helperToken:result.token});
      return result.token;
    } catch (e) {
      nativeConnection = null;
      throw Error('自動接続を確認できません。VidDockSetup.cmdを実行し、専用フォルダから拡張機能を読み込んでください。詳細: '+e.message);
    }
  })();
  return nativeConnection;
}
async function helperRequest(message, sender) {
  // Content scripts in web pages must not access the pairing key or helper API.
  if (sender?.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL('sidepanel.html')) {
    return { ok: false, error: '補助ツールの操作は拡張機能のサイドパネルからのみ可能です。' };
  }
  const method = message.method === 'POST' ? 'POST' : 'GET';
  const path = message.path;
  if (typeof path !== 'string' || !isAllowedHelperPath(path, method)) return { ok: false, error: '許可されていない補助ツールAPIです。' };
  if (method === 'POST' && (typeof message.data !== 'object' || !message.data || Array.isArray(message.data))) {
    return { ok: false, error: '送信内容が不正です。' };
  }
  let helperToken;
  try { helperToken = await nativeConnect(); }
  catch(e) { return {ok:false,error:e.message}; }
  const ctl = new AbortController();
  const timeout = setTimeout(() => ctl.abort(), path === '/api/update/check' ? 28000 : HELPER_TIMEOUT_MS);
  try {
    const response = await fetch(HELPER_API_ROOT + path, {
      method,
      headers: { 'X-Watari-Token': helperToken, ...(method === 'POST' ? { 'Content-Type': 'application/json' } : {}) },
      body: method === 'POST' ? JSON.stringify(message.data) : undefined,
      cache: 'no-store', signal: ctl.signal
    });
    let result;
    try { result = await response.json(); }
    catch { return { ok: false, error: 'ポート18763からJSON以外の応答が返りました。別のアプリまたは古い補助ツールが動作している可能性があります。' }; }
    if (response.status === 401) nativeConnection = null;
    if (response.status === 401) return { ok: false, error: '連携キーが一致しません。インストーラーに表示される48桁のキーを入力してください。' };
    if (response.status === 403) return { ok: false, error: `接続拒否（403 / ${result.code || 'UNKNOWN'}）：${result.error || '送信元または接続先の確認に失敗しました。'}` };
    if (!response.ok || !result?.ok) return { ok: false, error: result?.error || `補助ツールエラー: HTTP ${response.status}` };
    return { ok: true, value: result };
  } catch (error) {
    nativeConnection = null;
    if (error?.name === 'AbortError') return { ok: false, error: '補助ツールの応答がタイムアウトしました。補助ツールの起動状態を確認してください。' };
    return { ok: false, error: 'ローカル補助ツールに接続できません。自動起動設定かポート18763を確認してください。詳細: ' + (error?.message || String(error)) };
  } finally { clearTimeout(timeout); }
}

async function handleMessage(message, sender) {
  await ready;
  if (!message?.type) return { ok: false, error: '不正なリクエストです。' };
  if (message.type === 'HELPER_REQUEST') return helperRequest(message, sender);
  if (message.type === 'GET_MEDIA') return { ok: true, items: (videosByTab.get(message.tabId) || []).slice() };
  if (message.type === 'GET_SETTINGS') return { ok: true, folder: await getFolder() };
  if (message.type === 'SET_SETTINGS') {
    try { const folder = normalizeFolder(message.folder); await chrome.storage.local.set({ [SETTINGS_KEY]: { folder } }); return { ok: true, folder }; }
    catch (error) { return { ok: false, error: error.message }; }
  }
  if (message.type === 'GET_HISTORY') {
    const history = await historyGet();
    return { ok: true, entries: history };
  }
  if (message.type === 'CLEAR_HISTORY') {
    await chrome.storage.local.set({ [HISTORY_KEY]: {} });
    return { ok: true };
  }
  if (message.type === 'UPDATE_RECORD') {
    if (typeof message.key !== 'string' || message.key.length > 2500 || !/^hls:/.test(message.key)) return { ok: false, error: '保存IDが不正です' };
    const update = {};
    for (const k of ['state','message','percent','downloadId']) if (Object.prototype.hasOwnProperty.call(message,k)) update[k] = message[k];
    await putRecord(message.key, update);
    return { ok: true };
  }
  if (message.type === 'GET_IDENTITY') {
    try { return { ok: true, key: identity(message.mediaType || 'direct', message.url) }; }
    catch { return { ok: false, error: 'URLが不正です' }; }
  }

  if (message.type === 'ADD_PAGE_MEDIA') {
    const tabId = message.tabId;
    const tab = Number.isInteger(tabId) ? await chrome.tabs.get(tabId).catch(() => null) : null;
    if (!tab) return { ok: false, error: 'タブが見つかりません。' };
    await Promise.all((Array.isArray(message.records) ? message.records : []).slice(0, 90)
      .map(r => record(tabId, { ...r, source: 'page' })));
    return { ok: true };
  }
  if (message.type === 'DOWNLOAD_DIRECT') {
    const entry = (videosByTab.get(message.tabId) || []).find(e => e.url === message.url);
    if (!entry || !['mp4','webm','mov','mkv'].includes(entry.type)) {
      return { ok: false, error: '動画URLが見つかりません。再スキャンしてください。' };
    }
    const key = identity('direct', entry.url);
    const acquired = await claim(key, { title: safeName(message.title), url: entry.url });
    if (!acquired.ok) return { ok: true, duplicate: true, state: acquired.state, key };
    try {
      await preflightVideo(entry.url, entry.type);
      const filename = `${await getFolder()}/${safeName(message.title)}.${entry.type}`;
      const id = await chrome.downloads.download({ url: entry.url, filename, saveAs: false, conflictAction: 'uniquify' });
      await putRecord(key, { state: 'running', downloadId: id, filename, message: '保存中', percent: 0 });
      const details = await chrome.downloads.search({ id }).catch(() => []);
      if (details[0]?.state === 'complete') await putRecord(key, { state: 'done', percent: 100, message: '保存しました' });
      if (details[0]?.state === 'interrupted') await putRecord(key, { state: 'failed', message: details[0].error || '保存に失敗しました' });
      return { ok: true, downloadId: id, key };
    } catch (error) {
      await putRecord(key, { state: 'failed', message: error.message || String(error) });
      return { ok: false, error: error.message || String(error) };
    }
  }
  if (message.type === 'OPEN_HLS') return { ok: false, error: 'HLSはMP4変換が必要です。サイドパネルから補助ツールを使用してください。' };
  return { ok: false, error: '未知のリクエストです。' };
}
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  handleMessage(message, sender).then(reply, error => reply({ ok: false, error: error.message || String(error) }));
  return true;
});

if (typeof module !== 'undefined' && module.exports) module.exports = { mediaType, looksLikeHtml, signatureType, preflightVideo, normalizeFolder, identity };
