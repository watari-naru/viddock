'use strict';
const $ = id => document.getElementById(id);
const installedVersion = chrome.runtime.getManifest().version;
document.querySelector('.version-tag').textContent = 'v' + installedVersion;
const HELPER = 'http://127.0.0.1:18763';
const HELPER_HISTORY = 'watari_helper_jobs_v1';
const BROWSER_HISTORY = 'watari_download_history_v1';
const view = { tab:null, items:[], poster:'', drm:false, blob:false, token:'', folder:'VidDock',
  history:{}, helperHistory:{}, loading:false, helperReady:false, inflight:false, lastItemKey:'' };

function el(tag, cls='', content='') {
  const node = document.createElement(tag); node.className = cls; node.textContent = content; return node;
}
function button(text, cls, action) {
  const node=el('button',cls,text); node.type='button'; node.addEventListener('click',action); return node;
}
function notice(text, kind='') {
  const node=$('notice'); node.hidden=!text; node.textContent=text; node.className='notice'+(kind?' '+kind:'');
}
function host(u) { try { return new URL(u).hostname; } catch { return ''; } }
function source(u) { try { const v=new URL(u);return v.hostname+' '+v.pathname.slice(0,65); } catch {return u;} }
function thumbnail(url, title, tag) {
  const box=el('div','thumbnail'); const fallback=el('span','placeholder','▶'); box.append(fallback);
  if (url && /^https?:\/\//i.test(url)) {
    const img=document.createElement('img');img.alt=title;img.loading='lazy';img.referrerPolicy='no-referrer';
    img.onload=()=>{fallback.hidden=true;};img.onerror=()=>img.remove();img.src=url;box.append(img);
  }
  box.append(el('span','thumb-mark',tag));return box;
}
function youtubeId(url) {
  try {
    const u=new URL(url);
    const id=/(^|\.)(youtube\.com|youtube-nocookie\.com)$/.test(u.hostname) ?
      (u.pathname==='/watch' ? u.searchParams.get('v') : /^\/(shorts|embed|live)\//.test(u.pathname)?u.pathname.split('/')[2]:'') :
      ['youtu.be','www.youtu.be'].includes(u.hostname) ? u.pathname.split('/')[1] : '';
    return /^[A-Za-z0-9_-]{11}$/.test(id||'')?id:null;
  } catch {return null;}
}
function isTokyo(url) { try { const u=new URL(url);return /^(www\.)?tokyomotion\.net$/.test(u.hostname)&&/^\/video\/\d+\//.test(u.pathname); } catch {return false;} }
function browserKey(type,url) {
  try {const u=new URL(url);u.hash='';if(/\.(mp4|mkv|mov|webm|m3u8|m3u)$/i.test(u.pathname))u.search='';
    else ['token','expires','expire','signature','sig','auth','hdntl','hdnts'].forEach(k=>u.searchParams.delete(k));
    return type+':'+u.href;
  } catch{return type+':'+url;}
}
function stale(info) {
  return info && ((info.state==='preparing' && Date.now()-(info.updatedAt||0)>20*60*1000) ||
    (info.state==='running' && Date.now()-(info.updatedAt||0)>12*60*60*1000));
}
function stateName(info) {
  if (!info)return '';
  if(stale(info))return '前の処理が中断されました（再試行可能）';
  if (info.state==='done')return '✓ 保存済み';
  if (info.state==='preparing')return '準備中...';
  if (['running','queued'].includes(info.state))return `保存中 ${Math.round(info.percent||0)}%`;
  return info.state==='failed'?'保存失敗':'';
}
function helperKey(site,url){return site+':'+url;}
function completedMp4(info){return info?.state==='done' && /\.mp4$/i.test(info.path||'');}
function canBlock(info){return info&&!stale(info)&&['running','queued','preparing'].includes(info.state) || completedMp4(info);}
function currentStatus(){
  const url=view.tab?.url||''; const id=youtubeId(url);
  if(id)return view.helperHistory[helperKey('youtube','https://www.youtube.com/watch?v='+id)]||null;
  if(isTokyo(url))return view.helperHistory[helperKey('tokyomotion',new URL(url).origin+new URL(url).pathname)]||null;
  const playing=view.items.find(v=>v.playing)||view.items[0];
  if(!playing)return null;
  return playing.type==='mp4'?view.history[browserKey('direct',playing.url)]:view.helperHistory[helperKey('media',playing.url)]||null;
}
function showStatus(){
  const list=[...Object.values(view.helperHistory),...Object.values(view.history)]
    .filter(x=>x && ['preparing','running','queued','done','failed'].includes(x.state))
    .sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
  const box=$('globalStatus');box.hidden=!list.length;
  if(list.length){const item=list[0];$('globalStatusText').textContent=`${stateName(item)} · ${item.title||'動画'}`;
    $('globalStatusSub').textContent=(item.message|| (item.state==='done'?'VidDock に保存しました':'ダウンロードの状態を確認しています')).slice(0,190);
    $('globalProgress').style.width=Math.max(0,Math.min(100,item.percent||0))+'%';
    box.className='overall-status'+(item.state==='done'?' is-done':item.state==='failed'?' is-failed':''); }
  const status=currentStatus();
  const best=$('bestDownload');
  if(canBlock(status)) {
    best.textContent=status.state==='done'?'✓ 保存済み（重複防止中）':`保存中 ${Math.round(status.percent||0)}%`;
    best.disabled=true;
  } else {best.textContent='↓ 最高画質で保存';best.disabled=view.inflight;}
}
async function fetchHistory(){
  const data=await chrome.storage.local.get([HELPER_HISTORY,BROWSER_HISTORY]);
  view.history=data[BROWSER_HISTORY]||{};view.helperHistory=data[HELPER_HISTORY]||{};showStatus();
}
async function send(type, data={}){
  const reply=await chrome.runtime.sendMessage({type,...data});
  if(!reply?.ok)throw Error(reply?.error||'処理に失敗しました。');return reply;
}
async function helper(path, method='GET', data){
  const result = await send('HELPER_REQUEST',{path,method,...(data?{data}:{})});
  return result.value;
}
async function saveHelperInfo(key,patch){
  const next={...(view.helperHistory[key]||{}),...patch,updatedAt:Date.now()};
  view.helperHistory[key]=next;
  await chrome.storage.local.set({[HELPER_HISTORY]:view.helperHistory});showStatus();
}
async function syncHelper(){
  // WVH 1.7 automatic connection; native host owns the pairing key.
  const result=await helper('/api/status');
  if(!/^1\.(?:[5-9]|[1-9][0-9])\.\d+$/.test(result.version||''))throw Error(`旧補助ツール（${result.version||'不明'}）です。VidDockSetup.cmdを実行してください。`);
  if(!result.ytdlp)throw Error('yt-dlpが見つかりません。コマンド py -3 -m pip install -U "yt-dlp[default]" を実行してください。');
  if(!result.ffmpeg)throw Error('FFmpegが見つかりません。VidDockSetup.cmdを再実行して必要なツールを修復してください。');
  const saved=await helper('/api/settings');
  view.folder=saved.folder; $('saveFolder').value=saved.folder;
  $('currentFolder').textContent='Downloads / '+saved.folder;
  await send('SET_SETTINGS',{folder:saved.folder});
  view.helperReady=true;
  $('helperStatus').textContent=`接続OK · v${result.version} · yt-dlp OK · FFmpeg OK`;
  $('helperStatus').className='helper-status connected';return true;
}
async function checkHelper(){
  view.helperReady=false;
  $('helperStatus').textContent='接続確認中...';
  try {return await syncHelper();}
  catch(e){view.helperReady=false;$('helperStatus').textContent=e.message;$('helperStatus').className='helper-status error';return false;}
}
async function runHelper(site,url,quality='best',mediaUrl=''){
  view.inflight=true;showStatus();
  try{
    if(!await checkHelper())throw Error($('helperStatus').textContent);
    const result=await helper('/api/download','POST',{site,url,quality,mediaUrl});
    const canonical=site==='youtube'?'https://www.youtube.com/watch?v='+youtubeId(url):
      site==='tokyomotion'?'https://www.tokyomotion.net'+new URL(url).pathname:mediaUrl;
    const key=helperKey(site,canonical);
    await saveHelperInfo(key,{jobId:result.jobId,title:view.tab?.title||'動画',url,state:result.state||'running',percent:0,
      message:result.duplicate?'同じ動画を検出しました。新規保存は開始しません。':'動画を取得しています...'});
    notice(result.duplicate?'同じ動画は二重に保存しません。':'保存中です。完了まで進捗を表示します。','success');
    void pollHelper(key);
  }catch(e){notice(e.message,'error');$('helperSettings').open=true;}
  finally{view.inflight=false;showStatus();}
}
const polling=new Set();
async function pollHelper(key){
  if(polling.has(key))return;polling.add(key);
  try{
    let failures=0;
    for(let n=0;n<720;n++){
      const jobId=view.helperHistory[key]?.jobId;if(!jobId)break;
      let result;try{result=await helper('/api/job/'+encodeURIComponent(jobId));failures=0;}
      catch(e){
        if(++failures<3){
          await saveHelperInfo(key,{message:'補助ツールへの再接続を確認中... ('+failures+'/2)'});
          await new Promise(r=>setTimeout(r,1800));
          continue;
        }
        await saveHelperInfo(key,{state:'failed',message:'補助ツールの状態を確認できませんでした。'+e.message});break;
      }
      await saveHelperInfo(key,{state:result.state,percent:result.percent||0,path:result.path||'',message:result.message||'',title:view.helperHistory[key]?.title||'動画'});
      if(result.state==='done'){notice('保存しました。'+(result.path?' '+result.path:''),'success');break;}
      if(result.state==='failed'){notice(result.message||'保存に失敗しました','error');break;}
      await new Promise(r=>setTimeout(r,1300));
    }
  }finally{polling.delete(key);}
}
async function runMedia(item){
  // TokyoMotion often rejects extension-origin range probes with HTTP 403.
  // Use the native helper with the original video-page Referer for all media
  // candidates, including MP4. This is not a DRM or permission bypass.
  if(isTokyo(view.tab?.url||'')){
    if(!['mp4','webm','hls','mov','mkv'].includes(item.type)){
      notice('未対応の動画形式です。','error');return;
    }
    return runHelper('tokyomotion',view.tab.url,'best',item.url);
  }
  if(item.type==='mp4')return runBrowser(item);
  if(!['hls','webm','mov','mkv'].includes(item.type)){notice('この動画形式は未対応です','error');return;}
  if(!view.tab?.url?.startsWith('https://')){notice('MP4変換にはHTTPSページが必要です。','error');return;}
  return runHelper('media',view.tab.url,'best',item.url);
}
async function runBrowser(item){
  view.inflight=true;showStatus();notice('ファイルの形式を確認しています...');
  try{
    const response=await send(item.type==='hls'?'OPEN_HLS':'DOWNLOAD_DIRECT',{
      tabId:view.tab.id,url:item.url,title:item.label||view.tab.title||'video',autoStart:true});
    notice(response.duplicate?(response.state==='done'?'この動画は保存済みです。':'同じ動画を保存中です。'):
      (item.type==='hls'?'HLSの保存処理を開始しました。進捗はここに表示します。':'保存中です。完了時に通知します。'), 'success');
    await fetchHistory();
  }catch(e){
    // A 403 from the extension's MP4 preflight is not proof of an expired URL.
    // Retry through the local non-DRM media helper with the original page URL.
    if(/HTTP 403/.test(e.message||'')&&view.tab?.url?.startsWith('https://')){
      notice('サイトが事前確認を拒否しました。補助ツールで再試行しています...');
      await runHelper('media',view.tab.url,'best',item.url);
    }else notice(e.message,'error');
  }
  finally{view.inflight=false;showStatus();}
}
function selectBest(items){
  const usable=items.filter(x=>['mp4','webm','hls','mov','mkv'].includes(x.type));
  return usable.sort((a,b)=>{
    const score=x=> (x.playing?100000000:0)+(x.height||0)*2000+(x.width||0)+
      (x.type==='hls'?200:x.type==='mp4'?150:x.type==='webm'?110:0);
    return score(b)-score(a);
  })[0]||null;
}
async function bestDownload(){
  if(!view.tab||view.inflight)return;
  if(youtubeId(view.tab.url))return runHelper('youtube','https://www.youtube.com/watch?v='+youtubeId(view.tab.url));
  if(isTokyo(view.tab.url)){
    const item=selectBest(view.items);return runHelper('tokyomotion',view.tab.url,'best',item?.url||'');
  }
  const item=selectBest(view.items);
  if(!item){notice('動画が見つかりません。再生後に再検出してください。','error');return;}
  await runMedia(item);
}
function renderCard(item,index){
  const key=browserKey(item.type==='hls'?'hls':'direct',item.url);
  const tokyo=isTokyo(view.tab?.url||'');
  const siteKey=tokyo?'https://www.tokyomotion.net'+new URL(view.tab.url).pathname:'';
  const info=tokyo?view.helperHistory[helperKey('tokyomotion',siteKey)]:
    item.type==='mp4'?view.history[key]:view.helperHistory[helperKey('media',item.url)];
  const card=el('article','media-card');
  card.append(thumbnail(item.thumbnail||view.poster,item.label||'動画',item.height?item.height+'p':item.type.toUpperCase()));
  const title=el('div','media-title');title.append(el('strong','',item.label||`動画候補 ${index+1}`));
  title.append(el('span','format '+(item.type==='hls'?'hls':''),item.type.toUpperCase()));card.append(title);
  card.append(el('div','source',source(item.url)));
  const tags=el('div','tags');if(item.playing)tags.append(el('span','playing','● 再生中'));
  if(item.height)tags.append(el('span','',item.height+'p'));if(info)tags.append(el('span','',stateName(info)));card.append(tags);
  const actions=el('div','card-actions');actions.append(el('small','',item.type==='dash'?'DASHは未対応':item.type==='hls'?'HLS · 自動で最高画質':'直接動画'));
  const saving=canBlock(info);
  const b=button(item.type==='dash'?'未対応':saving?stateName(info):'MP4で保存','primary',()=>void runMedia(item));
  b.disabled=item.type==='dash'||!!saving;actions.append(b);card.append(actions);return card;
}
function showSiteCard(site, url, qualityOptions){
  const container=$(site==='youtube'?'youtubeArea':'tokyoArea');container.replaceChildren();container.hidden=false;
  const card=el('article','youtube-card');const id=youtubeId(url);
  card.append(thumbnail(view.poster||(id?'https://i.ytimg.com/vi/'+id+'/hqdefault.jpg':''),view.tab.title,site==='youtube'?'YOUTUBE':'SITE'));
  card.append(el('div','youtube-heading',view.tab.title||'動画'));
  card.append(el('div','source',site==='youtube'?'YouTube · 非DRM':'TokyoMotion · 非DRMのストリーム'));
  const select=document.createElement('select');select.setAttribute('aria-label',site==='youtube'?'画質選択':'取得先');
  if(site==='youtube'){
    [['best','最高画質'],['1080','1080p以下'],['720','720p以下'],['480','480p以下'],['360','360p以下']].forEach(([v,label])=>{
      const o=document.createElement('option');o.value=v;o.textContent=label;select.append(o);
    });
  }else{
    const o=document.createElement('option');o.value='';o.textContent='ページから解析';select.append(o);
    qualityOptions.slice(0,25).forEach((it,i)=>{const opt=document.createElement('option');opt.value=it.url;
      opt.textContent=`${it.type.toUpperCase()} ${it.height||''}p · 候補 ${i+1}`;select.append(opt);});
    if(qualityOptions.length)select.selectedIndex=1;
  }
  const controls=el('div','youtube-controls');controls.append(select);card.append(controls);
  const actions=el('div','card-actions');actions.append(el('small','',site==='youtube'?'yt-dlp + FFmpeg':'候補の検出後に保存'));
  const key=helperKey(site,site==='youtube'?'https://www.youtube.com/watch?v='+id:'https://www.tokyomotion.net'+new URL(url).pathname);
  const info=view.helperHistory[key];const blocked=canBlock(info);
  const b=button(blocked?stateName(info):'この設定で保存','primary',()=>void runHelper(site,url,site==='youtube'?select.value:'best',site==='tokyomotion'?select.value:''));
  b.disabled=!!blocked;actions.append(b);card.append(actions);
  if(info){const state=el('div','yt-job');state.append(el('strong','',stateName(info)));
    const bar=el('div','bar');const fill=el('div','job-fill');fill.style.width=(info.percent||0)+'%';bar.append(fill);
    state.append(bar,el('div','job-detail',info.message||''));card.append(state);}
  if(site==='tokyomotion')card.append(el('div','helper-warning','動画を再生後に「再検出」してください。サイトの配信制限によっては保存できない場合があります。'));
  container.append(card);
}
function render(){
  const page=view.tab||{};const id=youtubeId(page.url||'');
  $('youtubeArea').hidden=!id;$('tokyoArea').hidden=!isTokyo(page.url||'');
  if(id)showSiteCard('youtube',page.url,[]);
  else if(isTokyo(page.url||''))showSiteCard('tokyomotion',page.url,view.items.filter(x=>['mp4','webm','hls','dash'].includes(x.type)));
  $('drmArea').hidden=!view.drm;
  $('itemCount').textContent=String(view.items.length);
  $('items').replaceChildren(...view.items.map(renderCard));
  $('empty').hidden=!!view.items.length||!!id||isTokyo(page.url||'');
  $('summary').textContent=`${view.items.length}件の候補を検出${view.drm?' · DRM検出':''}`;
  showStatus();
}
async function scan(){
  if(view.loading)return;view.loading=true;$('rescan').disabled=true;
  try{
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(!tab?.id)throw Error('動画ページのタブを選択してください。');
    const changed=view.tab?.id!==tab.id||view.tab?.url!==tab.url;
    view.tab=tab;$('pageTitle').textContent=tab.title||'名称のないページ';$('pageDomain').textContent=host(tab.url||'');
    if(changed){view.poster='';view.drm=false;view.blob=false;notice('');}
    try{
      const response=await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},func:scanPageVideos});
      const data=response.map(x=>x.result).filter(Boolean);
      view.drm=data.some(x=>x.hasDRM);view.blob=data.some(x=>x.hasBlobVideo);
      view.poster=data.find(x=>x.pagePoster)?.pagePoster||'';
      const records=data.flatMap(x=>x.records||[]);
      if(records.length)await send('ADD_PAGE_MEDIA',{tabId:tab.id,records});
    }catch{/* protected page */}
    const {items}=await send('GET_MEDIA',{tabId:tab.id});
    view.items=items.sort((a,b)=>Number(b.playing)-Number(a.playing)||b.seenAt-a.seenAt);
    await fetchHistory();render();
  }catch(e){notice(e.message,'error');}
  finally{view.loading=false;$('rescan').disabled=false;}
}
async function saveSettings(){
  try{
    const {folder}=await send('SET_SETTINGS',{folder:$('saveFolder').value});
    view.folder=folder;$('saveFolder').value=folder;$('currentFolder').textContent='Downloads / '+folder;
    if(view.token){
      try{await syncHelper();}
      catch(e){notice('Chrome側の保存先は変更しました。補助ツール側は未反映です: '+e.message,'error');return;}
    }
    notice('保存先を変更しました：Downloads / '+folder,'success');
  }catch(e){notice(e.message,'error');}
}
async function pollBrowserProgress(){
  for(const [key, entry] of Object.entries(view.history)){
    if(entry.state!=='running'||!Number.isInteger(entry.downloadId))continue;
    try{
      const [item]=await chrome.downloads.search({id:entry.downloadId});
      if(item){
        if(item.totalBytes>0){
          const percent=Math.min(99,Math.round(item.bytesReceived/item.totalBytes*100));
          view.history[key]={...entry,percent};
          showStatus();
        }
      }
    }catch{/* Download entry may have been cleared */}
  }
}
$('rescan').addEventListener('click',()=>void scan());
$('bestDownload').addEventListener('click',()=>void bestDownload());
$('saveFolderButton').addEventListener('click',()=>void saveSettings());
$('saveToken').addEventListener('click',async()=>{
  view.token=$('helperToken').value.trim();await chrome.storage.local.set({helperToken:view.token});await checkHelper();
});
$('checkHelper').addEventListener('click',()=>void checkHelper());
chrome.tabs.onActivated.addListener(()=>void scan());
chrome.tabs.onUpdated.addListener((id,change)=>{if(id===view.tab?.id&&(change.status==='complete'||change.url))void scan();});
chrome.storage.onChanged.addListener((changes,area)=>{
  if(area==='local'&&changes[BROWSER_HISTORY]){
    const previous=view.history;
    view.history=changes[BROWSER_HISTORY].newValue||{};
    for(const [key,item] of Object.entries(view.history)) {
      if(previous[key]?.state!==item.state&&item.state==='done')notice('保存しました。'+(item.filename||''),'success');
      if(previous[key]?.state!==item.state&&item.state==='failed')notice(item.message||'保存に失敗しました','error');
    }
    render();
  }
});
(async()=>{
  const data=await chrome.storage.local.get(['helperToken']);
  view.token=data.helperToken||'';$('helperToken').value=view.token;
  const s=await send('GET_SETTINGS');view.folder=s.folder;$('saveFolder').value=s.folder;
  $('currentFolder').textContent='Downloads / '+s.folder;
  void checkHelper();
  await scan();
  for(const [key,value] of Object.entries(view.helperHistory))if(['running','queued'].includes(value.state)&&value.jobId)void pollHelper(key);
  setInterval(()=>void scan(),9000);
  setInterval(()=>void pollBrowserProgress(),1400);
})().catch(e=>notice(e.message,'error'));


// Private GitHub update workflow. All GitHub authentication stays on localhost helper.
let checkedUpdate = null;
let updatePolling = false;
function updateText(value, error = false) {
  const e = $('updateInfo'); e.textContent = value; e.className = 'help' + (error ? ' error' : '');
}
async function checkUpdates() {
  $('checkUpdates').disabled = true;
  $('applyUpdate').hidden = true;
  updateText('非公開GitHubから確認しています...');
  try {
    const data = await helper('/api/update/check');
    checkedUpdate = data;
    $('updateInstalled').textContent = `v${data.currentVersion}`;
    if (data.available) {
      updateText(`v${data.latestVersion} が利用できます。${data.notes || ''}`);
      $('applyUpdate').hidden = false;
    } else updateText('最新版です。');
  } catch (error) { updateText(error.message, true); }
  finally { $('checkUpdates').disabled = false; }
}
async function applyUpdate() {
  if (!checkedUpdate?.available || updatePolling) return;
  if (!confirm(`v${checkedUpdate.latestVersion}に更新します。保存中の動画がないことを確認してください。`)) return;
  $('applyUpdate').disabled = true; $('checkUpdates').disabled = true;
  $('updateProgress').hidden = false;
  updateText('アップデートを開始しています...');
  try {
    await helper('/api/update/apply', 'POST', {});
    updatePolling = true;
    for (let attempt=0; attempt<100; attempt++) {
      await new Promise(resolve => setTimeout(resolve, 1200));
      let state;
      try { state = await helper('/api/update/status'); }
      catch(e) { if(attempt<95) {updateText('補助ツールの再起動を待っています...');continue;} throw e; }
      if (state.state==='failed') throw new Error(state.message || '更新に失敗しました。');
      $('updateProgressBar').style.width = Math.max(0,Math.min(100,state.percent||0))+'%';
      updateText(state.message || '更新中...');
      if (state.state==='done' && state.version===checkedUpdate.latestVersion) {
        updateText('更新完了。Chrome拡張機能を再読み込みします。');
        setTimeout(()=>chrome.runtime.reload(), 900);
        return;
      }
    }
    throw new Error('更新状況の確認がタイムアウトしました。');
  } catch (error) { updateText(error.message, true); }
  finally {
    updatePolling = false; $('applyUpdate').disabled = false; $('checkUpdates').disabled = false;
  }
}
$('updateInstalled').textContent = 'v' + installedVersion;
$('checkUpdates').addEventListener('click',()=>void checkUpdates());
$('applyUpdate').addEventListener('click',()=>void applyUpdate());

// Automatic checks only; applying always requires user confirmation.
(async()=>{
  const previous=await chrome.storage.local.get('watariLastUpdateCheck');
  if(Date.now()-(previous.watariLastUpdateCheck||0)>6*60*60*1000){
    await chrome.storage.local.set({watariLastUpdateCheck:Date.now()});
    await checkUpdates();
  }
})().catch(()=>{});
