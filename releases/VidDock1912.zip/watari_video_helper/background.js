'use strict';

const CACHE_KEY = 'watari_videos_v2';
const JOB_KEY = 'watari_hls_jobs_v1';
const MAX_PER_TAB = 90;
const MAX_AGE_MS = 2 * 60 * 60 * 1000;
const MAX_TABS = 25;
const videosByTab = new Map();
// Only non-sensitive playback request headers; never capture Cookie or Authorization.
const playbackHeadersByTab = new Map();
const PLAYBACK_HEADER_ALLOWLIST = new Set(['referer','origin','user-agent','accept-language']);
function playbackHeaders(raw) {
  const result = {};
  for (const [name, value] of Object.entries(raw || {})) {
    const key = String(name).toLowerCase();
    if (!PLAYBACK_HEADER_ALLOWLIST.has(key) || typeof value !== 'string' ||
        value.length > 700 || /[\r\n\x00]/.test(value)) continue;
    if (['referer','origin'].includes(key)) {
      try {if (!['https:', 'http:'].includes(new URL(value).protocol)) continue;}
      catch {continue;}
    }
    result[key] = value;
  }
  return result;
}
function capturePlaybackHeaders(details) {
  if (details.tabId < 0 || details.method !== 'GET' || !mediaType(details.url)) return;
  const headers = playbackHeaders(Object.fromEntries((details.requestHeaders || [])
    .filter(h => h && typeof h.name === 'string')
    .map(h => [h.name, h.value])));
  if (!Object.keys(headers).length) return;
  let table = playbackHeadersByTab.get(details.tabId);
  if (!table) {table = new Map();playbackHeadersByTab.set(details.tabId, table);}
  table.set(details.url, {headers, recordedAt:Date.now()});
  const existing = videosByTab.get(details.tabId)?.find(v => v.url === details.url);
  if (existing) { existing.requestContext = { ...headers };scheduleSave(); }
  if (table.size > 120) table.delete(table.keys().next().value);
}

let saveTimer;

const ready = chrome.storage.session.get(CACHE_KEY).then((data) => {
  for (const [id, entries] of Object.entries(data[CACHE_KEY] || {})) {
    if (!Array.isArray(entries)) continue;
    const items = entries.filter(e => e?.url && Date.now() - e.seenAt < MAX_AGE_MS);
    if (items.length) videosByTab.set(Number(id), items);
  }
}).catch(() => {});

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
chrome.runtime.onInstalled.addListener(() => {
  void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

function isWebUrl(value) {
  try { return ['http:', 'https:'].includes(new URL(value).protocol); } catch { return false; }
}
function mediaType(url, mimeHeader = '') {
  if (!isWebUrl(url)) return null;
  const mime = String(mimeHeader).toLowerCase().split(';')[0].trim();
  if (/^(text\/html|application\/xhtml\+xml|application\/json|text\/plain)$/.test(mime)) return null;
  let path = new URL(url).pathname.toLowerCase();
  try { path = decodeURIComponent(path); } catch { /* 不正な%エンコードはそのまま */ }
  if (/\.(ts|m4s|cmfv|cmfa|aac|m4a|vtt|key|mp3)$/.test(path)) return null;
  if (/\.(m3u8|m3u)$/.test(path) || /^(application\/(vnd\.apple\.mpegurl|x-mpegurl)|audio\/mpegurl)$/.test(mime)) return 'hls';
  if (/\.mpd$/.test(path) || mime === 'application/dash+xml') return 'dash';
  if (/\.mp4$/.test(path) || mime === 'video/mp4') return 'mp4';
  if (/\.webm$/.test(path) || mime === 'video/webm') return 'webm';
  if (/\.mov$/.test(path) || mime === 'video/quicktime') return 'mov';
  if (/\.mkv$/.test(path) || mime === 'video/x-matroska') return 'mkv';
  return null;
}
function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const entries = [...videosByTab.entries()].slice(-MAX_TABS);
    void chrome.storage.session.set({ [CACHE_KEY]: Object.fromEntries(entries) }).catch(() => {});
  }, 350);
}
async function updateBadge(tabId) {
  const count = videosByTab.get(tabId)?.length || 0;
  try {
    await chrome.action.setBadgeText({ tabId, text: count ? String(Math.min(count, 99)) : '' });
    if (count) await chrome.action.setBadgeBackgroundColor({ tabId, color: '#444c61' });
  } catch { /* タブ終了済み */ }
}
async function record(tabId, item) {
  await ready;
  if (!Number.isInteger(tabId) || tabId < 0 || !item?.url) return;
  const type = mediaType(item.url, item.mime || '');
  if (!type) return;
  const now = Date.now();
  const entries = videosByTab.get(tabId) || [];
  let found = entries.find(e => e.url === item.url);
  if (!found) {
    found = { url: item.url, type, source: item.source || 'network', seenAt: now,
      playing: !!item.playing, width: item.width || 0, height: item.height || 0,
      thumbnail: '', label: '' };
    entries.unshift(found);
  } else {
    found.seenAt = now;
    found.playing ||= !!item.playing;
    if (item.width && item.height) { found.width = item.width; found.height = item.height; }
    if (item.source === 'page') found.source = 'page';
  }
  if (isWebUrl(item.thumbnail)) found.thumbnail = item.thumbnail;
  if (item.label) found.label = String(item.label).slice(0, 140);
  const liveHeaders = playbackHeadersByTab.get(tabId)?.get(item.url);
  if (liveHeaders && Date.now() - liveHeaders.recordedAt < 60 * 60 * 1000) {
    found.requestContext = { ...liveHeaders.headers };
  }

  videosByTab.delete(tabId);
  videosByTab.set(tabId, entries.filter(e => now - e.seenAt < MAX_AGE_MS).slice(0, MAX_PER_TAB));
  scheduleSave();
  void updateBadge(tabId);
}
function removeDetected(tabId, url) {
  const items = videosByTab.get(tabId);
  if (!items) return;
  videosByTab.set(tabId, items.filter(item => item.url !== url));
  scheduleSave();
  void updateBadge(tabId);
}
chrome.webRequest.onBeforeSendHeaders.addListener(capturePlaybackHeaders,
  {urls:['http://*/*','https://*/*'], types:['media','xmlhttprequest','other']},
  ['requestHeaders','extraHeaders']);
chrome.webRequest.onBeforeRequest.addListener((d) => {
  if (d.tabId >= 0 && d.method === 'GET' && mediaType(d.url)) {
    void record(d.tabId, { url: d.url, source: 'network' });
  }
}, { urls: ['http://*/*', 'https://*/*'], types: ['media', 'xmlhttprequest', 'other'] });
chrome.webRequest.onHeadersReceived.addListener((d) => {
  if (d.tabId < 0 || d.method !== 'GET') return;
  const mime = (d.responseHeaders || []).find(h => h.name.toLowerCase() === 'content-type')?.value || '';
  if (d.statusCode >= 400 || /^(text\/html|application\/json|application\/xhtml\+xml)/i.test(mime)) {
    void ready.then(() => removeDetected(d.tabId, d.url));
    return;
  }
  if (mediaType(d.url, mime)) void record(d.tabId, { url: d.url, mime, source: 'network' });
}, { urls: ['http://*/*', 'https://*/*'], types: ['media', 'xmlhttprequest', 'other'] }, ['responseHeaders']);
chrome.tabs.onRemoved.addListener(tabId => {
  videosByTab.delete(tabId); playbackHeadersByTab.delete(tabId); scheduleSave();
});
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (change.status === 'loading') {
    videosByTab.delete(tabId);
    playbackHeadersByTab.delete(tabId);
    scheduleSave();
    void updateBadge(tabId);
  }
});

const SETTINGS_KEY = 'watari_settings_v1';
const HISTORY_KEY = 'watari_download_history_v1';
const DEFAULT_FOLDER = 'VidDock';
let writeQueue = Promise.resolve();
function withLock(callback) {
  const task = writeQueue.then(callback, callback);
  writeQueue = task.catch(() => {});
  return task;
}
function normalizeFolder(raw) {
  if (typeof raw !== 'string') throw new Error('保存フォルダ名が不正です。');
  const folder = raw.trim().replace(/\\/g, '/');
  const parts = folder.split('/');
  if (!folder || folder.length > 150 || parts.some(p => !p || p === '.' || p === '..' || /[<>:"|?*\x00-\x1f]/.test(p) || /[. ]$/.test(p))) {
    throw new Error('Downloads内のフォルダ名を指定してください（例: VidDock/動画）。');
  }
  if (parts.some(p => /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?$/i.test(p)))
    throw new Error('Windowsで使えないフォルダ名が含まれています。');
  return parts.join('/');
}
async function getFolder() {
  const result = (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY];
  try { return normalizeFolder(result?.folder || DEFAULT_FOLDER); } catch { return DEFAULT_FOLDER; }
}
function identity(type, url) {
  const u = new URL(url); u.hash = '';
  if (/\.(mp4|mkv|mov|webm|m3u8|m3u)(?:$)/i.test(u.pathname)) u.search = '';
  else for (const name of ['token','expires','expire','signature','sig','auth','hdntl','hdnts']) u.searchParams.delete(name);
  return `${type}:${u.href}`;
}
async function historyGet() {
  const history = (await chrome.storage.local.get(HISTORY_KEY))[HISTORY_KEY];
  return history && typeof history === 'object' ? history : {};
}
async function putRecord(key, update) {
  return withLock(async () => {
    const history = await historyGet();
    history[key] = { ...(history[key] || {}), ...update, updatedAt: Date.now() };
    const keys = Object.keys(history).sort((a,b) => history[b].updatedAt - history[a].updatedAt);
    if (keys.length > 400) for (const k of keys.slice(400)) delete history[k];
    await chrome.storage.local.set({ [HISTORY_KEY]: history });
    return history[key];
  });
}
async function claim(key, data = {}) {
  return withLock(async () => {
    const history = await historyGet();
    const old = history[key];
    const expired = old && ((old.state === 'preparing' && Date.now() - old.updatedAt > 20 * 60 * 1000) ||
      (old.state === 'running' && Date.now() - old.updatedAt > 12 * 60 * 60 * 1000));
    if (old && !expired && ['preparing', 'running', 'done'].includes(old.state)) {
      return { ok: false, duplicate: true, state: old.state, record: old };
    }
    const newRecord = { ...data, state: 'preparing', percent: 0, createdAt:Date.now(), updatedAt: Date.now() };
    history[key] = newRecord;
    await chrome.storage.local.set({ [HISTORY_KEY]: history });
    return { ok: true, record: newRecord };
  });
}
async function updateById(id, updates) {
  return withLock(async () => {
    const history = await historyGet();
    const key = Object.keys(history).find(k => history[k].downloadId === id);
    if (!key) return;
    history[key] = { ...history[key], ...updates, updatedAt: Date.now() };
    await chrome.storage.local.set({ [HISTORY_KEY]: history });
  });
}
chrome.downloads.onChanged.addListener(delta => {
  if (delta.state?.current === 'complete') void updateById(delta.id, { state: 'done', percent: 100, message: '保存しました' });
  if (delta.state?.current === 'interrupted') void updateById(delta.id, { state: 'failed', message: delta.error?.current || '保存に失敗しました' });
});
function safeName(raw) {
  return String(raw || 'video').replace(/[\\/:*?"<>|\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ')
    .replace(/[. ]+$/g, '').trim().slice(0, 100) || 'video';
}
function signatureType(bytes) {
  if (bytes.length >= 8) {
    const four = String.fromCharCode(...bytes.slice(4, 8));
    if (['ftyp', 'styp', 'moov', 'mdat'].includes(four)) return 'mp4';
  }
  if (bytes.length >= 4 && bytes[0] === 0x1a && bytes[1] === 0x45 && bytes[2] === 0xdf && bytes[3] === 0xa3) return 'webm';
  return null;
}
function looksLikeHtml(bytes) {
  const text = new TextDecoder().decode(bytes.slice(0, 350)).replace(/^\ufeff/, '').trimStart().toLowerCase();
  return /^(<!doctype\s+html|<html(?:\s|>)|<head(?:\s|>)|<body(?:\s|>)|<\?xml|\{\s*"(?:error|message|status)"\s*:)/.test(text);
}

// 動画拡張子でもログイン/エラーページを返す場合があるため、保存前に実体を少量検査する。
async function preflightVideo(url, type) {
  const ctl = new AbortController();
  const timeout = setTimeout(() => ctl.abort(), 16000);
  try {
    const response = await fetch(url, {
      method: 'GET', headers: { Range: 'bytes=0-1023' }, credentials: 'include',
      redirect: 'follow', cache: 'no-store', signal: ctl.signal
    });
    if (response.status === 403) throw new Error('動画配信元が拡張機能の事前確認を拒否しました（HTTP 403）。URLの期限切れとは限りません。動画を再生し直してから補助ツール経由で試してください。');
    if (!response.ok) throw new Error(`動画の事前確認に失敗しました（HTTP ${response.status}）。配信元のアクセス条件を確認してください。`);
    const mime = (response.headers.get('content-type') || '').split(';')[0].toLowerCase().trim();
    if (mime === 'text/html' || mime === 'application/xhtml+xml' || mime === 'application/json') {
      throw new Error(`動画ではなく ${mime} が返りました。ログイン切れ・期限切れURL・サイトのアクセス制限を確認してください。`);
    }
    if (response.url && new URL(response.url).pathname.toLowerCase().endsWith('.html')) {
      throw new Error('動画URLがHTMLページへリダイレクトされました。');
    }
    if (!response.body) throw new Error('サーバーから動画データを確認できませんでした。');
    const reader = response.body.getReader();
    const { value } = await reader.read();
    void reader.cancel().catch(() => {});
    const bytes = (value || new Uint8Array()).slice(0, 1024);
    if (!bytes.length) throw new Error('動画データが空です。');
    if (looksLikeHtml(bytes)) throw new Error('動画ではなくHTML/エラーページが返りました。保存を中止しました。');
    const detected = signatureType(bytes);
    if (detected && ((detected === 'webm' && type !== 'webm' && type !== 'mkv') || (detected === 'mp4' && type === 'webm'))) {
      throw new Error('URLの拡張子と実際の動画形式が一致しません。');
    }
    if (!detected && !mime.startsWith('video/') && mime !== 'application/octet-stream' && mime !== 'binary/octet-stream') {
      throw new Error(`動画形式を確認できません（Content-Type: ${mime || '不明'}）。`);
    }
    return { mime, signature: detected };
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('検査がタイムアウトしました。サイトの通信制限を確認してください。');
    throw error;
  } finally { clearTimeout(timeout); }
}
const HELPER_API_ROOT = 'http://127.0.0.1:18763';
const HELPER_TIMEOUT_MS = 14000;
function isAllowedHelperPath(path, method) {
  if (method === 'GET' && (path === '/api/status' || path === '/api/settings' || path === '/api/update/check' || path === '/api/update/status' || /^\/api\/job\/[0-9a-f]{32}$/.test(path))) return true;
  if (method === 'POST' && (path === '/api/download' || path === '/api/settings' || path === '/api/jobs/status' || path === '/api/update/apply')) return true;
  return false;
}
let nativeConnection = null;
async function nativeConnect() {
  if (!nativeConnection) nativeConnection = (async () => {
    try {
      const result = await chrome.runtime.sendNativeMessage('com.watari.video_helper', {action:'connect'});
      if (!result?.ok || !/^[a-f0-9]{48}$/i.test(result.token||'')) throw Error(result?.error||'自動接続に失敗しました。');
      await chrome.storage.local.set({helperToken:result.token});
      return result.token;
    } catch (e) {
      nativeConnection = null;
      throw Error('接続できません。VidDockSetup.exeで修復してください。');
    }
  })();
  return nativeConnection;
}
async function helperRequest(message, sender) {
  // Content scripts in web pages must not access the pairing key or helper API.
  if (sender?.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL('sidepanel.html')) {
    return { ok: false, error: '補助ツールの操作は拡張機能のサイドパネルからのみ可能です。' };
  }
  const method = message.method === 'POST' ? 'POST' : 'GET';
  const path = message.path;
  if (typeof path !== 'string' || !isAllowedHelperPath(path, method)) return { ok: false, error: '許可されていない補助ツールAPIです。' };
  if (method === 'POST' && (typeof message.data !== 'object' || !message.data || Array.isArray(message.data))) {
    return { ok: false, error: '送信内容が不正です。' };
  }
  // A disconnected supervisor can restart through Native Messaging. Retry a
  // read-only request once after re-establishing that trusted native channel.
  // POST is deliberately not retried: a lost response must not create 2 jobs.
  const attempts = method === 'GET' ? 2 : 1;
  for (let attempt = 0; attempt < attempts; attempt++) {
    let helperToken;
    try { helperToken = await nativeConnect(); }
    catch (e) { return {ok:false,error:e.message}; }
    const ctl = new AbortController();
    const timeout = setTimeout(() => ctl.abort(), path === '/api/update/check' ? 28000 : HELPER_TIMEOUT_MS);
    try {
      const response = await fetch(HELPER_API_ROOT + path, {
        method,
        headers: { 'X-Watari-Token': helperToken, ...(method === 'POST' ? { 'Content-Type': 'application/json' } : {}) },
        body: method === 'POST' ? JSON.stringify(message.data) : undefined,
        cache: 'no-store', signal: ctl.signal
      });
      let result;
      try { result = await response.json(); }
      catch {
        return { ok: false, error: 'ポート18763からJSON以外の応答が返りました。別のアプリや古い補助ツールが動作していないか確認してください。' };
      }
      if (response.status === 401) {
        nativeConnection = null;
        if (attempt + 1 < attempts) continue;
        return { ok: false, status: 401, error: '接続設定を確認できません。VidDockSetup.exeで修復してください。' };
      }
      if (response.status === 403) return { ok: false, error: `補助ツールの接続拒否（403 / ${result.code || 'UNKNOWN'}）：${result.error || '送信元または接続先を確認してください。'}` };
      if (!response.ok || !result?.ok) return { ok: false, status: response.status, code: result?.code, error: result?.error || `接続エラー: HTTP ${response.status}` };
      return { ok: true, value: result };
    } catch (error) {
      // Native bootstrap can restart the supervisor when its previous worker
      // died after an earlier successful native handshake.
      nativeConnection = null;
      if (attempt + 1 < attempts && error?.name !== 'AbortError') continue;
      if (error?.name === 'AbortError') return { ok: false, error: '応答を待っています。しばらくしてから再度お試しください。' };
      return { ok: false, error: '接続できません。続く場合はVidDockSetup.exeで修復してください。' };
    } finally { clearTimeout(timeout); }
  }
  return { ok:false,error:'補助ツールの再接続に失敗しました。' };
}

// Serialize helper records in the background, including across side panels.
const HELPER_HISTORY_KEY='watari_helper_jobs_v1';
const TERMINAL_JOB_STATES=new Set(['done','failed','interrupted']);
async function patchHelperHistory(message,sender){
  if(sender?.id!==chrome.runtime.id||sender.url!==chrome.runtime.getURL('sidepanel.html'))return {ok:false,error:'サイドパネルからのみ更新できます。'};
  const key=message.key,patch=message.patch;
  if(typeof key!=='string'||key.length>8192||!['youtube:','tokyomotion:','media:'].some(p=>key.startsWith(p))||!patch||typeof patch!=='object'||Array.isArray(patch))return {ok:false,error:'保存状態が不正です。'};
  const safe={};
  for(const field of ['jobId','state','phase','title','url','pageUrl','thumbnail','path','message','errorCode','errorDetails']){
    if(typeof patch[field]==='string')safe[field]=patch[field].slice(0,field==='url'||field==='pageUrl'||field==='thumbnail'?8192:field==='path'?2048:field==='errorDetails'?2400:field==='message'?600:300);
  }
  if(safe.jobId&&!/^[a-f0-9]{32}$/.test(safe.jobId))return {ok:false,error:'ジョブIDが不正です。'};
  if(safe.state&&!['preparing','queued','running','done','failed','interrupted'].includes(safe.state))delete safe.state;
  if(Number.isFinite(patch.percent))safe.percent=Math.max(0,Math.min(100,patch.percent));
  for(const field of ['speedBytes','etaSeconds','bytesReceived','totalBytes','queuePosition']){
    if(patch[field]===null)safe[field]=null;
    else if(Number.isFinite(patch[field])&&patch[field]>=0)safe[field]=Math.min(patch[field],Number.MAX_SAFE_INTEGER);
  }
  if(typeof patch.totalEstimated==='boolean')safe.totalEstimated=patch.totalEstimated;
  if(typeof patch.connectionLost==='boolean')safe.connectionLost=patch.connectionLost;
  return withLock(async()=>{
    const all=(await chrome.storage.local.get(HELPER_HISTORY_KEY))[HELPER_HISTORY_KEY]||{};
    const previous=all[key]||{};
    if(message.expectedJobId&&previous.jobId!==message.expectedJobId)return {ok:true,skipped:true,record:previous};
    const newJob=!!safe.jobId&&previous.jobId!==safe.jobId;
    if(!newJob&&TERMINAL_JOB_STATES.has(previous.state)&&['queued','running','preparing'].includes(safe.state))return {ok:true,skipped:true,record:previous};
    if(!newJob&&Object.keys(safe).every(k=>previous[k]===safe[k]))return {ok:true,record:previous,unchanged:true};
    const record={...(newJob?{}:previous),...safe,createdAt:newJob?Date.now():(previous.createdAt||previous.updatedAt||Date.now()),updatedAt:Date.now()};
    all[key]=record;
    const terminal=Object.keys(all).filter(k=>TERMINAL_JOB_STATES.has(all[k]?.state)).sort((a,b)=>(all[b].updatedAt||0)-(all[a].updatedAt||0));
    for(const expired of terminal.slice(400))delete all[expired];
    await chrome.storage.local.set({[HELPER_HISTORY_KEY]:all});
    return {ok:true,record};
  });
}
let browserRefresh=null;
function refreshBrowserTransfers(sender){
  if(sender?.id!==chrome.runtime.id||sender.url!==chrome.runtime.getURL('sidepanel.html'))return Promise.resolve({ok:false,error:'許可されていません。'});
  if(browserRefresh)return browserRefresh;
  browserRefresh=(async()=>{
    const history=await historyGet(),results=[];
    for(const [key,entry]of Object.entries(history)){
      if(!['running','preparing'].includes(entry.state)||!Number.isInteger(entry.downloadId))continue;
      try{
        const [item]=await chrome.downloads.search({id:entry.downloadId});if(!item)continue;
        const state=item.state==='complete'?'done':item.state==='interrupted'?'failed':'running';
        const percent=state==='done'?100:item.totalBytes>0?Math.min(99,100*item.bytesReceived/item.totalBytes):(entry.percent||0);
        results.push({key,id:entry.downloadId,patch:{state,percent,bytesReceived:item.bytesReceived,totalBytes:item.totalBytes,message:state==='done'?'保存しました':item.error||'保存中'}});
      }catch{/* A cleared Chrome entry is not proof of a failed transfer. */}
    }
    if(results.length)await withLock(async()=>{
      const current=await historyGet();let changed=false;
      for(const {key,id,patch}of results){
        const old=current[key];
        if(!old||old.downloadId!==id||!['running','preparing'].includes(old.state))continue;
        if(Object.keys(patch).some(k=>patch[k]!==old[k])){current[key]={...old,...patch,updatedAt:Date.now()};changed=true;}
      }
      if(changed)await chrome.storage.local.set({[HISTORY_KEY]:current});
    });
    return {ok:true};
  })().finally(()=>{browserRefresh=null;});
  return browserRefresh;
}

// Shared across all side panels: one snapshot request and one history write.
const PANEL_ACTIVE_STATES = new Set(['queued','running','preparing']);
const POLL_FIELDS = ['state','phase','percent','queuePosition','speedBytes','etaSeconds',
  'bytesReceived','totalBytes','totalEstimated','path','message','connectionLost'];
let helperBatchInFlight=null, helperBatchNext=0;
function trustedPanel(sender){
  return sender?.id===chrome.runtime.id && sender.url===chrome.runtime.getURL('sidepanel.html');
}
function pollHelperJobs(sender){
  if(!trustedPanel(sender))return Promise.resolve({ok:false,error:'許可されていません。'});
  if(helperBatchInFlight)return helperBatchInFlight;
  if(Date.now()<helperBatchNext)return Promise.resolve({ok:true,throttled:true});
  helperBatchNext=Date.now()+1250;
  helperBatchInFlight=(async()=>{
    const snapshot=(await chrome.storage.local.get(HELPER_HISTORY_KEY))[HELPER_HISTORY_KEY]||{};
    const tracked=Object.entries(snapshot).filter(([,v])=>v&&PANEL_ACTIVE_STATES.has(v.state)&&/^[a-f0-9]{32}$/.test(v.jobId||''));
    if(!tracked.length)return {ok:true,active:0};
    const ids=[...new Set(tracked.map(([,v])=>v.jobId))];
    const states={},missing=new Set();
    let failure=null;
    // Queue is currently capped at 203 including running jobs. Chunk defensively.
    for(let start=0;start<ids.length;start+=256){
      const reply=await helperRequest({path:'/api/jobs/status',method:'POST',data:{ids:ids.slice(start,start+256)}},sender);
      if(!reply.ok){failure=reply;break;}
      if(!reply.value?.jobs||!Array.isArray(reply.value.missing)){
        failure={ok:false,error:'補助ツールの一括進捗に対応していません。v1.9.6以降へ更新してください。'};break;
      }
      Object.assign(states,reply.value.jobs);
      for(const id of reply.value.missing)missing.add(id);
    }
    if(failure)helperBatchNext=Date.now()+7500;
    let changedCount=0;
    await withLock(async()=>{
      const all=(await chrome.storage.local.get(HELPER_HISTORY_KEY))[HELPER_HISTORY_KEY]||{};
      for(const [key,prior] of tracked){
        const current=all[key];
        if(!current||current.jobId!==prior.jobId||!PANEL_ACTIVE_STATES.has(current.state))continue;
        let patch;
        if(failure){patch={connectionLost:true};}
        else if(missing.has(prior.jobId)){
          patch={state:'interrupted',connectionLost:false,message:'補助ツールにジョブの記録がありません。保存先を確認して再試行してください。'};
        }else{
          const value=states[prior.jobId];
          if(!value||!['queued','running','done','failed','interrupted'].includes(value.state))continue;
          patch={state:value.state,phase:value.phase||'',percent:value.percent||0,
            queuePosition:value.queuePosition||0,speedBytes:value.speedBytes??null,
            etaSeconds:value.etaSeconds??null,bytesReceived:value.bytesReceived||0,
            totalBytes:value.totalBytes||0,totalEstimated:!!value.totalEstimated,
            path:value.path||'',message:value.message||'',errorCode:value.errorCode||'',errorDetails:value.errorDetails||'',connectionLost:false};
        }
        if(Object.keys(patch).some(field=>current[field]!==patch[field])){
          all[key]={...current,...patch,updatedAt:Date.now()};changedCount++;
        }
      }
      if(changedCount)await chrome.storage.local.set({[HELPER_HISTORY_KEY]:all});
    });
    return failure||{ok:true,active:ids.length,changed:changedCount};
  })().finally(()=>{helperBatchInFlight=null;});
  return helperBatchInFlight;
}
let settingsWriteTail=Promise.resolve();
function saveDownloadSettings(message,sender){
  if(!trustedPanel(sender))return Promise.resolve({ok:false,error:'許可されていません。'});
  const fields={};
  if(Object.hasOwn(message,'folder')){
    try{fields.folder=normalizeFolder(message.folder);}catch(e){return Promise.resolve({ok:false,error:e.message});}
  }
  if(Object.hasOwn(message,'fragmentConcurrency')){
    if(![1,2,4,8].includes(message.fragmentConcurrency))return Promise.resolve({ok:false,error:'分割取得数は1・2・4・8です。'});
    fields.fragmentConcurrency=message.fragmentConcurrency;
  }
  if(Object.hasOwn(message,'maxConcurrent')){
    if(!Number.isInteger(message.maxConcurrent)||message.maxConcurrent<1||message.maxConcurrent>12)return Promise.resolve({ok:false,error:'同時保存数は1〜12本です。'});
    fields.maxConcurrent=message.maxConcurrent;
  }
  if(!Object.keys(fields).length)return Promise.resolve({ok:false,error:'設定が指定されていません。'});
  const task=settingsWriteTail.then(async()=>{
    const result=await helperRequest({path:'/api/settings',method:'POST',data:fields},sender);
    if(!result.ok)return result;
    const saved=result.value;
    if(!Number.isInteger(saved.maxConcurrent)||saved.maxConcurrent<1||saved.maxConcurrent>12||
       (fields.maxConcurrent!==undefined&&saved.maxConcurrent!==fields.maxConcurrent))return {ok:false,error:'同時保存数を確認できません。補助ツールをv1.9.7以降へ更新してください。'};
    if(![1,2,4,8].includes(saved.fragmentConcurrency))return {ok:false,error:'補助ツールの速度設定を確認できません。'};
    await withLock(async()=>{
      const old=(await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY]||{};
      const next={...old,folder:saved.folder,fragmentConcurrency:saved.fragmentConcurrency,maxConcurrent:saved.maxConcurrent};
      if(JSON.stringify(old)!==JSON.stringify(next))await chrome.storage.local.set({[SETTINGS_KEY]:next});
    });
    return {ok:true,folder:saved.folder,fragmentConcurrency:saved.fragmentConcurrency,maxConcurrent:saved.maxConcurrent};
  });
  settingsWriteTail=task.catch(()=>{});
  return task;
}

let activeSaveCommands=0;
const SAVE_PREPARATION_PORT='viddock-save-preparation-v1';
const SAVE_PREPARATION_LEASE_MS=45000;
const savePreparations=new Map();
function hasSavePreparations(){
  for(const entry of savePreparations.values())if(entry.expiresAt<=Date.now())entry.release();
  return savePreparations.size>0;
}
chrome.runtime.onConnect?.addListener(port=>{
  if(port.name!==SAVE_PREPARATION_PORT)return;
  if(!trustedPanel(port.sender)){port.disconnect();return;}
  let closed=false,started=false,timer=null,entry=null;
  const release=()=>{
    if(closed)return;closed=true;clearTimeout(timer);
    if(entry)savePreparations.delete(entry.id);
    try{port.disconnect();}catch{}
  };
  const renew=()=>{
    clearTimeout(timer);
    if(entry)entry.expiresAt=Date.now()+SAVE_PREPARATION_LEASE_MS;
    timer=setTimeout(release,SAVE_PREPARATION_LEASE_MS);
  };
  const reply=value=>{try{port.postMessage(value);}catch{release();}};
  port.onDisconnect.addListener(release);
  port.onMessage.addListener(message=>{
    if(closed)return;
    if(entry&&entry.expiresAt<=Date.now()){release();return;}
    if(message?.type==='KEEPALIVE'&&entry){renew();return;}
    if(message?.type!=='BEGIN'||started)return;
    started=true;
    void(async()=>{
      const updates=globalThis.VidDockUpdates;
      if(updates)await updates.ready();
      if(closed)return;
      if(updates?.isBlocking()){
        reply({ok:false,error:'更新中です。完了してから保存してください。'});release();return;
      }
      entry={id:crypto.randomUUID(),documentId:port.sender.documentId||'',expiresAt:0,submitted:false,release};
      savePreparations.set(entry.id,entry);renew();
      reply({ok:true,preparationId:entry.id});
    })().catch(()=>{reply({ok:false,error:'保存の準備を開始できませんでした。再試行してください。'});release();});
  });
  renew();
});
const UPDATE_COMMANDS=new Set(['UPDATE_STATUS','UPDATE_CHECK','UPDATE_APPLY','UPDATE_SET_AUTO']);
async function handleMessage(message,sender){
  const updates=globalThis.VidDockUpdates;
  if(UPDATE_COMMANDS.has(message?.type)){
    return updates?updates.handle(message,sender):{ok:false,error:'更新機能を準備しています。'};
  }
  if(updates&&message?.type==='HELPER_REQUEST'&&message.path==='/api/update/apply'){
    const reply=await updates.handle({type:'UPDATE_APPLY'},sender);
    return reply.ok?{ok:true,value:{ok:true,state:reply.update?.state}}:reply;
  }
  const startsSave=message?.type==='DOWNLOAD_DIRECT'||message?.type==='BATCH_WINDOW_START'||message?.type==='HELPER_SAVE_SUBMIT'||
    (message?.type==='HELPER_REQUEST'&&message.path==='/api/download'&&message.method==='POST');
  if(!startsSave)return handleMessageCore(message,sender);
  if(updates){
    await updates.ready();
    if(updates.isBlocking())return {ok:false,error:'更新中です。完了してから保存してください。'};
  }
  activeSaveCommands++;
  try{return await handleMessageCore(message,sender);}
  finally{activeSaveCommands--;}
}
async function handleMessageCore(message, sender) {
  await ready;
  if (!message?.type) return { ok: false, error: '不正なリクエストです。' };
  if (message.type.startsWith('BATCH_WINDOW_')) return handleWindowBatch(message,sender);
  if(message.type==='HELPER_SAVE_SUBMIT'){
    const preparation=savePreparations.get(message.preparationId);
    if(!trustedPanel(sender)||!preparation||preparation.submitted||preparation.expiresAt<=Date.now()||
       preparation.documentId!==(sender.documentId||'')){
      return {ok:false,error:'保存の準備が中断されました。もう一度保存してください。'};
    }
    preparation.submitted=true;
    return helperRequest({path:'/api/download',method:'POST',data:message.data},sender);
  }
  if (message.type === 'HELPER_REQUEST') return helperRequest(message, sender);
  if (message.type === 'PATCH_HELPER_HISTORY') return patchHelperHistory(message,sender);
  if (message.type === 'POLL_HELPER_JOBS') return pollHelperJobs(sender);
  if (message.type === 'SAVE_DOWNLOAD_SETTINGS') return saveDownloadSettings(message,sender);
  if (message.type === 'REFRESH_BROWSER_TRANSFERS') return refreshBrowserTransfers(sender);
  if (message.type === 'GET_MEDIA') return { ok: true, items: (videosByTab.get(message.tabId) || []).slice() };
  if (message.type === 'GET_SETTINGS') {
    const saved=(await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY]||{};
    return {ok:true,folder:await getFolder(),fragmentConcurrency:[1,2,4,8].includes(saved.fragmentConcurrency)?saved.fragmentConcurrency:4,maxConcurrent:Number.isInteger(saved.maxConcurrent)&&saved.maxConcurrent>=1&&saved.maxConcurrent<=12?saved.maxConcurrent:3};
  }
  if (message.type === 'SET_SETTINGS') {
    try {
      const folder=normalizeFolder(message.folder);
      return await withLock(async()=>{
        const old=(await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY]||{};
        if(old.folder!==folder)await chrome.storage.local.set({[SETTINGS_KEY]:{...old,folder}});
        return {ok:true,folder};
      });
    }
    catch (error) { return { ok: false, error: error.message }; }
  }
  if (message.type === 'GET_HISTORY') {
    const history = await historyGet();
    return { ok: true, entries: history };
  }
  if (message.type === 'CLEAR_HISTORY') {
    await chrome.storage.local.set({ [HISTORY_KEY]: {} });
    return { ok: true };
  }
  if (message.type === 'UPDATE_RECORD') {
    if (typeof message.key !== 'string' || message.key.length > 2500 || !/^hls:/.test(message.key)) return { ok: false, error: '保存IDが不正です' };
    const update = {};
    for (const k of ['state','message','percent','downloadId']) if (Object.prototype.hasOwnProperty.call(message,k)) update[k] = message[k];
    await putRecord(message.key, update);
    return { ok: true };
  }
  if (message.type === 'GET_IDENTITY') {
    try { return { ok: true, key: identity(message.mediaType || 'direct', message.url) }; }
    catch { return { ok: false, error: 'URLが不正です' }; }
  }

  if (message.type === 'ADD_PAGE_MEDIA') {
    const tabId = message.tabId;
    const tab = Number.isInteger(tabId) ? await chrome.tabs.get(tabId).catch(() => null) : null;
    if (!tab) return { ok: false, error: 'タブが見つかりません。' };
    await Promise.all((Array.isArray(message.records) ? message.records : []).slice(0, 90)
      .map(r => record(tabId, { ...r, source: 'page' })));
    return { ok: true };
  }
  if (message.type === 'DOWNLOAD_DIRECT') {
    const entry = (videosByTab.get(message.tabId) || []).find(e => e.url === message.url);
    if (!entry || !['mp4','webm','mov','mkv'].includes(entry.type)) {
      return { ok: false, error: '動画URLが見つかりません。再スキャンしてください。' };
    }
    const key = identity('direct', entry.url);
    const acquired = await claim(key, { title: safeName(message.title), url: entry.url, pageUrl:isWebUrl(message.pageUrl)?message.pageUrl:'', thumbnail:isWebUrl(message.thumbnail)?message.thumbnail:(entry.thumbnail||'') });
    if (!acquired.ok) return { ok: true, duplicate: true, state: acquired.state, key };
    try {
      await preflightVideo(entry.url, entry.type);
      const filename = `${await getFolder()}/${safeName(message.title)}.${entry.type}`;
      const id = await chrome.downloads.download({ url: entry.url, filename, saveAs: false, conflictAction: 'uniquify' });
      await putRecord(key, { state: 'running', downloadId: id, filename, message: '保存中', percent: 0 });
      const details = await chrome.downloads.search({ id }).catch(() => []);
      if (details[0]?.state === 'complete') await putRecord(key, { state: 'done', percent: 100, message: '保存しました' });
      if (details[0]?.state === 'interrupted') await putRecord(key, { state: 'failed', message: details[0].error || '保存に失敗しました' });
      return { ok: true, downloadId: id, key };
    } catch (error) {
      await putRecord(key, { state: 'failed', message: error.message || String(error) });
      return { ok: false, error: error.message || String(error) };
    }
  }
  if (message.type === 'OPEN_HLS') return { ok: false, error: 'HLSはMP4変換が必要です。サイドパネルから補助ツールを使用してください。' };
  return { ok: false, error: '未知のリクエストです。' };
}
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  handleMessage(message, sender).then(reply, error => reply({ ok: false, error: error.message || String(error) }));
  return true;
});

if (typeof module !== 'undefined' && module.exports) module.exports = { mediaType, looksLikeHtml, signatureType, preflightVideo, normalizeFolder, identity };

// Window batch controller. No remote code, page clicks, cookies or challenge solving.
const WINDOW_BATCH_KEY='viddock_window_batch_v1';
const WINDOW_BATCH_ALARM='viddock-window-batch';
const WINDOW_BATCH_PLAN_KEY='viddock_window_batch_plan_v1';
const BATCH_RUNNING=new Set(['running','stopping']);
const BATCH_LOAD_TIMEOUT=30000;
const BATCH_SCAN_TIMEOUT=45000;
let windowBatch=null,windowBatchBusy=false,windowBatchTimer=null,windowBatchCommands=Promise.resolve();
const batchSender=()=>({id:chrome.runtime.id,url:chrome.runtime.getURL('sidepanel.html')});
const batchDelay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function batchPageIdentity(raw){try{const u=new URL(raw);u.hash='';return u.href;}catch{return '';}}
function batchWebTab(tab){return Number.isInteger(tab?.id)&&/^https?:\/\//i.test(tab.url||'');}
function batchYoutube(raw){
  try{const u=new URL(raw);let id='';
    if(/(^|\.)(youtube\.com|youtube-nocookie\.com)$/.test(u.hostname))id=u.pathname==='/watch'?u.searchParams.get('v'):/^\/(shorts|embed|live)\//.test(u.pathname)?u.pathname.split('/')[2]:'';
    else if(['youtu.be','www.youtu.be'].includes(u.hostname))id=u.pathname.split('/')[1];
    return /^[\w-]{11}$/.test(id||'')?'https://www.youtube.com/watch?v='+id:'';
  }catch{return '';}
}
function batchTokyo(raw){try{const u=new URL(raw);return /^(www\.)?tokyomotion\.net$/.test(u.hostname)&&/^\/video\/\d+\/[^/?#]*$/.test(u.pathname)?'https://www.tokyomotion.net'+u.pathname:'';}catch{return '';}}
function batchBest(items){
  return items.filter(x=>x&&/^https:\/\//i.test(x.url||'')&&['mp4','webm','hls','mov','mkv'].includes(x.type))
    .sort((a,b)=>batchScore(b)-batchScore(a))[0]||null;
}
function batchScore(x){return (x.playing?100000000:0)+(x.height||0)*2000+(x.width||0)+(x.type==='hls'?200:x.type==='mp4'?150:0);}
function batchSummary(){
  if(!windowBatch)return null;
  const {rows,...base}=windowBatch;const counts={};
  for(const row of rows)counts[row.state]=(counts[row.state]||0)+1;
  return {...base,counts,rows:rows.filter(r=>!['pending','reloading','scanning','submitting'].includes(r.state))
    .map(({tabId,title,state,message})=>({tabId,title,state,message}))};
}
async function batchPersist(){
  if(windowBatch)await chrome.storage.session.set({[WINDOW_BATCH_KEY]:windowBatch});
}
function batchSchedule(delay=200){
  if(windowBatchTimer!==null||windowBatchBusy||!BATCH_RUNNING.has(windowBatch?.state))return;
  windowBatchTimer=setTimeout(()=>{windowBatchTimer=null;void batchStep().catch(()=>{});},delay);
}
const windowBatchReady=chrome.storage.session.get(WINDOW_BATCH_KEY).then(async data=>{
  const stored=data[WINDOW_BATCH_KEY];
  if(!stored||!Array.isArray(stored.rows)||!Number.isInteger(stored.windowId))return;
  windowBatch=stored;
  await batchRestoreTab(windowBatch);
  // Read-only discovery can resume; an ambiguous POST must never be replayed.
  for(const row of windowBatch.rows){
    if(row.state==='submitting'){
      row.state='needs_action';row.message='拡張機能の処理が中断されました。保存一覧を確認して再試行してください。';
    }else if(['reloading','scanning'].includes(row.state)){
      row.resumeCount=(row.resumeCount||0)+1;
      row.state=row.resumeCount<=2?'pending':'needs_action';
      row.message=row.state==='pending'?'中断した動画の確認を再開します。':'動画の確認が繰り返し中断されました。このタブを確認してください。';
    }
  }
  if(BATCH_RUNNING.has(windowBatch.state)){await batchPersist();batchSchedule();}
}).catch(()=>{windowBatch=null;});
function batchAbortRequested(batch){return windowBatch!==batch||batch.state!=='running';}
async function batchGetTab(batch,row,checkUrl=true){
  const tab=await chrome.tabs.get(row.tabId);
  if(tab.windowId!==batch.windowId)throw Error('別のウィンドウへ移動したため対象から外しました。');
  if(checkUrl&&batchPageIdentity(tab.url)!==batchPageIdentity(row.url))throw Error('ページが変更されたため対象から外しました。');
  if(checkUrl&&tab.pendingUrl&&batchPageIdentity(tab.pendingUrl)!==batchPageIdentity(row.url))throw Error('別のページへ移動中のため対象から外しました。');
  return tab;
}
// This function runs in each page frame. Only videos started by this probe are paused.
async function batchProbeVideo(){
  const changed=[];
  try{
    for(const video of [...document.querySelectorAll('video')].slice(0,3)){
      if(!video.paused||video.ended||video.mediaKeys)continue;
      changed.push({video,muted:video.muted});video.muted=true;
      Promise.resolve(video.play()).catch(()=>{});
    }
    if(changed.length)await new Promise(resolve=>setTimeout(resolve,1600));
  }finally{for(const {video,muted}of changed){video.pause();video.muted=muted;}}
  return {probed:changed.length};
}
function batchPageFlags(){
  return {challenge:!!document.querySelector('#challenge-running,#challenge-stage')||/^(just a moment|checking your browser|security verification)/i.test(document.title.trim()),
    video:!!document.querySelector('video'),pageUrl:location.href,documentTimeOrigin:performance.timeOrigin};
}
async function batchExecute(details){
  let timer;
  try{return await Promise.race([
    chrome.scripting.executeScript(details),
    new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('ページの検出がタイムアウトしました。')),6500);})
  ]);}finally{clearTimeout(timer);}
}
async function batchInject(tabId,func){
  try{return await batchExecute({target:{tabId,allFrames:true},func});}
  catch{const result=await batchExecute({target:{tabId},func});result.partial=true;return result;}
}
async function batchResetDetection(row){
  await ready;
  videosByTab.delete(row.tabId);playbackHeadersByTab.delete(row.tabId);
  scheduleSave();void updateBadge(row.tabId);
}
// Ordinary scans retain their request context. Only dormant-page recovery reloads.
// Visibility remains opt-in and never brings another browser window to the front.
async function batchShowForScan(batch,row){
  if(!batch.activateForScan||batchAbortRequested(batch))return false;
  const tab=await batchGetTab(batch,row);
  if(tab.active)return false;
  if(tab.discarded&&(row.reloadCount||0)>=1)return false;
  const [previous]=await chrome.tabs.query({windowId:batch.windowId,active:true});
  if(!previous||previous.id===row.tabId)return false;
  batch.focusLease={from:previous.id,to:row.tabId,fromUrl:batchPageIdentity(previous.url),toUrl:batchPageIdentity(row.url)};
  await batchPersist();
  if(batchAbortRequested(batch))return false;
  const fresh=await batchGetTab(batch,row);
  if(fresh.discarded){
    if((row.reloadCount||0)>=1)return false;
    row.reloadCount=(row.reloadCount||0)+1;
    await batchResetDetection(row);await batchPersist();
  }
  if(batchAbortRequested(batch))return false;
  await batchGetTab(batch,row);
  const [selected]=await chrome.tabs.query({windowId:batch.windowId,active:true});
  if(selected?.id!==previous.id||batchAbortRequested(batch))return false;
  await chrome.tabs.update(row.tabId,{active:true});
  return true;
}
async function batchRestoreTab(batch){
  const lease=batch.focusLease;if(!lease)return;
  try{
    const [current]=await chrome.tabs.query({windowId:batch.windowId,active:true});
    // Never override a tab selection the user changed during the probe.
    if(current?.id!==lease.to)return;
    if(lease.toUrl&&(batchPageIdentity(current.url)!==lease.toUrl||
      (current.pendingUrl&&batchPageIdentity(current.pendingUrl)!==lease.toUrl)))return;
    const previous=await chrome.tabs.get(lease.from);
    if(previous.windowId===batch.windowId&&!previous.discarded&&!previous.frozen&&
       batchPageIdentity(previous.url)===lease.fromUrl){
      const [selected]=await chrome.tabs.query({windowId:batch.windowId,active:true});
      if(selected?.id!==lease.to||(lease.toUrl&&(batchPageIdentity(selected.url)!==lease.toUrl||
         (selected.pendingUrl&&batchPageIdentity(selected.pendingUrl)!==lease.toUrl))))return;
      await chrome.tabs.update(previous.id,{active:true});
    }
  }catch{/* Closed/moved tabs must not cause navigation or window creation. */}
  finally{delete batch.focusLease;}
}
async function batchWakeTab(batch,row){
  let tab=await batchGetTab(batch,row);
  if(batchAbortRequested(batch)||(!tab.discarded&&!tab.frozen))return;
  row.state='reloading';batch.currentTitle=row.title+' · 休止タブを復帰中';await batchPersist();
  if(batchAbortRequested(batch))return;
  // Frozen documents keep their page state and can normally just be unfrozen.
  if(tab.frozen&&!tab.discarded&&batch.activateForScan){
    await batchShowForScan(batch,row);
    await batchDelay(400);
    if(batchAbortRequested(batch))return;
    tab=await batchGetTab(batch,row);
    if(!tab.discarded&&!tab.frozen)return;
  }
  if((row.reloadCount||0)>=1)throw Error('復帰後もタブが休止しています。繰り返しリロードせず、このタブの確認を保留しました。');
  row.reloadCount=(row.reloadCount||0)+1;
  row.reloadSettledAfter=Date.now()+800;
  await batchResetDetection(row);await batchPersist();
  if(batchAbortRequested(batch))return;
  tab=await batchGetTab(batch,row);
  if(batchAbortRequested(batch))return;
  // Recheck after persistence: the user may already have resumed the page.
  if(!tab.discarded&&!tab.frozen)return;
  await chrome.tabs.reload(row.tabId);
  if(batchAbortRequested(batch))return;
  batch.currentTitle=row.title+' · 再読み込み後のページを待っています';await batchPersist();
}
async function batchWaitForReady(batch,row){
  const deadline=Date.now()+BATCH_LOAD_TIMEOUT;
  let stable=0;
  for(let pass=0;pass<80&&Date.now()<deadline;pass++){
    if(batchAbortRequested(batch))return false;
    const tab=await batchGetTab(batch,row);
    if((tab.discarded||tab.frozen)&&tab.status!=='loading'&&(row.reloadCount||0)<1){
      await batchWakeTab(batch,row);stable=0;continue;
    }
    if(!tab.discarded&&!tab.frozen&&tab.status!=='loading'&&!tab.pendingUrl&&Date.now()>=(row.reloadSettledAfter||0)){
      if(++stable>=2)return true;
    }else stable=0;
    await batchDelay(400);
  }
  if(batchAbortRequested(batch))return false;
  throw Error('ページの読み込みを30秒待ちましたが完了を確認できませんでした。動画がないとは判定していません。');
}
function batchMainFrame(frames){return frames.find(frame=>frame.frameId===0)?.result;}
async function batchValidateFrames(batch,row,frames){
  await batchGetTab(batch,row);
  const main=batchMainFrame(frames);
  if(main?.pageUrl&&batchPageIdentity(main.pageUrl)!==batchPageIdentity(row.url))throw Error('検出中にページが変更されました。');
}
async function batchScan(batch,row){
  let poster='',hasVideo=false,playbackProbed=false,activationAttempted=false,partialFrames=false;
  let bestUrl='',bestSince=0,lastProbeAt=0,probeCount=0,lastError='';
  const startedAt=Date.now(),deadline=startedAt+BATCH_SCAN_TIMEOUT;
  // Fast paths finish quickly. Late players/frames get a full bounded discovery window.
  for(let pass=0;pass<60&&Date.now()<deadline;pass++){
    if(batchAbortRequested(batch))return {cancelled:true};
    let tab=await batchGetTab(batch,row);
    if(tab.discarded||tab.frozen){await batchWakeTab(batch,row);playbackProbed=false;bestUrl='';}
    if(tab.discarded||tab.frozen||tab.status==='loading'||tab.pendingUrl){
      if(!await batchWaitForReady(batch,row))return {cancelled:true};
      row.state='scanning';
    }
    const generation=row.pageGeneration||0;
    let flags,frames;
    try{
      flags=await batchInject(row.tabId,batchPageFlags);
      if(batchAbortRequested(batch))return {cancelled:true};
      await batchValidateFrames(batch,row,flags);
      if(flags.some(x=>x.result?.challenge))return {needsAction:'ページで認証・確認を完了してから再試行してください。'};
      frames=await batchInject(row.tabId,scanPageVideos);
    }catch(error){
      // A newly restored page/frame may not accept scripts immediately.
      if(batchAbortRequested(batch))return {cancelled:true};
      await batchGetTab(batch,row);
      lastError=String(error.message||error);await batchDelay(1000);continue;
    }
    if(batchAbortRequested(batch))return {cancelled:true};
    await batchValidateFrames(batch,row,frames);
    partialFrames ||= !!frames.partial;
    const flagsMain=batchMainFrame(flags),scanMain=batchMainFrame(frames);
    if(generation!==(row.pageGeneration||0)||(flagsMain?.documentTimeOrigin&&scanMain?.documentTimeOrigin&&
       flagsMain.documentTimeOrigin!==scanMain.documentTimeOrigin)){bestUrl='';await batchDelay(400);continue;}
    let drm=false,videoNow=false;
    for(const frame of frames){
      const found=frame.result;if(!found)continue;
      drm ||= !!found.hasDRM;videoNow ||= !!found.hasVideo;
      if(!poster)poster=found.pagePoster||'';
      for(const item of (found.records||[]).slice(0,90))await record(row.tabId,{...item,source:'page'});
    }
    hasVideo ||= videoNow;
    if(drm)return {needsAction:'DRM付き動画は保存対象外です。'};
    const best=batchBest((videosByTab.get(row.tabId)||[]).slice());
    if(best?.url!==bestUrl){bestUrl=best?.url||'';bestSince=Date.now();}
    // Two independent scans are required; give background/config-only candidates time.
    if(best&&pass>0&&Date.now()-bestSince>=(hasVideo?600:2500))return {
      best,poster,hasVideo,pageGeneration:generation,documentTimeOrigin:scanMain?.documentTimeOrigin||flagsMain?.documentTimeOrigin||0
    };
    // A video appearing on a later pass still gets the requested playback probe.
    if(!best&&videoNow&&batch.probePlayback&&probeCount<3&&(!playbackProbed||Date.now()-lastProbeAt>=12000)){
      playbackProbed=true;lastProbeAt=Date.now();probeCount++;
      try{await batchInject(row.tabId,batchProbeVideo);}catch{/* Retry discovery after a transient player error. */}
      if(batchAbortRequested(batch))return {cancelled:true};
      await batchGetTab(batch,row);
    }
    if(!best&&pass>=1&&!activationAttempted){
      activationAttempted=true;
      if(await batchShowForScan(batch,row))playbackProbed=false;
    }
    if(pass===2||pass%5===0){batch.currentTitle=row.title+' · 動画を再確認中（'+Math.floor((Date.now()-startedAt)/1000)+'秒）';await batchPersist();}
    await batchDelay(pass===0?600:1000);
  }
  return {poster,hasVideo,partialFrames,scanError:!!lastError};
}
async function batchRunTab(batch,row){
  try{
    const initial=await batchGetTab(batch,row);
    if(batchAbortRequested(batch))return;
    row.state='scanning';batch.currentTitle=row.title;await batchPersist();
    if(initial.discarded||initial.frozen)await batchWakeTab(batch,row);
    if(!await batchWaitForReady(batch,row))return;
    row.state='scanning';await batchPersist();
    let youtube=batchYoutube(row.url),tokyo=batchTokyo(row.url);
    const found=await batchScan(batch,row);
    if(batchAbortRequested(batch)||found.cancelled)return;
    if(found.needsAction){row.state='needs_action';row.message=found.needsAction;return;}
    if(!found.best&&!youtube&&!tokyo){
      row.state='needs_action';row.message=found.partialFrames?'埋め込みプレイヤーの一部を確認できませんでした。タブで動画を再生して再試行してください。':found.hasVideo?'動画はありますが、45秒間再確認しても保存先URLを取得できませんでした。':found.scanError?'ページへの接続を繰り返しましたが検出を完了できませんでした。':'45秒間再確認しましたが動画の取得先を特定できませんでした。動画がないとは判定していません。';return;
    }
    const tab=await batchGetTab(batch,row);if(batchAbortRequested(batch))return;
    const finalFlags=await batchInject(row.tabId,batchPageFlags);
    if(batchAbortRequested(batch))return;
    await batchValidateFrames(batch,row,finalFlags);
    if(finalFlags.some(x=>x.result?.challenge))throw Error('ページで認証・確認を完了してから再試行してください。');
    const finalDocument=batchMainFrame(finalFlags)?.documentTimeOrigin;
    if(found.documentTimeOrigin&&finalDocument&&found.documentTimeOrigin!==finalDocument)throw Error('検出後にページが再読み込みされました。もう一度確認してください。');
    const site=youtube?'youtube':tokyo?'tokyomotion':'media';
    const url=youtube||tokyo||tab.url,mediaUrl=found.best?.url||'';
    if(site!=='youtube'&&!url.startsWith('https://')){row.state='skipped';row.message='HTTPSの動画ページが必要です。';return;}
    row.state='submitting';await batchPersist();
    if(batchAbortRequested(batch))return;
    await batchGetTab(batch,row);
    if(batchAbortRequested(batch))return;
    if(found.pageGeneration!==undefined&&found.pageGeneration!==(row.pageGeneration||0))throw Error('検出後にページが再読み込みされました。もう一度確認してください。');
    const reply=await helperRequest({path:'/api/download',method:'POST',data:{site,url,quality:'best',mediaUrl,requestContext:found.best?.requestContext||{}}},batchSender());
    if(!reply.ok){row.state='needs_action';row.message=String(reply.error||'保存予約を確認できませんでした。').slice(0,240);return;}
    const result=reply.value,key=site+':'+(site==='media'?mediaUrl:url);
    const prior=(await chrome.storage.local.get(HELPER_HISTORY_KEY))[HELPER_HISTORY_KEY]?.[key];
    const stored=prior?.jobId===result.jobId?{ok:true}:await patchHelperHistory({key,patch:{jobId:result.jobId,title:tab.title||row.title,url,pageUrl:tab.url,
      thumbnail:found.best?.thumbnail||found.poster||'',state:result.state||'queued',queuePosition:result.queuePosition||0,
      percent:result.state==='done'?100:0,message:result.message||'ウィンドウ一括保存から追加',connectionLost:false}},batchSender());
    row.state=result.duplicate?'duplicate':'added';row.jobId=result.jobId;
    row.message=stored.ok?(result.duplicate?'保存済み・予約済みのため二重保存しません。':'保存待機列へ追加しました。'):'予約は受理されましたが一覧の更新に失敗しました。';
    batch.currentTitle=tab.title||row.title;
  }catch(e){row.state='needs_action';row.message='タブを確認してください: '+String(e.message||e).replace(/https?:\/\/\S+/g,'[URL]').slice(0,220);}
  finally{
    await batchRestoreTab(batch);
    if(batchAbortRequested(batch)&&['reloading','scanning','submitting'].includes(row.state)){
      row.state='cancelled';row.message='一括操作を停止しました。受理済みの保存は続行します。';
    }
  }
}
async function batchStep(){
  await windowBatchReady;
  if(windowBatchBusy||!BATCH_RUNNING.has(windowBatch?.state))return;
  windowBatchBusy=true;const batch=windowBatch;let delay=250;
  try{
    if(batch.state==='stopping'){
      for(const row of batch.rows)if(row.state==='pending')row.state='cancelled';
      batch.state='stopped';batch.phase='stopped';return;
    }
    const row=batch.rows.find(x=>x.state==='pending');
    if(!row){batch.completed=batch.rows.length;batch.state='done';batch.phase='done';
      const unresolved=batch.rows.filter(r=>['needs_action','no_video'].includes(r.state)).length;
      batch.currentTitle=unresolved?'全タブの確認が終了しました。確認が必要な '+unresolved+' 件は結果一覧に理由を表示しています。':'全タブの確認・保存予約が完了しました。保存処理は一覧で続行します。';return;}
    // Backpressure avoids scanning more pages while the existing save queue is full.
    const health=await helperRequest({path:'/api/status',method:'GET'},batchSender());
    if(!health.ok){batch.phase='connection_wait';batch.currentTitle='補助ツールへの接続待ち（停止ボタンで中止できます）';delay=8000;return;}
    if((health.value.queuedDownloads||0)>=195){batch.phase='queue_wait';batch.currentTitle='保存待機列の空きを待っています';delay=5000;return;}
    batch.phase='processing';await batchRunTab(batch,row);
    batch.completed=batch.rows.filter(x=>x.state!=='pending'&&!['reloading','scanning','submitting'].includes(x.state)).length;
  }finally{
    try{await batchPersist();}finally{windowBatchBusy=false;}
    if(BATCH_RUNNING.has(batch.state))batchSchedule(delay);
    else{try{await chrome.alarms?.clear(WINDOW_BATCH_ALARM);}catch{}}
  }
}
async function handleWindowBatch(message,sender){
  if(!trustedPanel(sender))return {ok:false,error:'サイドパネルからのみ実行できます。'};
  await windowBatchReady;
  if(message.type==='BATCH_WINDOW_STATUS')return {ok:true,batch:batchSummary()};
  if(message.type==='BATCH_WINDOW_STOP'){
    if(windowBatch?.state==='running'){windowBatch.state='stopping';await batchPersist();batchSchedule(0);}
    return {ok:true,batch:batchSummary()};
  }
  const execute=async()=>{
    if(!Number.isInteger(message.windowId)||message.windowId<0)return {ok:false,error:'対象ウィンドウを確認できません。'};
    if(message.type==='BATCH_WINDOW_PREVIEW'){
      const tabs=(await chrome.tabs.query({windowId:message.windowId})).sort((a,b)=>a.index-b.index);
      if(tabs.length>1000)return {ok:false,error:'一括対象は1ウィンドウ1000タブまでです。ウィンドウを分けてください。'};
      const plan={id:crypto.randomUUID(),windowId:message.windowId,createdAt:Date.now(),rows:tabs.map(t=>({tabId:t.id,url:t.url||'',title:(t.title||'タブ').slice(0,300),state:batchWebTab(t)?'pending':'skipped',message:batchWebTab(t)?'':'Chrome内部ページなどは対象外です。'}))};
      await chrome.storage.session.set({[WINDOW_BATCH_PLAN_KEY]:plan});
      return {ok:true,planId:plan.id,total:plan.rows.length,eligible:plan.rows.filter(r=>r.state==='pending').length};
    }
    if(message.type!=='BATCH_WINDOW_START')return {ok:false,error:'不明な一括操作です。'};
    if(globalThis.VidDockUpdates?.isBlocking())return {ok:false,error:'更新中です。完了してから保存してください。'};
    if(BATCH_RUNNING.has(windowBatch?.state))return {ok:false,error:'別の一括操作が進行中です。完了または停止後に開始してください。'};
    const plan=(await chrome.storage.session.get(WINDOW_BATCH_PLAN_KEY))[WINDOW_BATCH_PLAN_KEY];
    if(!plan||plan.id!==message.planId||plan.windowId!==message.windowId||Date.now()-plan.createdAt>600000)return {ok:false,error:'対象タブをもう一度確認してください。'};
    const health=await helperRequest({path:'/api/status',method:'GET'},sender);
    if(!health.ok)return health;
    if(!health.value.ytdlp||!health.value.ffmpeg)return {ok:false,error:'yt-dlpとFFmpegが利用可能な補助ツールが必要です。'};
    if(globalThis.VidDockUpdates?.isBlocking())return {ok:false,error:'更新中です。完了してから保存してください。'};
    windowBatch={id:crypto.randomUUID(),windowId:plan.windowId,state:'running',phase:'processing',rows:plan.rows,completed:0,total:plan.rows.length,startedAt:Date.now(),probePlayback:message.probePlayback===true,activateForScan:message.activateForScan===true,currentTitle:''};
    await batchPersist();
    try{await chrome.alarms?.create(WINDOW_BATCH_ALARM,{periodInMinutes:1});}catch{}
    batchSchedule(0);return {ok:true,batch:batchSummary()};
  };
  const task=windowBatchCommands.then(execute,execute);windowBatchCommands=task.catch(()=>{});return task;
}
if(typeof importScripts==='function')importScripts('scan.js');
chrome.tabs.onUpdated?.addListener((tabId,change)=>{
  if(change.status!=='loading'||!BATCH_RUNNING.has(windowBatch?.state))return;
  const row=windowBatch.rows.find(r=>r.tabId===tabId&&['reloading','scanning','submitting'].includes(r.state));
  if(row)row.pageGeneration=(row.pageGeneration||0)+1;
});
chrome.alarms?.onAlarm.addListener(alarm=>{if(alarm.name===WINDOW_BATCH_ALARM)void batchStep().catch(()=>{});});

async function updateBusyReason(){
  await windowBatchReady;
  if(activeSaveCommands||hasSavePreparations()||windowBatchBusy||BATCH_RUNNING.has(windowBatch?.state))return '動画の確認・保存が終わるまで待機します。';
  const history=await historyGet();
  const transfers=await chrome.downloads.search({state:'in_progress'});
  const ours=new Set(Object.values(history).map(item=>item?.downloadId).filter(Number.isInteger));
  if(transfers.some(item=>item.byExtensionId===chrome.runtime.id||ours.has(item.id)))return '保存が終わるまで待機します。';
  if(Object.values(history).some(item=>item?.state==='preparing'&&Date.now()-(item.updatedAt||0)<20*60*1000))return '保存の準備が終わるまで待機します。';
  if(activeSaveCommands||hasSavePreparations()||BATCH_RUNNING.has(windowBatch?.state))return '動画の確認・保存が終わるまで待機します。';
  return '';
}

// BEGIN VIDDock update bundle
// Bundled into background.js by the release build. Loading this file has no
// side effects; the background worker supplies transport and activity gates.
globalThis.VidDockUpdates = (() => {
  'use strict';
  const KEY = 'viddock_update_state_v1';
  const ALARM = 'viddock-auto-update-v1';
  const MINUTE = 60 * 1000;
  const INTERVAL = 6 * 60 * MINUTE;
  const DEFER = 5 * MINUTE;
  const APPLY_TIMEOUT = 10 * MINUTE;
  const POLL = 1500;
  const BACKOFF = [5 * MINUTE, 15 * MINUTE, 60 * MINUTE, INTERVAL];
  const ACTIVE = new Set(['running', 'restarting']);
  let config, state, loadedVersion = '', initialization, flight, pollTimer;
  let blocking = false;
  let initializationFailed = false, recovering = false;
  let writes = Promise.resolve();

  function version(value) {
    if (typeof value !== 'string' || !/^\d+\.\d+\.\d+$/.test(value)) return null;
    const parts = value.split('.').map(Number);
    return parts.every(part => part <= 65535) ? parts : null;
  }
  function compare(left, right) {
    const a = version(left), b = version(right);
    if (!a || !b) return 0;
    for (let index = 0; index < 3; index++) if (a[index] !== b[index]) return a[index] > b[index] ? 1 : -1;
    return 0;
  }
  function newest(left, right) {
    return !version(left) || (version(right) && compare(right, left) > 0) ? right : left;
  }
  function defaults() {
    return {
      schema: 1, enabled: true, state: 'idle', message: '更新を定期的に確認します。', percent: 0,
      latestVersion: '', helperVersion: '', diskVersion: '', targetVersion: '',
      lastCheckedAt: 0, lastAttemptAt: 0, nextCheckAt: Date.now() + MINUTE,
      checkFailures: 0, pendingApply: false, manualRequested: false, failedVersion: '',
      intent: null, reloadRequestedVersion: '', reloadRequestedAt: 0,
    };
  }
  function candidate() { return newest(state.latestVersion, state.diskVersion) || ''; }
  function available() { return compare(candidate(), loadedVersion) > 0; }
  function snapshot() {
    return {
      enabled: state.enabled, state: state.state, currentVersion: loadedVersion,
      helperVersion: state.helperVersion, latestVersion: candidate(), targetVersion: state.targetVersion,
      available: available(), percent: state.percent, message: state.message,
      lastCheckedAt: state.lastCheckedAt, nextCheckAt: state.enabled || state.intent || state.manualRequested ? state.nextCheckAt : 0,
      inProgress: Boolean(state.intent) || state.state === 'checking',
      blocking,
    };
  }
  function response() {
    const update = snapshot();
    const ok = !['failed', 'offline', 'error'].includes(update.state);
    return ok ? {ok: true, update} : {ok: false, error: update.message, update};
  }
  function persist() {
    // Capture each revision now; serialize writes so a late check cannot undo
    // a preference changed while the request was in flight.
    const value = JSON.parse(JSON.stringify(state));
    const task = writes.then(() => chrome.storage.local.set({[KEY]: value}));
    writes = task.catch(() => {});
    return task;
  }
  async function request(path, method = 'GET') {
    try { return await config.request(path, method, {}); }
    catch { return {ok: false}; }
  }
  async function busy() {
    try { return (await config.busy()) || ''; }
    catch { return '保存状況を確認してから更新します。'; }
  }
  function helperBusy(health) {
    return ['activeDownloads', 'runningDownloads', 'queuedDownloads', 'impersonationInstalling'].some(key => Number(health?.[key]) > 0);
  }
  function signature(status) {
    return JSON.stringify([status?.state || '', status?.version || '', Number(status?.updatedAt) || 0]);
  }
  function freshStatus(status, intent) {
    // The helper records whole SECONDS. A changed status in the same second
    // belongs to this request; an unchanged previous "done" does not.
    return Number(status?.updatedAt) >= Math.floor(intent.startedAt / 1000) &&
      (signature(status) !== intent.before || intent.seenActive);
  }
  async function schedule() {
    if (pollTimer !== undefined) { clearTimeout(pollTimer); pollTimer = undefined; }
    // Let the new worker replace the existing alarm after reload. Clearing it
    // here could race that worker's startup alarm creation.
    if (state?.state === 'reload_pending') return;
    if (!state || (!initializationFailed && !state.enabled && !state.intent && !state.manualRequested)) {
      try { await chrome.alarms.clear(ALARM); } catch {}
      return;
    }
    // One-shot alarms are recreated whenever the worker starts. A one-minute
    // floor also works on the minimum supported Chrome version (116).
    const when = Math.max(Date.now() + MINUTE, Number(state.nextCheckAt) || Date.now() + MINUTE);
    try { await chrome.alarms.create(ALARM, {when}); } catch {}
    // Short polling only while an installation is active. The alarm is the
    // durable fallback when Chrome suspends this worker or the panel is closed.
    if (state.intent && !state.intent.verifiedVersion && !initializationFailed) {
      pollTimer = setTimeout(() => { pollTimer = undefined; void tick(); }, POLL);
    }
  }
  async function initialize() {
    loadedVersion = chrome.runtime.getManifest().version;
    state = defaults();
    try {
      const saved = (await chrome.storage.local.get(KEY))[KEY];
      if (saved && typeof saved === 'object' && !Array.isArray(saved)) {
        state = {...state, ...saved, enabled: saved.enabled !== false, schema: 1};
        for (const key of ['latestVersion', 'helperVersion', 'diskVersion', 'targetVersion', 'failedVersion', 'reloadRequestedVersion']) {
          if (!version(state[key])) state[key] = '';
        }
        for (const key of ['lastCheckedAt', 'lastAttemptAt', 'nextCheckAt', 'reloadRequestedAt']) {
          if (!Number.isFinite(state[key]) || state[key] < 0) state[key] = 0;
        }
        const intent = state.intent;
        if (!intent || !version(intent.targetVersion) || !Number.isFinite(intent.startedAt) || intent.startedAt <= 0) state.intent = null;
        if (state.intent) {
          state.intent.deadline = state.intent.startedAt + APPLY_TIMEOUT;
          state.targetVersion = state.intent.targetVersion;
        } else if (state.state === 'checking') {
          state.state = available() ? 'available' : 'idle';
          state.nextCheckAt = Date.now() + MINUTE;
        }
      }
      if (state.state === 'reload_pending' && state.reloadRequestedVersion === state.intent?.targetVersion) {
        if (compare(loadedVersion, state.reloadRequestedVersion) >= 0) {
          complete(state.reloadRequestedVersion);
        } else {
          // Never create a reload loop if the unpacked extension did not pick
          // up the new files. An explicit Update action may retry the reload.
          fail('更新済みです。「今すぐ更新」を押して読み込み直してください。');
        }
      }
      blocking = Boolean(state.intent);
      await persist();
      initializationFailed = false;
      await schedule();
    } catch {
      // Unknown durable state may contain an already-sent POST. Do not replace
      // it with defaults or start another install until storage can be read.
      initializationFailed = true; blocking = true;
      state.state = 'error';
      state.message = '更新設定を読み込めませんでした。あとで再確認してください。';
      state.nextCheckAt = Date.now() + DEFER;
      await schedule();
    }
    return snapshot();
  }
  function start(options) {
    if (initialization) return initialization;
    if (!options || typeof options.request !== 'function' || typeof options.busy !== 'function' || typeof options.trusted !== 'function') {
      throw new TypeError('Update transport, activity gate, and trusted sender check are required');
    }
    config = options;
    blocking = true;
    chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === ALARM) void tick(); });
    const startup = () => {
      void ready().then(async () => {
        if (initializationFailed) { await schedule(); return; }
        if (!state.intent && state.enabled) {
          state.nextCheckAt = Math.min(state.nextCheckAt || Infinity, Date.now() + MINUTE);
          await persist();
        }
        await schedule();
      }).catch(() => {});
    };
    chrome.runtime.onStartup?.addListener(startup);
    chrome.runtime.onInstalled?.addListener(startup);
    initialization = initialize();
    return initialization;
  }
  function ready() { return initialization || Promise.resolve(); }
  function restore() {
    if (initializationFailed && !recovering) {
      recovering = true;
      initialization = initialize().finally(() => { recovering = false; });
    }
    return ready();
  }
  function complete(actual) {
    state.intent = null; state.targetVersion = ''; state.pendingApply = false; state.manualRequested = false;
    state.state = 'done'; state.message = '最新版です。'; state.percent = 100;
    state.latestVersion = newest(state.latestVersion, actual); state.diskVersion = actual;
    state.reloadRequestedVersion = ''; state.reloadRequestedAt = 0;
    state.failedVersion = ''; state.checkFailures = 0; state.nextCheckAt = Date.now() + INTERVAL;
    blocking = false;
  }
  function fail(message) {
    state.failedVersion = state.targetVersion || candidate();
    state.intent = null; state.pendingApply = false; state.manualRequested = false;
    state.state = 'failed'; state.message = message; state.nextCheckAt = Date.now() + INTERVAL;
    blocking = false;
  }
  async function offline() {
    state.intent = null; state.pendingApply = false; state.manualRequested = false;
    state.state = 'offline'; state.message = '更新を確認できません。あとで再確認します。';
    const index = Math.min(Math.max(0, Number(state.checkFailures) || 0), BACKOFF.length - 1);
    state.checkFailures = index + 1; state.nextCheckAt = Date.now() + BACKOFF[index];
    blocking = false;
    await persist();
  }
  async function defer(message, manual = state.manualRequested) {
    if (!manual && !state.enabled) {
      state.intent = null; state.pendingApply = false; state.manualRequested = false;
      state.state = 'available'; state.message = `v${candidate()} に更新できます。`;
      blocking = false; await persist(); return;
    }
    state.intent = null; state.pendingApply = true; state.manualRequested = manual;
    state.state = 'waiting_idle'; state.message = message || '保存が終わり次第、更新します。';
    state.targetVersion = candidate(); state.nextCheckAt = Date.now() + DEFER;
    blocking = false;
    await persist();
  }
  async function check(allowAutomatic) {
    state.state = 'checking'; state.message = '更新を確認しています…'; state.percent = 0;
    state.lastAttemptAt = Date.now();
    await persist();
    const result = await request('/api/update/check');
    if (!result?.ok || !version(result.value?.latestVersion) || !version(result.value?.currentVersion)) return offline();
    state.latestVersion = result.value.latestVersion; state.diskVersion = result.value.currentVersion;
    if (version(result.value.helperVersion)) state.helperVersion = result.value.helperVersion;
    state.lastCheckedAt = Date.now(); state.checkFailures = 0; state.nextCheckAt = Date.now() + INTERVAL;
    state.pendingApply = false; state.targetVersion = available() ? candidate() : '';
    if (!available()) {
      state.state = 'current'; state.message = '最新版です。'; state.manualRequested = false;
      await persist(); return;
    }
    state.state = 'available'; state.message = `v${candidate()} に更新できます。`;
    const installed = compare(state.diskVersion, loadedVersion) > 0;
    if (!installed && state.failedVersion && compare(candidate(), state.failedVersion) <= 0 && !state.manualRequested) {
      state.state = 'failed'; state.message = '更新を完了できませんでした。再試行する場合は「今すぐ更新」を押してください。';
      await persist(); return;
    }
    if (state.manualRequested || (allowAutomatic && state.enabled)) {
      await persist(); await apply();
    } else {
      if (state.enabled) { state.pendingApply = true; state.nextCheckAt = Date.now() + DEFER; }
      await persist();
    }
  }
  async function beginIntent(status, external) {
    const target = external ? newest(candidate(), version(status.version) ? status.version : '') : candidate();
    state.targetVersion = target;
    state.intent = {
      targetVersion: target, startedAt: Date.now(), deadline: Date.now() + APPLY_TIMEOUT,
      before: signature(status), seenActive: false, external: Boolean(external),
    };
    state.pendingApply = false; state.state = status.state === 'restarting' ? 'restarting' : 'applying';
    state.message = '更新を適用しています…'; state.percent = 0; state.nextCheckAt = Date.now() + MINUTE;
    blocking = true;
    // A restored intent is always reconciled read-only, even if the worker
    // stopped immediately before sending this POST.
    await persist();
  }
  async function apply() {
    const manual = Boolean(state.manualRequested);
    if (!manual && !state.enabled) return;
    // Acquired synchronously before any awaited activity checks. The caller
    // blocks new save commands while these final checks and the POST run.
    blocking = true;
    let reason = await busy();
    if (reason) return defer(reason, manual);
    const health = await request('/api/status');
    if (!health?.ok) return offline();
    if (version(health.value?.version)) state.helperVersion = health.value.version;
    if (helperBusy(health.value)) return defer('', manual);
    const result = await request('/api/update/status');
    if (!result?.ok) return offline();
    const status = result.value || {};
    reason = await busy();
    if (reason) return defer(reason, manual);
    if (!manual && !state.enabled) {
      blocking = false; state.pendingApply = false; state.state = 'available';
      state.message = `v${candidate()} に更新できます。`; await persist(); return;
    }
    const installed = compare(state.diskVersion, loadedVersion) > 0;
    if (installed || ACTIVE.has(status.state)) {
      await beginIntent(status, true); state.manualRequested = false;
      await reconcile(); return;
    }
    await beginIntent(status, false);
    // Preference and activity may change while local persistence is pending.
    // Until this last check no install request has been sent.
    reason = await busy();
    if (reason) return defer(reason, manual);
    if (!manual && !state.enabled) {
      state.intent = null; state.pendingApply = false; state.state = 'available';
      state.message = `v${candidate()} に更新できます。`; blocking = false; await persist(); return;
    }
    state.manualRequested = false;
    const resultApply = await request('/api/update/apply', 'POST');
    if (!resultApply?.ok && resultApply?.status === 409) {
      // This response guarantees our request was rejected. An already-running
      // updater is monitored; a download collision can safely be tried later.
      const current = await request('/api/update/status');
      if (current?.ok && (ACTIVE.has(current.value?.state) ||
          (current.value?.state === 'done' && freshStatus(current.value, state.intent) && compare(current.value.version, state.intent.targetVersion) >= 0))) {
        state.intent.external = true;
        await reconcile(); return;
      }
      return defer('', manual);
    }
    if (!resultApply?.ok && resultApply?.status >= 400 && resultApply?.status < 500) {
      fail('更新を開始できませんでした。あとで再試行してください。'); await persist(); return;
    }
    state.message = resultApply?.ok ? '更新を適用しています…' : '更新状況を確認しています…';
    // A lost response is ambiguous. Keep the persisted intent and never POST
    // again on a timer, a duplicate click, or a service-worker restart.
    await persist();
  }
  async function reconcile() {
    const intent = state.intent;
    if (!intent || state.state === 'reload_pending') return;
    intent.verifiedVersion = '';
    blocking = true;
    const result = await request('/api/update/status');
    if (result?.ok) {
      const status = result.value || {};
      const fresh = intent.external || freshStatus(status, intent);
      if (fresh && status.state === 'failed') {
        if (version(status.version) && compare(status.version, intent.targetVersion) >= 0) state.targetVersion = status.version;
        fail('更新を完了できませんでした。再試行する場合は「今すぐ更新」を押してください。');
        await persist(); return;
      }
      if (fresh && ACTIVE.has(status.state)) {
        intent.seenActive = true;
        if (version(status.version) && compare(status.version, intent.targetVersion) >= 0) {
          intent.targetVersion = status.version; state.targetVersion = status.version;
        }
        state.state = status.state === 'restarting' ? 'restarting' : 'applying';
        state.message = status.state === 'restarting' ? '更新後の起動を確認しています…' : '更新を適用しています…';
        state.percent = Math.max(0, Math.min(100, Number(status.percent) || 0));
      }
      if (fresh && status.state === 'done' && version(status.version) && compare(status.version, intent.targetVersion) >= 0) {
        // apply_update checks the release again; its actual version can be
        // newer than the one originally displayed by /api/update/check.
        intent.targetVersion = status.version; state.targetVersion = status.version;
        const health = await request('/api/status');
        if (health?.ok && version(health.value?.version)) state.helperVersion = health.value.version;
        if (health?.ok && health.value?.version === status.version) {
          intent.verifiedVersion = status.version;
          state.percent = 100;
          if (compare(loadedVersion, status.version) >= 0) {
            complete(status.version); await persist(); return;
          }
          const reason = await busy();
          if (reason || helperBusy(health.value)) {
            state.state = 'waiting_idle'; state.message = '保存が終わり次第、更新を仕上げます。';
            state.nextCheckAt = Date.now() + DEFER; await persist(); return;
          }
          if (state.reloadRequestedVersion === status.version) {
            fail('更新済みです。「今すぐ更新」を押して読み込み直してください。'); await persist(); return;
          }
          state.diskVersion = status.version;
          state.state = 'reload_pending'; state.message = '更新が完了しました。画面を再読み込みします。';
          state.reloadRequestedVersion = status.version; state.reloadRequestedAt = Date.now();
          await persist();
          // The gate remains held until the extension reloads. Persisting the
          // marker first prevents repeated reloads of an unchanged runtime.
          try { chrome.runtime.reload(); }
          catch { fail('更新済みです。「今すぐ更新」を押して読み込み直してください。'); await persist(); }
          return;
        }
        state.state = 'restarting'; state.message = '更新後の起動を確認しています…';
      }
    } else {
      state.message = '更新後の起動を確認しています…';
    }
    if (Date.now() >= intent.deadline && !intent.verifiedVersion) {
      fail('更新の完了を確認できませんでした。あとで再確認してください。');
    } else {
      state.nextCheckAt = Date.now() + MINUTE;
    }
    await persist();
  }
  function run(forceCheck = false) {
    if (flight) return flight;
    flight = (async () => {
      await restore();
      if (!config || !state) return {ok: false, error: '更新機能を準備しています。'};
      if (initializationFailed) return response();
      try {
        if (state.intent) await reconcile();
        else if (forceCheck) await check(false);
        else if (state.manualRequested || (state.enabled && Date.now() >= state.nextCheckAt)) {
          if (state.pendingApply && available() && Date.now() - state.lastCheckedAt < INTERVAL) await apply();
          else await check(true);
        }
      } catch {
        if (state.intent) {
          if (Date.now() >= state.intent.deadline) fail('更新の完了を確認できませんでした。あとで再確認してください。');
          else { state.message = '更新状況を確認しています…'; state.nextCheckAt = Date.now() + MINUTE; }
        } else {
          state.state = 'error'; state.message = '更新を開始できませんでした。あとで再確認してください。';
          state.nextCheckAt = Date.now() + DEFER; state.manualRequested = false; blocking = false;
        }
        try { await persist(); } catch {}
      }
      return response();
    })().finally(async () => {
      await schedule();
      flight = undefined;
    });
    return flight;
  }
  function tick() { return run(false); }
  async function handle(message, sender) {
    if (!config || !config.trusted(sender)) return {ok: false, error: '更新操作はサイドパネルから行ってください。'};
    await restore();
    if (message?.type === 'UPDATE_STATUS') return {ok: true, update: snapshot()};
    if (initializationFailed) return response();
    if (message?.type === 'UPDATE_SET_AUTO') {
      if (typeof message.enabled !== 'boolean') return {ok: false, error: '自動更新の設定が不正です。'};
      state.enabled = message.enabled;
      if (!state.intent) {
        if (state.enabled) state.nextCheckAt = Math.min(state.nextCheckAt || Infinity, Date.now() + MINUTE);
        else if (!state.manualRequested) {
          state.pendingApply = false;
          if (state.state === 'waiting_idle') { state.state = 'available'; state.message = `v${candidate()} に更新できます。`; }
        }
      }
      await persist(); await schedule();
      return {ok: true, update: snapshot()};
    }
    if (message?.type === 'UPDATE_CHECK') return run(true);
    if (message?.type === 'UPDATE_APPLY') {
      if (!state.intent) {
        state.manualRequested = true; state.failedVersion = ''; state.reloadRequestedVersion = ''; state.reloadRequestedAt = 0;
        state.nextCheckAt = Date.now();
        await persist();
      }
      const result = await run(false);
      // An Apply click can arrive just as a check-only flight finishes.
      if (state.manualRequested && !state.intent && state.state === 'available') return run(false);
      return result;
    }
    return {ok: false, error: '不正な更新操作です。'};
  }
  return Object.freeze({start, ready, handle, tick, isBlocking: () => blocking});
})();
// END VIDDock update bundle
if(typeof importScripts==='function'&&globalThis.VidDockUpdates){
  void VidDockUpdates.start({
    request:(path,method='GET',data={})=>helperRequest({path,method,data},batchSender()),
    busy:updateBusyReason,
    trusted:trustedPanel,
  });
}
