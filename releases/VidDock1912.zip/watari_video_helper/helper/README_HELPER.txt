VidDock

初回はVidDockSetup.exeを開き、画面の案内に沿ってインストールしてください。
GitHubへのログインや、コマンドの入力は不要です。

以後は自動更新、またはVidDockの「アプリの更新」から更新できます。
接続できない場合は、VidDockSetup.exeで修復してください。
