#!/usr/bin/env python3
"""Private GitHub updates with durable rollback and verified helper restart."""
from __future__ import annotations
import base64, hashlib, io, json, os, re, shutil, subprocess, threading, time, uuid, zipfile
from pathlib import Path
VERSION='1.9.12'
REPO='watari-naru/viddock'
APP=Path(__file__).resolve().parent
EXTENSION_PATH=APP/'extension_path.txt'
STATE_PATH=APP/'update_status.json'
JOURNAL=APP/'update_transaction.json'
RESTART=APP/'restart.request'
LOCK=threading.RLock()
ACTIVE=False
MAX_ZIP_BYTES=800000
MAX_UNPACKED=8*1024*1024
ROOT_FILES={'manifest.json','background.js','panel.js','panel.css','sidepanel.html','scan.js','hls.js','style.css','README.md','RELEASE_NOTES.txt','LICENSE-INFO.txt'}
HELPER_FILES={'youtube_helper.py','updater.py','runner.py','native_host.py','install_autostart.ps1','install_autostart.bat','start_helper.bat','uninstall_autostart.ps1','uninstall_autostart.bat','repair_connection.bat','publish_release.py','publish_release.bat','first_setup.bat','setup_github.bat','README_HELPER.txt'}
REQUIRED={'manifest.json','background.js','panel.js','sidepanel.html','helper/youtube_helper.py','helper/updater.py','helper/runner.py','helper/native_host.py'}

def load(path):
    try:
        obj=json.loads(path.read_text(encoding='utf-8-sig'))
        return obj if isinstance(obj,dict) else {}
    except (OSError,ValueError):return {}

def atomic_json(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with tmp.open('w',encoding='utf-8') as f:
            json.dump(obj,f,ensure_ascii=False);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:tmp.unlink(missing_ok=True)

def status():return load(STATE_PATH) or {'state':'idle'}
def _status(**fields):
    with LOCK:atomic_json(STATE_PATH,{**status(),**fields,'updatedAt':int(time.time())})

def version_tuple(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d+\.\d+\.\d+',value):raise ValueError('Invalid release version')
    result=tuple(map(int,value.split('.')))
    if any(n>65535 for n in result):raise ValueError('Version exceeds Chrome limit')
    return result

def extension_dir():
    root=Path(EXTENSION_PATH.read_text(encoding='utf-8-sig').strip())
    if not root.is_absolute() or root.is_symlink() or load(root/'manifest.json').get('name')!='VidDock':raise RuntimeError('Invalid installation folder. Run VidDockSetup.cmd.')
    return root.resolve()

def installed_version():return load(extension_dir()/'manifest.json').get('version',VERSION)

PUBLIC_BASE='https://raw.githubusercontent.com/watari-naru/viddock/main/'

def public_bytes(path,limit=MAX_ZIP_BYTES,timeout=25):
    """Public GitHub distribution: no GitHub CLI, login, or private tokens."""
    from urllib.parse import urlsplit
    from urllib.error import HTTPError, URLError
    import urllib.request
    if not re.fullmatch(r'(update\.json|releases/VidDock[0-9]+\.zip)',path):
        raise ValueError('Invalid public release path')
    url=PUBLIC_BASE+path
    request=urllib.request.Request(url,headers={'User-Agent':'VidDock/1.9.1','Accept':'application/octet-stream'})
    try:
        with urllib.request.urlopen(request,timeout=timeout) as response:
            resolved=urlsplit(response.geturl())
            if resolved.scheme!='https' or resolved.hostname!='raw.githubusercontent.com':
                raise ValueError('Unexpected release host')
            if response.headers.get('Content-Length') and int(response.headers['Content-Length'])>limit:
                raise ValueError('Release exceeds download limit')
            data=response.read(limit+1)
    except HTTPError as exc:
        if exc.code==404:
            raise RuntimeError('VidDock public release is not published yet.') from None
        raise RuntimeError('Public release HTTP '+str(exc.code)) from None
    except (URLError,TimeoutError) as exc:
        raise RuntimeError('VidDock update network error: '+str(getattr(exc,'reason',exc))) from None
    if len(data)>limit:raise ValueError('Release exceeds download limit')
    return data

def validate_manifest(meta):
    if not isinstance(meta,dict) or meta.get('repo')!=REPO:raise ValueError('Release repository mismatch')
    version_tuple(meta.get('version',''))
    if meta.get('asset')!=f"releases/VidDock{meta['version'].replace('.', '')}.zip" or not re.fullmatch(r'[0-9a-f]{64}',str(meta.get('sha256',''))):raise ValueError('Invalid release path or SHA256')
    return {**meta,'notes':str(meta.get('notes',''))[:500]}

def check_update():
    current=installed_version()
    meta=validate_manifest(json.loads(public_bytes('update.json',limit=65536).decode('utf-8-sig')))
    return {'currentVersion':current,'helperVersion':VERSION,'latestVersion':meta['version'],'available':version_tuple(meta['version'])>version_tuple(current),'notes':meta['notes'],'metadata':meta}

def _allowed_file(parts):
    if len(parts)==1:return parts[0] in ROOT_FILES
    if len(parts)==2 and parts[0]=='helper':return parts[1] in HELPER_FILES
    return len(parts)==2 and parts[0]=='icons' and bool(re.fullmatch(r'icon(16|32|48|128)\.png',parts[1]))

def unpack_payload(content,stage,expected_version):
    if len(content)>MAX_ZIP_BYTES:raise ValueError('ZIP exceeds size limit')
    stage.mkdir(parents=True,exist_ok=True)
    extracted=[];seen=set();total=0
    with zipfile.ZipFile(io.BytesIO(content)) as z:
        if len(z.infolist())>150:raise ValueError('Too many ZIP entries')
        for info in z.infolist():
            if info.is_dir():continue
            parts=tuple(info.filename.split('/'));normalized=info.filename.casefold()
            if len(parts)<2 or parts[0]!='watari_video_helper' or not _allowed_file(parts[1:]) or normalized in seen or (info.external_attr>>16)&0o170000==0o120000:raise ValueError('Unsafe/duplicate ZIP entry: '+info.filename[:100])
            seen.add(normalized);total+=info.file_size
            if total>MAX_UNPACKED or info.file_size>2*1024*1024:raise ValueError('ZIP expansion limit')
            dest=stage.joinpath(*parts[1:]);dest.parent.mkdir(parents=True,exist_ok=True)
            data=z.read(info)
            if dest.suffix=='.py':compile(data,str(dest),'exec')
            dest.write_bytes(data);extracted.append((dest,parts[1:]))
    if not REQUIRED.issubset({'/'.join(p) for _,p in extracted}):raise ValueError('Required files missing')
    m=load(stage/'manifest.json')
    if m.get('version')!=expected_version or m.get('name')!='VidDock' or m.get('manifest_version')!=3:raise ValueError('Extension manifest mismatch')
    return extracted

def replace_file(source,target):
    target.parent.mkdir(parents=True,exist_ok=True)
    tmp=target.with_name(target.name+'.watari-new')
    try:shutil.copy2(source,tmp);os.replace(tmp,target)
    finally:tmp.unlink(missing_ok=True)

def rollback(reason):
    tx=load(JOURNAL);errors=[]
    for entry in reversed(tx.get('entries',[])):
        try:
            dest=Path(entry['target'])
            if entry['backup']:replace_file(Path(entry['backup']),dest)
            else:dest.unlink(missing_ok=True)
        except OSError as exc:errors.append(str(exc))
    if errors:
        _status(state='failed',message='Rollback incomplete; run VidDockSetup.cmd. Backups retained.',percent=0)
        raise RuntimeError('Rollback incomplete')
    atomic_json(JOURNAL,{**tx,'phase':'rolled_back'});RESTART.unlink(missing_ok=True)
    _status(state='failed',message=reason[:350],percent=0)

def recover_interrupted():
    if load(JOURNAL).get('phase')=='applying':rollback('Interrupted update restored to previous version.')

def clean_extension_runtime(root):
    """Remove legacy Python-only files from Chrome's unpacked extension directory."""
    root=Path(root)
    if not (root/'manifest.json').is_file():
        raise RuntimeError('Cannot clean an extension without manifest.json')
    legacy=root/'helper'
    if legacy.is_symlink():
        raise RuntimeError('Unexpected symlink under Chrome extension')
    if legacy.is_dir():
        shutil.rmtree(legacy)
    for cache in sorted(root.rglob('__pycache__'),key=lambda p:len(p.parts),reverse=True):
        if cache.is_symlink():
            raise RuntimeError('Unexpected symlink in Chrome extension')
        if cache.is_dir():shutil.rmtree(cache)

def confirm_restart(running_version):
    tx=load(JOURNAL)
    if tx.get('phase')!='awaiting_restart':return
    if tx.get('version')!=running_version:raise RuntimeError('Restart version mismatch')
    clean_extension_runtime(extension_dir())
    atomic_json(JOURNAL,{**tx,'phase':'committed'})
    _status(state='done',version=running_version,percent=100,message='更新完了。補助ツールの再起動を確認しました。')

def apply_update(*,reserved=False):
    global ACTIVE
    with LOCK:
        if ACTIVE and not reserved:raise RuntimeError('Update already running')
        if load(JOURNAL).get('phase') in ('applying','awaiting_restart'):raise RuntimeError('Previous update is unfinished')
        ACTIVE=True
    try:
        _status(state='running',percent=0,message='GitHubの更新情報を確認中...',version='')
        result=check_update()
        if not result['available']:
            _status(state='done',percent=100,version=result['currentVersion'],message='最新版です。')
            return {'updated':False}
        root=extension_dir();meta=result['metadata']
        _status(state='running',percent=15,message='更新パッケージを取得中...')
        binary=public_bytes(meta['asset'],timeout=70)
        if hashlib.sha256(binary).hexdigest()!=meta['sha256']:raise ValueError('SHA256 mismatch: update rejected')
        folder=APP/'updates'/uuid.uuid4().hex
        extracted=unpack_payload(binary,folder/'stage',meta['version'])
        if load(root/'manifest.json').get('key')!=load(folder/'stage'/'manifest.json').get('key'):raise ValueError('Extension identity changed. Run installer instead')
        entries=[]
        for src,rel in extracted:
            # Keep Python helpers outside Chrome; only extension files go to Extension/.
            if rel[0]=='helper':
                if len(rel)==2 and rel[1].endswith('.py'):targets=[APP/rel[1]]
                else:continue
            else:targets=[root.joinpath(*rel)]
            for target in targets:
                if target.is_symlink() or any(p.is_symlink() for p in target.parents):raise ValueError('Linked update target rejected')
                backup=folder/'backup'/str(len(entries)) if target.exists() else None
                if backup:backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,backup)
                entries.append({'source':str(src),'target':str(target),'backup':str(backup) if backup else None})
        tx={'phase':'applying','version':meta['version'],'entries':entries}
        atomic_json(JOURNAL,tx)
        _status(state='running',percent=60,message='バックアップを保存して更新中...')
        try:
            for item in entries:replace_file(Path(item['source']),Path(item['target']))
        except Exception:rollback('Update failed. Previous version restored.');raise
        # A fast update can preserve file size and 1-second mtime, allowing
        # Python's timestamp-based .pyc cache to load the PREVIOUS updater
        # source on Windows. Remove generated bytecode before restarting.
        cache=APP/'__pycache__'
        if cache.is_dir():
            shutil.rmtree(cache)
        atomic_json(JOURNAL,{**tx,'phase':'awaiting_restart'})
        _status(state='restarting',percent=90,version=meta['version'],message='補助ツールを再起動中...')
        RESTART.write_text(meta['version'],encoding='ascii')
        return {'updated':True,'version':meta['version']}
    except Exception as exc:_status(state='failed',percent=0,message=str(exc)[:350]);raise
    finally:
        with LOCK:ACTIVE=False

def start_update():
    global ACTIVE
    with LOCK:
        if ACTIVE or load(JOURNAL).get('phase') in ('applying','awaiting_restart'):raise RuntimeError('An update is already in progress')
        ACTIVE=True;_status(state='running',percent=0,version='',message='更新を準備中...')
    def worker():
        try:apply_update(reserved=True)
        except Exception:pass
    try:threading.Thread(target=worker,daemon=True).start()
    except Exception:
        with LOCK:ACTIVE=False
        raise
