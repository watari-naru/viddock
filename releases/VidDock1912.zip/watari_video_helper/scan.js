// executeScriptに渡す関数は依存のない独立関数として保持する。
function scanPageVideos() {
  const records = [];
  const used = new Set();
  const attr = (selector) => document.querySelector(selector)?.getAttribute('content') || '';
  const metaPoster = attr('meta[property="og:image"]') || attr('meta[name="twitter:image"]') || '';
  const pageTitle = attr('meta[property="og:title"]') || document.title || '';
  const validThumb = (value) => { try {
    const u = new URL(value, location.href); return ['https:', 'http:'].includes(u.protocol) ? u.href : '';
  } catch { return ''; } };
  const add = (url, type, video, thumbnail) => {
    if (!url || !/^https?:\/\//i.test(url) || used.has(url)) return;
    used.add(url);
    records.push({ url, mime: type || '', playing: !!video && !video.paused && !video.ended,
      width: video?.videoWidth || 0, height: video?.videoHeight || 0,
      thumbnail: validThumb(thumbnail || video?.poster || metaPoster), label: pageTitle });
  };
  let hasBlobVideo = false;
  let hasDRM = false;
  for (const video of document.querySelectorAll('video')) {
    if (video.currentSrc?.startsWith('blob:')) hasBlobVideo = true;
    if (video.mediaKeys) hasDRM = true;
    const poster = video.poster || metaPoster;
    add(video.currentSrc, video.getAttribute('type'), video, poster);
    add(video.src, video.getAttribute('type'), video, poster);
    for (const source of video.querySelectorAll('source')) add(source.src, source.type, video, poster);
  }
  // 一部のプレイヤーは<video>を即時生成せず、ページ内の設定JSONに動画URLを保持する。
  // 実行・復号はせず、公開されているDOM文字列内の明示的なメディアURLだけを取得する。
  const scanSnippet = (source) => {
    if (!source || source.length > 300000) return;
    const text = source.replace(/\\\//g, '/').replace(/\\u0026/gi, '&').replace(/&amp;/g, '&');
    const re = /(?:https?:\/\/|\/\/)[^\s"'<>\\]{4,1500}?\.(?:m3u8|mpd|mp4|webm)(?:\?[^\s"'<>\\]{0,500})?/ig;
    let match, scanned = 0;
    while ((match = re.exec(text)) && scanned++ < 80) {
      try { add(new URL(match[0], location.href).href, '', null, metaPoster); } catch { /* ignore */ }
    }
  };
  for (const script of document.querySelectorAll('script:not([src])')) {
    if (records.length >= 85) break;
    scanSnippet(script.textContent || '');
  }
  for (const node of document.querySelectorAll('[data-src], [data-video-src], [data-hls], [data-file]')) {
    for (const key of ['data-src', 'data-video-src', 'data-hls', 'data-file']) {
      const value = node.getAttribute(key);
      if (!value || !/\.(m3u8|mpd|mp4|webm)(?:[?#]|$)/i.test(value)) continue;
      try { add(new URL(value, location.href).href, '', null, metaPoster); } catch { /* ignore */ }
    }
  }
  for (const entry of performance.getEntriesByType('resource')) {
    if (/\.(m3u8|m3u|mpd|mp4|webm)(?:[?#]|$)/i.test(entry.name)) add(entry.name, '', null, metaPoster);
  }
  return { records: records.slice(0, 90), hasBlobVideo, hasDRM,
    hasVideo: !!document.querySelector('video'), pagePoster: validThumb(metaPoster),
    pageTitle, pageUrl: location.href, documentTimeOrigin: performance.timeOrigin };
}
