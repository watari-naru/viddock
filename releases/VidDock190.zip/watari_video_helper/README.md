# VidDock190

Stable non-DRM media download update. Records the actual video-playback Referer Origin User-Agent and Accept-Language in the active tab, and forwards only these allowed headers to the local yt-dlp helper. Cookies and Authorization headers are deliberately never captured or stored. Protects signed URLs in errors, keeps distinct media IDs unique, and synchronizes save folders with the helper before updating Chrome UI. Adds integration tests of header forwarding, duplicate identity, published-version updates, and rollback.

HTTP 403 can still occur if the server requires an authenticated session, DRM license, or other access control; this update does not bypass those restrictions. Browser/site end-to-end behavior is not guaranteed by local tests.
