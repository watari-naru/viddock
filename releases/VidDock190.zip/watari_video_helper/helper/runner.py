"""Single-instance supervisor, verified restart, diagnostics, and rollback."""
from __future__ import annotations
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import updater

ROOT = Path(__file__).resolve().parent
ATTEMPT_LOG = ROOT / 'helper_startup.log'
FAILURE_LOG = ROOT / 'helper_startup_failure.log'


def probe():
    try:
        key = (ROOT / '.pairing_key').read_text(encoding='utf-8-sig').strip()
        request = urllib.request.Request('http://127.0.0.1:18763/api/status',
                                         headers={'X-Watari-Token': key})
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request, timeout=1) as response:
            return json.load(response)
    except (OSError, ValueError):
        return {}


def log(message):
    try:
        with (ROOT / 'supervisor.log').open('a', encoding='utf-8') as handle:
            handle.write(time.ctime() + ' ' + message + '\n')
    except OSError:
        pass


def startup_failure(child):
    """Keep the failed process trace even after the old version starts again."""
    try:
        shutil.copy2(ATTEMPT_LOG, FAILURE_LOG)
        lines = FAILURE_LOG.read_text(encoding='utf-8', errors='replace').splitlines()
        relevant = [line for line in lines if line.strip()]
        detail = ' | '.join(relevant[-4:])
    except OSError as exc:
        detail = 'Could not read startup log: ' + str(exc)
    code = child.returncode
    log('Helper startup failure, exit code=' + str(code) + ', trace=' + detail[:700])
    return ('exit=' + str(code) + ' / ' + detail[-230:]).strip()


def stop_child(child):
    if child.poll() is None:
        try:
            child.terminate()
        except OSError:
            pass
    try:
        child.wait(timeout=8)
    except subprocess.TimeoutExpired:
        child.kill()
        child.wait(timeout=8)


def main():
    lock = (ROOT / 'supervisor.lock').open('a+b')
    try:
        lock.seek(0)
        lock.write(b'0')
        lock.flush()
        lock.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        return
    (ROOT / 'supervisor.pid').write_text(str(os.getpid()), encoding='ascii')
    updater.recover_interrupted()
    interpreter = Path(sys.executable)
    if interpreter.name.lower() == 'pythonw.exe':
        interpreter = interpreter.with_name('python.exe')
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.name == 'nt' else 0
    failures = 0
    while failures < 6:
        updater.RESTART.unlink(missing_ok=True)
        # The old helper has exited before launching a replacement; retain
        # the failed child's stderr instead of silently discarding it.
        with ATTEMPT_LOG.open('wb') as error_log:
            child = subprocess.Popen([str(interpreter), str(ROOT / 'youtube_helper.py')],
                                     cwd=ROOT, stdin=subprocess.DEVNULL,
                                     stdout=error_log, stderr=subprocess.STDOUT,
                                     creationflags=flags)
        (ROOT / 'helper.pid').write_text(str(child.pid), encoding='ascii')
        ready = {}
        for _ in range(80):
            time.sleep(.25)
            if child.poll() is not None:
                break
            ready = probe()
            if ready.get('pid') == child.pid and ready.get('ok'):
                break
        if ready.get('pid') != child.pid:
            stop_child(child)
            detail = startup_failure(child)
            if updater.load(updater.JOURNAL).get('phase') == 'awaiting_restart':
                updater.rollback('New helper could not start (' + detail[:170] +
                                 '). Previous version restored. See helper_startup_failure.log')
                log('Update rolled back')
                continue
            log('Helper could not start. Verify port 18763 and helper_startup_failure.log.')
            return
        try:
            updater.confirm_restart(ready.get('version', ''))
        except (RuntimeError, OSError, ValueError) as exc:
            stop_child(child)
            log('Restart confirmation failed: ' + str(exc))
            updater.rollback('New helper restart confirmation failed: ' + str(exc)[:160])
            continue
        log('Helper ready: ' + str(ready.get('version')) + ', pid=' + str(child.pid))
        child.wait()
        if updater.RESTART.exists():
            continue
        failures += 1
        log('Helper exited unexpectedly (exit ' + str(child.returncode) + '); retrying')
        time.sleep(2)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        log('Supervisor error: ' + repr(exc))
