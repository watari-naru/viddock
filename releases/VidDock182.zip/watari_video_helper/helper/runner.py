"""Single-instance supervisor with verified restart and rollback."""
from __future__ import annotations
import json, os, subprocess, sys, time, urllib.request
from pathlib import Path
import updater
ROOT=Path(__file__).resolve().parent

def probe():
    try:
        key=(ROOT/'.pairing_key').read_text(encoding='utf-8-sig').strip()
        req=urllib.request.Request('http://127.0.0.1:18763/api/status',headers={'X-Watari-Token':key})
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=1) as response:return json.load(response)
    except (OSError,ValueError):return {}

def log(text):
    with (ROOT/'supervisor.log').open('a',encoding='utf-8') as f:f.write(time.ctime()+' '+text+'\n')

def main():
    lock=(ROOT/'supervisor.lock').open('a+b')
    try:
        lock.seek(0);lock.write(b'0');lock.flush();lock.seek(0)
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except OSError:return
    (ROOT/'supervisor.pid').write_text(str(os.getpid()),encoding='ascii')
    updater.recover_interrupted()
    interpreter=Path(sys.executable)
    if interpreter.name.lower()=='pythonw.exe':interpreter=interpreter.with_name('python.exe')
    flags=getattr(subprocess,'CREATE_NO_WINDOW',0) if os.name=='nt' else 0
    failures=0
    while failures<6:
        updater.RESTART.unlink(missing_ok=True)
        child=subprocess.Popen([str(interpreter),str(ROOT/'youtube_helper.py')],cwd=ROOT,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=flags)
        (ROOT/'helper.pid').write_text(str(child.pid),encoding='ascii')
        ready={}
        for _ in range(40):
            time.sleep(.25)
            if child.poll() is not None:break
            ready=probe()
            if ready.get('pid')==child.pid and ready.get('ok'):break
        if ready.get('pid')!=child.pid:
            child.terminate();child.wait(timeout=8)
            if updater.load(updater.JOURNAL).get('phase')=='awaiting_restart':
                updater.rollback('New helper could not start. Previous version restored.');log('Update rolled back');continue
            log('Helper failed to start. Port may be in use.');return
        try:updater.confirm_restart(ready.get('version',''))
        except RuntimeError:
            child.terminate();child.wait(timeout=8);updater.rollback('New helper version mismatch. Previous version restored.');continue
        log('Helper ready: '+str(ready.get('version')))
        child.wait()
        if updater.RESTART.exists():continue
        failures+=1;log('Helper exited unexpectedly; retrying');time.sleep(2)

if __name__=='__main__':
    try:main()
    except Exception as exc:log('Supervisor error: '+str(exc))
