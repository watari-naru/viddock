"""Authenticated Chrome Native Messaging bootstrap; no web-page token access."""
from __future__ import annotations
import json, os, struct, subprocess, sys, time
from pathlib import Path
import runner
ROOT=Path(__file__).resolve().parent
ORIGIN='chrome-extension://fkdjednhijimbbelplimgojldphcoaij/'

def read_exact(stream,size):
    result=b''
    while len(result)<size:
        part=stream.read(size-len(result))
        if not part:raise EOFError('Truncated native message')
        result+=part
    return result

def handle(request):
    if request!={'action':'connect'}:raise ValueError('Unsupported native request')
    if not runner.probe().get('ok'):
        interpreter=Path(sys.executable)
        if os.name=='nt' and interpreter.with_name('pythonw.exe').is_file():interpreter=interpreter.with_name('pythonw.exe')
        subprocess.Popen([str(interpreter),str(ROOT/'runner.py')],cwd=ROOT,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0) if os.name=='nt' else 0)
        for _ in range(50):
            if runner.probe().get('ok'):break
            time.sleep(.2)
        else:raise RuntimeError('Helper did not start. Run VidDockSetup.cmd to repair.')
    return {'ok':True,'token':(ROOT/'.pairing_key').read_text(encoding='utf-8-sig').strip()}

def main():
    if len(sys.argv)<2 or sys.argv[1].rstrip('/')!=ORIGIN.rstrip('/'):return
    if os.name=='nt':
        import msvcrt
        msvcrt.setmode(sys.stdin.fileno(),os.O_BINARY);msvcrt.setmode(sys.stdout.fileno(),os.O_BINARY)
    try:
        size=struct.unpack('=I',read_exact(sys.stdin.buffer,4))[0]
        if not 0<size<=1024:raise ValueError('Native request too large')
        result=handle(json.loads(read_exact(sys.stdin.buffer,size)))
    except Exception as exc:result={'ok':False,'error':str(exc)[:250]}
    data=json.dumps(result,ensure_ascii=False).encode('utf-8')
    sys.stdout.buffer.write(struct.pack('=I',len(data))+data);sys.stdout.buffer.flush()

if __name__=='__main__':main()
