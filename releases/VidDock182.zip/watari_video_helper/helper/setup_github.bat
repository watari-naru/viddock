@echo off
setlocal
set "GH=gh"
where gh.exe >nul 2>nul
if errorlevel 1 (
  if exist "%ProgramFiles%\GitHub CLI\gh.exe" (
    set "GH=%ProgramFiles%\GitHub CLI\gh.exe"
  ) else (
    echo [Watari] Installing GitHub CLI...
    winget install --id GitHub.cli --exact --source winget
    if errorlevel 1 goto :error
    if exist "%ProgramFiles%\GitHub CLI\gh.exe" (
      set "GH=%ProgramFiles%\GitHub CLI\gh.exe"
    ) else (
      echo GitHub CLI installed. Reopen Command Prompt, then run this file again.
      pause
      exit /b 0
    )
  )
)
"%GH%" auth status >nul 2>nul
if errorlevel 1 (
  echo Sign in to the GitHub account that can access watari-naru/videodownloader.
  "%GH%" auth login --hostname github.com --git-protocol https --web --scopes repo
  if errorlevel 1 goto :error
)
echo.
echo [Watari] GitHub authentication OK. You can now check for updates.
pause
exit /b 0
:error
echo [ERROR] GitHub setup did not complete. See the error above.
pause
exit /b 1
