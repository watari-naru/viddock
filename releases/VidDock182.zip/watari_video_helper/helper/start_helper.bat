@echo off
start "" "%LOCALAPPDATA%\WatariVideoHelper\Runtime\Scripts\pythonw.exe" "%LOCALAPPDATA%\WatariVideoHelper\runner.py"
