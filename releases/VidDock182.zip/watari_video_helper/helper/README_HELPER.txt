Watari Video Helper v1.5.0

1) Windows: install GitHub CLI: winget install --id GitHub.cli
2) In PowerShell or CMD: gh auth login
   -> GitHub.com -> HTTPS -> Login with browser. Access to the private repo is required.
3) Run install_autostart.bat ONCE after copying the v1.5.0 files over the current Chrome unpacked extension folder.
4) Update manager is under "Other" > "App Updates" in Chrome side panel.
5) Initial GitHub publisher (developer only): run publish_release.bat once to publish source, ZIP, then update.json.

Github credentials are managed by GitHub CLI; never paste a token into the browser extension.
DRM decryption is not included.

New PC: Install from private GitHub with installer.ps1 after gh auth login.
