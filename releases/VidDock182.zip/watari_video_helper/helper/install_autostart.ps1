throw 'This installer is obsolete. Use Setup-Watari.cmd from the repository.'
