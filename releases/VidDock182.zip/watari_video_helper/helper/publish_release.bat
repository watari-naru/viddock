@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% == 0 (
  py -3 "%~dp0publish_release.py"
) else (
  python "%~dp0publish_release.py"
)
echo.
pause
