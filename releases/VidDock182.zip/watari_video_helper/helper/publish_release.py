#!/usr/bin/env python3
"""One-time private GitHub publication via the user's local gh login.

Never stores or prints GitHub tokens. Publishes update.json LAST so clients
cannot see a new version until the payload has been uploaded successfully.
"""
from __future__ import annotations
import base64
import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import updater

REPO = updater.REPO
ROOT = Path(__file__).resolve().parent.parent


def run_gh(*args: str, input_data: bytes | None = None, allow_missing: bool = False) -> dict | None:
    gh = updater.gh_executable()
    if not gh:
        raise RuntimeError('GitHub CLIがありません。winget install --id GitHub.cli を実行してください。')
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.name == 'nt' else 0
    p = subprocess.run([gh, 'api', '-H', 'Accept: application/vnd.github+json', *args],
                       input=input_data, capture_output=True, timeout=100, creationflags=flags)
    if p.returncode:
        err = p.stderr.decode('utf-8', errors='replace')
        if allow_missing and ('404' in err or 'Not Found' in err):
            return None
        raise RuntimeError(f'GitHub API error: {err[-350:]}')
    return json.loads(p.stdout)


def put_file(repo_path: str, content: bytes, message: str, *, immutable=False) -> bool:
    endpoint = f'repos/{REPO}/contents/{repo_path}'
    old = run_gh(endpoint, allow_missing=True)
    if old and immutable:
        same = old.get('sha') == git_blob_sha(content)
        if same:
            return False
        raise RuntimeError(f'{repo_path} はすでに存在します。配布済みのバージョンは上書きできません。')
    if old and old.get('sha') == git_blob_sha(content):
        return False
    payload = {'message': message, 'content': base64.b64encode(content).decode('ascii'),
               'branch': 'main'}
    if old:
        payload['sha'] = old['sha']
    run_gh('-X', 'PUT', endpoint, '--input', '-', input_data=json.dumps(payload).encode('utf-8'))
    return True


def git_blob_sha(b: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\x00' + b).hexdigest()


def package_zip() -> tuple[Path, str, str]:
    manifest = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
    version = manifest['version']
    updater.version_tuple(version)
    output = ROOT.parent / f'Watari_Video_Helper_v{version}.zip'
    sources = []
    for src in sorted(ROOT.rglob('*')):
        if not src.is_file():
            continue
        rel = src.relative_to(ROOT).parts
        if updater._allowed_file(rel):
            sources.append(src)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for src in sources:
            z.write(src, '/'.join((updater.APP_FOLDER, *src.relative_to(ROOT).parts)))
    return output, version, hashlib.sha256(output.read_bytes()).hexdigest()


def publish() -> None:
    pkg, version, sha = package_zip()
    print('GitHub private repository:', REPO)
    print('Package:', pkg.name, f'{pkg.stat().st_size:,} bytes')
    print('First authenticate with: gh auth login (required only once)')
    # Check token without displaying it.
    gh = updater.gh_executable()
    if not gh: raise RuntimeError('GitHub CLIがありません。winget install --id GitHub.cli を実行してください。')
    status = subprocess.run([gh, 'auth', 'status'], capture_output=True, text=True)
    if status.returncode:
        raise RuntimeError('GitHubへのログインが必要です。コマンド gh auth login を実行してください。')
    print('Publishing source files...')
    for src in sorted(ROOT.rglob('*')):
        if not src.is_file():
            continue
        rel = src.relative_to(ROOT).parts
        if updater._allowed_file(rel):
            path = 'src/' + '/'.join(rel)
            if put_file(path, src.read_bytes(), f'src: update {path} for v{version}'):
                print(' ', path)
    print('Publishing immutable package...')
    put_file(f'releases/{pkg.name}', pkg.read_bytes(), f'release: {version}', immutable=True)
    meta = {'repo': REPO, 'version': version, 'asset': f'releases/{pkg.name}',
            'sha256': sha, 'notes': f'Watari Video Helper v{version} / private GitHub update'}
    # Never advertise a version until the ZIP has been published.
    print('Publishing update.json...')
    put_file('update.json', (json.dumps(meta, ensure_ascii=False, indent=2) + '\n').encode('utf-8'),
             f'update: publish v{version}')
    print('SUCCESS: update.json -> v' + version)
    print('https://github.com/' + REPO)


if __name__ == '__main__':
    try:
        publish()
    except Exception as error:
        print('ERROR:', str(error))
        sys.exit(1)
