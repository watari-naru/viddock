@echo off
echo Use Setup-Watari.cmd from the repository for installation or repair.
start "" https://github.com/watari-naru/videodownloader
pause
