$runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
Remove-ItemProperty -Path $runKey -Name 'WatariVideoHelper' -ErrorAction SilentlyContinue
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
  Where-Object { $_.Name -in @('python.exe', 'pythonw.exe') -and $_.CommandLine -match 'youtube_helper\.py' -and $_.CommandLine -match 'WatariVideoHelper' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Write-Host 'Autostart entry removed. You can delete %LOCALAPPDATA%\WatariVideoHelper manually.'
