/* HLSプレイリストの安全な解析。FFmpegや遠隔スクリプトの読み込みは不要。 */
'use strict';

const HLS = (() => {
  const splitLines = (text) => text.replace(/\r/g, '').split('\n').map((line) => line.trim()).filter(Boolean);
  const absolute = (path, base) => new URL(path, base).href;

  function parseAttrs(line) {
    const attrs = {};
    const body = line.substring(line.indexOf(':') + 1);
    const regex = /([A-Z][A-Z0-9-]*)=("(?:[^"\\]|\\.)*"|[^,]*)/g;
    let match;
    while ((match = regex.exec(body)) !== null) {
      const str = match[2].trim();
      attrs[match[1]] = str.startsWith('"') && str.endsWith('"') ? str.slice(1, -1) : str;
    }
    return attrs;
  }

  function parseMaster(text, base) {
    const lines = splitLines(text);
    if (!lines[0]?.startsWith('#EXTM3U')) throw new Error('有効なM3U8ではありません。');
    const variants = [];
    const audioGroups = new Map();
    for (const line of lines) {
      if (!line.startsWith('#EXT-X-MEDIA:')) continue;
      const attrs = parseAttrs(line);
      if (attrs.TYPE === 'AUDIO' && attrs['GROUP-ID'] && attrs.URI) audioGroups.set(attrs['GROUP-ID'], attrs.URI);
    }
    let pending = null;
    for (const line of lines) {
      if (line.startsWith('#EXT-X-SESSION-KEY:')) {
        const attrs = parseAttrs(line);
        if (attrs.METHOD && attrs.METHOD !== 'NONE') throw new Error('暗号化されたHLSには対応していません。');
      }
      if (line.startsWith('#EXT-X-STREAM-INF:')) { pending = parseAttrs(line); continue; }
      if (pending && !line.startsWith('#')) {
        const resolution = pending.RESOLUTION || '';
        const bandwidth = Number(pending['AVERAGE-BANDWIDTH'] || pending.BANDWIDTH || '0');
        const label = `${resolution || '自動'}${bandwidth ? ` · ${Math.round(bandwidth / 1000)} kbps` : ''}`;
        variants.push({ url: absolute(line, base), bandwidth, resolution, label,
          separateAudio: audioGroups.has(pending.AUDIO) });
        pending = null;
      }
    }
    return variants.sort((a, b) => {
      const height = v => Number((v.resolution || '').split('x')[1]) || 0;
      return height(b) - height(a) || b.bandwidth - a.bandwidth;
    });
  }

  function parseMedia(text, base) {
    const lines = splitLines(text);
    if (!lines[0]?.startsWith('#EXTM3U')) throw new Error('有効なM3U8ではありません。');
    if (!lines.some((line) => line === '#EXT-X-ENDLIST')) {
      throw new Error('ライブ配信・配信途中のプレイリストには未対応です（#EXT-X-ENDLIST がありません）。');
    }
    const segments = [];
    let initSegment = null;
    let pendingSegment = false;
    let currentMapUri = null;
    for (const line of lines) {
      if (line.startsWith('#EXT-X-KEY:')) {
        const attrs = parseAttrs(line);
        if (attrs.METHOD && attrs.METHOD !== 'NONE') throw new Error('暗号化されたHLSには対応していません。');
      }
      if (line.startsWith('#EXT-X-BYTERANGE:')) {
        throw new Error('バイトレンジ方式のHLSには未対応です。');
      }
      if (line.startsWith('#EXT-X-DISCONTINUITY')) {
        throw new Error('分割形式が切り替わるHLSには未対応です。');
      }
      if (line.startsWith('#EXT-X-MAP:')) {
        const attrs = parseAttrs(line);
        if (attrs.BYTERANGE) throw new Error('バイトレンジ方式のHLSには未対応です。');
        if (!attrs.URI) throw new Error('初期化セグメントのURLが不正です。');
        const candidate = absolute(attrs.URI, base);
        if (currentMapUri && candidate !== currentMapUri) throw new Error('初期化セグメントの途中切り替えには未対応です。');
        currentMapUri = candidate;
        initSegment = candidate;
      }
      if (line.startsWith('#EXTINF:')) { pendingSegment = true; continue; }
      if (!line.startsWith('#') && pendingSegment) {
        segments.push(absolute(line, base));
        pendingSegment = false;
      }
    }
    if (!segments.length) throw new Error('動画セグメントがありません。');
    const firstPath = new URL(segments[0]).pathname.toLowerCase();
    if (!initSegment && /\.(m4s|cmfv|mp4)$/.test(firstPath)) {
      throw new Error('MP4の初期化セグメントが見つかりません。');
    }
    const extension = initSegment ? 'mp4' : 'ts';
    return { segments, initSegment, extension, count: segments.length };
  }

  async function fetchText(url, signal) {
    const response = await fetch(url, { signal, credentials: 'include', cache: 'no-store' });
    if (!response.ok) throw new Error(`M3U8を取得できませんでした（HTTP ${response.status}）。`);
    return response.text();
  }

  async function resolve(url, signal, depth = 0) {
    if (depth > 4) throw new Error('プレイリストの階層が深すぎます。');
    const text = await fetchText(url, signal);
    const variants = parseMaster(text, url);
    if (variants.length) return { variants, sourceUrl: url };
    return { variants: [{ url, label: '元の画質', bandwidth: 0, resolution: '', separateAudio: false }], sourceUrl: url };
  }

  async function resolveMedia(url, signal, depth = 0) {
    if (depth > 4) throw new Error('プレイリストの階層が深すぎます。');
    const text = await fetchText(url, signal);
    const variants = parseMaster(text, url);
    if (variants.length) {
      if (variants[0].separateAudio) throw new Error('音声と映像が別々のHLSは未対応です。');
      return resolveMedia(variants[0].url, signal, depth + 1);
    }
    return parseMedia(text, url);
  }

  return { parseAttrs, parseMaster, parseMedia, resolve, resolveMedia };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = HLS;
