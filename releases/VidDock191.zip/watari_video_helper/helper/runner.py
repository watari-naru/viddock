"""Single-instance supervisor, verified restart, diagnostics, and rollback."""
from __future__ import annotations
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import updater

ROOT = Path(__file__).resolve().parent
ATTEMPT_LOG = ROOT / 'helper_startup.log'
FAILURE_LOG = ROOT / 'helper_startup_failure.log'


def probe():
    try:
        key = (ROOT / '.pairing_key').read_text(encoding='utf-8-sig').strip()
        request = urllib.request.Request('http://127.0.0.1:18763/api/status',
                                         headers={'X-Watari-Token': key})
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request, timeout=1) as response:
            return json.load(response)
    except (OSError, ValueError):
        return {}


def log(message):
    try:
        with (ROOT / 'supervisor.log').open('a', encoding='utf-8') as handle:
            handle.write(time.ctime() + ' ' + message + '\n')
    except OSError:
        pass


def startup_failure(child):
    """Keep the failed process trace even after the old version starts again."""
    try:
        shutil.copy2(ATTEMPT_LOG, FAILURE_LOG)
        lines = FAILURE_LOG.read_text(encoding='utf-8', errors='replace').splitlines()
        relevant = [line for line in lines if line.strip()]
        detail = ' | '.join(relevant[-4:])
    except OSError as exc:
        detail = 'Could not read startup log: ' + str(exc)
    code = child.returncode
    log('Helper startup failure, exit code=' + str(code) + ', trace=' + detail[:700])
    return ('exit=' + str(code) + ' / ' + detail[-230:]).strip()


def stop_child(child):
    if child.poll() is None:
        try:
            child.terminate()
        except OSError:
            pass
    try:
        child.wait(timeout=8)
    except subprocess.TimeoutExpired:
        child.kill()
        child.wait(timeout=8)


def main():
    lock = (ROOT / 'supervisor.lock').open('a+b')
    try:
        lock.seek(0)
        lock.write(b'0')
        lock.flush()
        lock.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        return
    (ROOT / 'supervisor.pid').write_text(str(os.getpid()), encoding='ascii')
    updater.recover_interrupted()
    interpreter = Path(sys.executable)
    if interpreter.name.lower() == 'pythonw.exe':
        interpreter = interpreter.with_name('python.exe')
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.name == 'nt' else 0
    failures = 0
    startup_clean_retries = 0
    while failures < 6:
        # Snapshot transaction *before* starting the child. An update may
        # begin during the initial /api/status health checks; that old child
        # must NOT be confirmed against a transaction created afterwards.
        startup_tx = updater.load(updater.JOURNAL)
        expected_restart = (startup_tx.get('version')
                            if startup_tx.get('phase') == 'awaiting_restart' else None)
        if expected_restart:
            updater.RESTART.unlink(missing_ok=True)
        # The old helper has exited before launching a replacement; retain
        # the failed child's stderr instead of silently discarding it.
        with ATTEMPT_LOG.open('wb') as error_log:
            child = subprocess.Popen([str(interpreter), str(ROOT / 'youtube_helper.py')],
                                     cwd=ROOT, stdin=subprocess.DEVNULL,
                                     stdout=error_log, stderr=subprocess.STDOUT,
                                     creationflags=flags)
        (ROOT / 'helper.pid').write_text(str(child.pid), encoding='ascii')
        ready = {}
        for _ in range(80):
            time.sleep(.25)
            if child.poll() is not None:
                break
            ready = probe()
            if ready.get('pid') == child.pid and ready.get('ok'):
                break
        if ready.get('pid') == child.pid and ready.get('ok'):
            # A single 200 response is not enough: verify that the exact
            # subprocess stays alive. Other installations may share the port.
            time.sleep(.35)
            final_probe = probe()
            if child.poll() is not None or final_probe.get('pid') != child.pid:
                log('Startup probe changed: expected pid=' + str(child.pid) +
                    ', observed=' + str(final_probe.get('pid')) +
                    ', last_version=' + str(final_probe.get('version')))
                ready = {}
        if ready.get('pid') != child.pid:
            stop_child(child)
            state = updater.load(updater.JOURNAL).get('phase')
            # A clean exit after valid HTTP responses can be a second restart
            # request rather than a Python crash. Retry twice before rollback.
            if state == 'awaiting_restart' and child.returncode == 0 and startup_clean_retries < 2:
                startup_clean_retries += 1
                log('Clean helper exit during update; retry=' + str(startup_clean_retries) +
                    ', expected_pid=' + str(child.pid) +
                    ', last_seen_pid=' + str(ready.get('pid')) +
                    ', exit=' + str(child.returncode))
                time.sleep(.5)
                continue
            detail = startup_failure(child)
            if state == 'awaiting_restart':
                updater.rollback('New helper did not become healthy (' + detail[:156] +
                                 '). Previous version restored. See helper_startup_failure.log')
                log('Update rolled back')
                startup_clean_retries = 0
                continue
            log('Helper could not start. Verify port 18763 and helper_startup_failure.log.')
            return
        startup_clean_retries = 0
        script = (ROOT / 'youtube_helper.py').read_text(encoding='utf-8', errors='replace')
        expected = updater.load(updater.JOURNAL).get('version')
        disk_version = (script.split("'version': '", 1)[1].split("'", 1)[0]
                        if "'version': '" in script else '<missing>')
        log('Confirming restart: observed_version=' + str(ready.get('version')) +
            ', journal_version=' + str(expected) +
            ', on_disk_version=' + disk_version +
            ', helper_pid=' + str(child.pid) +
            ', supervisor_updater=' + str(updater.VERSION))
        try:
            if expected_restart:
                updater.confirm_restart(ready.get('version', ''))
            elif updater.load(updater.JOURNAL).get('phase') == 'awaiting_restart':
                log('An update started after helper launch; defer confirmation until the NEW child starts')
        except (RuntimeError, OSError, ValueError) as exc:
            stop_child(child)
            log('Restart confirmation failed: ' + str(exc))
            updater.rollback('New helper restart confirmation failed: ' + str(exc)[:160])
            continue
        log('Helper ready: ' + str(ready.get('version')) + ', pid=' + str(child.pid))
        child.wait()
        if updater.RESTART.exists():
            continue
        failures += 1
        log('Helper exited unexpectedly (exit ' + str(child.returncode) + '); retrying')
        time.sleep(2)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        log('Supervisor error: ' + repr(exc))
