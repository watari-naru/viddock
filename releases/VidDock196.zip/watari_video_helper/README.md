# VidDock
VidDock is a video detector and non-DRM MP4 downloader for Chrome with a Windows local helper.

## Distribution
Development remains private in `watari-naru/videodownloader`.
The public `watari-naru/viddock` repository will contain only a versioned ZIP, update.json and setup files. Friends need no GitHub account.

## One-time owner action
The owner runs `VidDockPublish.cmd` after v1.8.0 has passed CI. That command uses the owner's existing GitHub CLI login to create the Public release repository and uploads the tested binary, hash metadata, and public installer. No token is stored in this code or the public repository.

## Friend setup
From `https://github.com/watari-naru/viddock/releases/latest`, run `VidDockSetup.cmd`.
Chrome: load `%LOCALAPPDATA%\\VidDock\\Extension` using chrome://extensions.
Old installations under `%LOCALAPPDATA%\\WatariVideoHelper` keep their path and settings during migration. The extension ID remains stable.

## Updating
The right side panel offers 'Check update' and 'Update'. The helper reads the public update.json and ZIP anonymously over HTTPS, validates the SHA256 digest and release manifest, backs up previous files, then restarts and checks the new helper version. Active video downloads prevent updates.
Private GitHub login is not used by end-user installers or the updater.

## Caveats
No DRM circumvention. Video access depends on each website and user permissions. Chrome requires the unpacked extension to be loaded manually on first installation. Unsigned CMD/PowerShell files may trigger Windows security warnings.

## v1.8.1

- Chrome service worker automatically reconnects to the native helper after a failed read-only HTTP request. POST requests are never silently retried.
- TokyoMotion MP4 cards use the local helper with the video-page Referer instead of extension-origin Range preflight.
- HTTP 403 is reported as a potential website restriction, not an assumed expired link. DRM-protected or access-restricted streams are not bypassed.

## VidDock182 optional Cloudflare impersonation support

- Official yt-dlp extra: `pip install -U "yt-dlp[default,curl-cffi]"` in the isolated VidDock runtime, not system Python.
- Fresh installs receive the extra automatically. Existing v1.8.1 installs can update from Chrome and the v1.8.2 helper performs a one-time nonblocking local dependency repair on startup when needed.
- A verified Cloudflare anti-bot challenge on a generic/TokyoMotion downloader triggers exactly one official `--extractor-args generic:impersonate` retry. All other errors fail without automated retries.
- A site can still deny requests. VidDock does not decrypt DRM or defeat website access-control policies.

## VidDock183: restart repair and diagnostics

- Fixes a Windows update failure that previously only displayed "New helper could not start. Previous version restored."
- Starts the HTTP helper and verifies its version **before** an optional curl_cffi install. An existing yt-dlp installation is no longer upgraded while the helper is starting.
- Saves stdout/stderr from failed startup in `helper_startup_failure.log`, and keeps `supervisor.log`.
- Clears generated Python bytecode before restarting to avoid stale versions.
- Keeps the same Extension folder identity, local credentials, download history, and rollback guarantees.
- Adds an integration test upgrading from the previously published VidDock182 archive.

### If VidDock182 previously rolled back

**Use the updated `VidDockSetup.cmd` once to repair**. The running supervisor may still be the old version, so its new diagnostics will not take effect until it restarts. Do not delete the app folder or download history.

Common locations:
`%LOCALAPPDATA%\VidDock` and `%LOCALAPPDATA%\WatariVideoHelper`.

If the repair still fails, inspect `supervisor.log` and `helper_startup_failure.log` in the app folder, then remove any personal paths or tokens before sharing excerpts.

## VidDock190

Improves HLS playlist requests by forwarding the original player request headers (Referer Origin User-Agent Accept-Language) to yt-dlp. Does not capture or export cookies/authorization. Fixes save-folder synchronization and signed-URL diagnostic redaction. Does not bypass site access restrictions, PPV authorization, or DRM.

## VidDock191 - restart and rollback reliability

The v1.9.0 local update could report "New helper could not start (exit=0)" even after HTTP 200 health responses. In the prior implementation a pending restart request could trigger the newly started helper to shut itself down. In v1.9.1, the helper only exits if a strictly newer version is requested. The supervisor checks the actual child PID twice and allows at most two retries for clean exits during an update, preserving rollback for persistent failures.

Automated tests now include a live helper started with an existing same-version restart marker, an older marker, a newer-version shutdown, and a published VidDock190 -> VidDock191 integration upgrade. Initial repair on Windows can be performed by rerunning the current `VidDockSetup.cmd`; this restarts the previously loaded supervisor as well as replacing the helper files. Video-site HTTP403 access restrictions are unrelated and may continue.

## VidDock192

Download jobs now have a local status journal. If the helper restarts, a queued or running job is shown as interrupted at its last saved progress instead of disappearing. Runtime exit logs are kept for troubleshooting. Please check the destination folder before retrying a failed transfer.
