#!/usr/bin/env python3
"""VidDock local non-DRM download companion.

Runs only on 127.0.0.1; validates a persistent pairing token and strict
YouTube video URLs. Uses yt-dlp for non-DRM media; does not decrypt DRM.
"""
from __future__ import annotations

import hmac
import math
from collections import deque
import ipaddress
import importlib
import importlib.util
import importlib.metadata
import json
import os
import re
import secrets
import shutil
import tempfile
import subprocess
import time
import sys
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse, urlunparse, parse_qsl, urlencode
import updater

PORT = 18763
HOST = '127.0.0.1'
KEY_PATH = Path(__file__).with_name('.pairing_key')
def downloads_root():
    if os.name == 'nt':
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r'Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders') as key:
                value = winreg.QueryValueEx(key, '{374DE290-123F-4565-9164-39C4925E467B}')[0]
                return Path(os.path.expandvars(value))
        except OSError: pass
    return Path.home() / 'Downloads'
DOWNLOADS_ROOT = downloads_root()
CONFIG_PATH = Path(__file__).with_name('settings.json')
HISTORY_PATH = Path(__file__).with_name('history.json')
DEFAULT_FOLDER = 'VidDock'

JOBS: dict[str, dict] = {}
SAVED: dict[str, dict] = {}
JOBS_PATH = Path(__file__).with_name('job_journal.json')
INSTANCE_ID = uuid.uuid4().hex
# Only the local supervisor passes this one-launch identifier. Do not forward it to yt-dlp.
LAUNCH_ID = os.environ.pop('VIDDOCK_LAUNCH_ID', '')
_LAST_JOB_JOURNAL_WRITE = 0.0
JOB_JOURNAL_LIMIT = 400
MAX_CONCURRENT_DOWNLOADS = 3
MAX_PENDING_JOBS = 200
PENDING_DOWNLOADS = deque()
RUNNING_DOWNLOADS = set()
CONVERSION_LOCK = threading.Lock()
LOCK = threading.RLock()
IMPERSONATION_STATUS = {'attempted': False, 'installing': False, 'error': ''}
QUALITY = {'best': None, '1080': 1080, '720': 720, '480': 480, '360': 360}
ID_RE = re.compile(r'^[A-Za-z0-9_-]{11}$')
EXTENSION_ORIGIN_RE = re.compile(r'^chrome-extension://[a-p]{32}$')


def validate_folder(value: str) -> str:
    if not isinstance(value, str) or not (1 <= len(value.strip()) <= 150):
        raise ValueError('保存先はDownloads内のフォルダ名で指定してください。')
    folder = value.strip().replace('\\', '/')
    chunks = folder.split('/')
    if any(not x or x in ('.', '..') or re.search(r'[<>:"|?*\x00-\x1f]', x)
           or x[-1:] in ('.', ' ') for x in chunks):
        raise ValueError('相対フォルダ名だけ指定できます（例: VidDock/動画）。')
    if any(re.match(r'^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?$', x, re.I) for x in chunks):
        raise ValueError('Windowsの予約名はフォルダ名に使えません。')
    return '/'.join(chunks)


def load_json(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def store_json(path: Path, data: dict) -> None:
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(temporary, path)


def get_folder() -> str:
    try:
        return validate_folder(load_json(CONFIG_PATH).get('folder', DEFAULT_FOLDER))
    except ValueError:
        return DEFAULT_FOLDER


def get_fragment_concurrency() -> int:
    value = load_json(CONFIG_PATH).get('fragmentConcurrency', 4)
    return value if type(value) is int and value in (1, 2, 4, 8) else 4


def get_destination(folder: str | None = None) -> Path:
    return DOWNLOADS_ROOT.joinpath(*(folder or get_folder()).split('/'))


def load_saved() -> None:
    with LOCK:
        SAVED.update(load_json(HISTORY_PATH))


def save_success(key: str, path: Path, quality: str) -> None:
    with LOCK:
        SAVED[key] = {'path': str(path), 'quality': quality, 'savedAt': __import__('time').time()}
        if len(SAVED) > 400:
            for old in list(SAVED)[:-400]:
                SAVED.pop(old, None)
        store_json(HISTORY_PATH, SAVED)


def status_log(message: str) -> None:
    """pythonw.exe has no console; avoid raising while reporting status."""
    try:
        with Path(__file__).with_name('helper.log').open('a', encoding='utf-8') as fp:
            fp.write(message + '\n')
    except OSError:
        pass
    if sys.stdout is not None:
        try:
            print(message)
        except (OSError, AttributeError, UnicodeError):
            pass


def read_key() -> str:
    if KEY_PATH.is_file():
        value = KEY_PATH.read_text(encoding='utf-8').strip()
        if re.fullmatch(r'[A-Fa-f0-9]{48}', value):
            return value
    token = secrets.token_hex(24)
    KEY_PATH.write_text(token, encoding='utf-8')
    try:
        KEY_PATH.chmod(0o600)
    except OSError:
        pass
    return token


def normalize_youtube_url(raw: str) -> str:
    if len(raw) > 1500:
        raise ValueError('URLが長すぎます。')
    parsed = urlparse(raw)
    if parsed.scheme not in ('https', 'http') or parsed.port is not None:
        raise ValueError('動画URLは有効なHTTP(S) URLにしてください。')
    name = (parsed.hostname or '').lower()
    if name in ('youtu.be', 'www.youtu.be'):
        video_id = parsed.path.strip('/').split('/')[0]
    elif name in ('youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtube-nocookie.com', 'www.youtube-nocookie.com'):
        segments = parsed.path.strip('/').split('/')
        if parsed.path == '/watch':
            video_id = parse_qs(parsed.query).get('v', [''])[0]
        elif len(segments) == 2 and segments[0] in ('shorts', 'live', 'embed'):
            video_id = segments[1]
        else:
            raise ValueError('YouTubeの単一動画ページのみ対応しています。')
    else:
        raise ValueError('YouTubeの動画URLだけを指定してください。')
    if not ID_RE.fullmatch(video_id):
        raise ValueError('YouTube動画IDが正しくありません。')
    return f'https://www.youtube.com/watch?v={video_id}'


def yt_dlp_command() -> list[str] | None:
    # pythonw.exe has no stdout/stderr; use python.exe for the yt-dlp child.
    interpreter = Path(sys.executable)
    if os.name == 'nt' and interpreter.name.lower() == 'pythonw.exe':
        console = interpreter.with_name('python.exe')
        if console.is_file():
            interpreter = console
    if importlib.util.find_spec('yt_dlp'):
        return [str(interpreter), '-m', 'yt_dlp']
    name = shutil.which('yt-dlp')
    return [name] if name else None



def dependency_versions() -> dict:
    """Report the actual helper runtime, never assume system pip is the same Python."""
    result = {'pythonVersion': '.'.join(map(str, sys.version_info[:3]))}
    for package, field in [('yt-dlp', 'ytdlpVersion'), ('curl-cffi', 'curlCffiVersion'),
                           ('yt-dlp-ejs', 'ejsVersion')]:
        try: result[field] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError: result[field] = ''
    return result


def impersonation_available() -> bool:
    """Check the exact Python environment used to launch yt-dlp."""
    importlib.invalidate_caches()
    try:
        return importlib.util.find_spec('curl_cffi') is not None
    except (ValueError, ImportError):
        return False


def managed_python() -> bool:
    """Do not silently pip-install into a system-wide interpreter."""
    if os.name != 'nt':
        return False
    interpreter = Path(sys.executable)
    runtime = Path(__file__).resolve().parent / 'Runtime' / 'Scripts'
    return interpreter.parent.resolve() == runtime.resolve()


def install_impersonation_dependency() -> tuple[bool, str]:
    """Install official optional extra into VidDock's isolated Python runtime."""
    interpreter = Path(sys.executable)
    if interpreter.name.lower() == 'pythonw.exe':
        interpreter = interpreter.with_name('python.exe')
    # Do not upgrade yt-dlp while the helper is starting or downloading. Only
    # install the optional impersonation backend in our managed environment.
    args = [str(interpreter), '-m', 'pip', 'install', '--disable-pip-version-check',
            '--quiet', '--only-binary=:all:', 'curl_cffi']
    try:
        result = subprocess.run(args, capture_output=True, text=True,
                                encoding='utf-8', errors='replace', timeout=180,
                                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.name == 'nt' else 0)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, 'Optional dependency installation failed: ' + str(exc)[:220]
    importlib.invalidate_caches()
    if result.returncode != 0:
        return False, ('Optional dependency installation failed: ' + (result.stderr or result.stdout)[-230:])
    if not impersonation_available():
        return False, 'curl_cffi was not found after installation.'
    return True, ''


def schedule_impersonation_setup() -> None:
    """Nonblocking repair for existing installations updated from VidDock181."""
    if impersonation_available() or not managed_python() or not yt_dlp_command():
        return
    with LOCK:
        if IMPERSONATION_STATUS['attempted']:
            return
        IMPERSONATION_STATUS.update(attempted=True, installing=True, error='')
    def install_worker():
        try:
            ok, error = install_impersonation_dependency()
            with LOCK:
                IMPERSONATION_STATUS.update(installing=False, error=error)
            status_log('curl_cffi ready' if ok else 'curl_cffi optional dependency unavailable: ' + error[:200])
        except Exception as exc:
            with LOCK:
                IMPERSONATION_STATUS.update(installing=False, error=str(exc)[:220])
    threading.Thread(target=install_worker, daemon=True, name='VidDockImpersonationSetup').start()


def cloudflare_challenge(text: str) -> bool:
    return 'cloudflare anti-bot challenge' in text.lower()


def impersonation_arguments(enabled: bool) -> list[str]:
    # The extractor arg only covers the first request. The global option
    # also covers variant playlists and segment requests. Keep HLS in
    # yt-dlp's networking stack instead of an external ffmpeg downloader.
    return (['--impersonate', 'chrome', '--extractor-args', 'generic:impersonate=chrome',
             '--downloader', 'm3u8:native',
             '--abort-on-unavailable-fragments', '--fragment-retries', '2',
             '--retries', '2'] if enabled else [])



def hls_forbidden(text: str) -> bool:
    lower = text.lower()
    return ('[generic]' in lower and 'failed to download m3u8 information' in lower
            and bool(re.search(r'http(?: error)?\s+403\b', lower)))


def browser_transport_available(command: list[str]) -> bool:
    """Check usable targets in the exact yt-dlp child, not only find_spec."""
    try:
        result = subprocess.run(
            command + ['--ignore-config', '--no-plugin-dirs', '--no-colors',
                       '--list-impersonate-targets'],
            stdin=subprocess.DEVNULL, capture_output=True, text=True,
            encoding='utf-8', errors='replace', timeout=15,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.name == 'nt' else 0)
        return result.returncode == 0 and any(
            re.match(r'^\s*chrome(?:[-\s])', line, re.I) and 'unavailable' not in line.lower()
            for line in result.stdout.splitlines())
    except (OSError, subprocess.TimeoutExpired):
        return False


def wait_for_impersonation_setup(seconds: float = 45) -> bool:
    if impersonation_available():
        return True
    schedule_impersonation_setup()
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        with LOCK:
            installing = IMPERSONATION_STATUS['installing']
        if not installing:
            break
        time.sleep(0.5)
    return impersonation_available()


def _persist_jobs(force: bool = False) -> None:
    """Durable, minimal job state; never persist media URLs or credentials.

    Caller owns LOCK. An intermittent disk error must not kill a download.
    Writes are throttled while yt-dlp emits frequent progress lines.
    """
    global _LAST_JOB_JOURNAL_WRITE
    now = time.monotonic()
    if not force and now - _LAST_JOB_JOURNAL_WRITE < 1.25:
        return
    snapshot = {}
    for job_id, job in list(JOBS.items())[-JOB_JOURNAL_LIMIT:]:
        if not re.fullmatch(r'[a-f0-9]{32}', job_id):
            continue
        state = job.get('state')
        if state not in ('queued', 'running', 'done', 'failed', 'interrupted'):
            continue
        try:
            percent = max(0.0, min(100.0, float(job.get('percent', 0) or 0)))
        except (TypeError, ValueError):
            percent = 0.0
        item = {
            'state': state,
            'percent': percent,
            'message': sanitize_diagnostic(str(job.get('message', '')))[:300],
            'updatedAt': int(time.time()),
        }
        if state == 'done' and job.get('path'):
            item['path'] = str(job['path'])[:1024]
        snapshot[job_id] = item
    try:
        store_json(JOBS_PATH, {'schema': 1, 'jobs': snapshot})
        _LAST_JOB_JOURNAL_WRITE = now
    except (OSError, ValueError) as exc:
        status_log('Unable to persist download state: ' + str(exc)[:140])


def load_jobs() -> None:
    """Recover statuses after an unexpected helper exit.

    In-progress subprocess downloads cannot be safely claimed as resumed.
    Preserve their progress and explain that the outcome is unknown.
    """
    data = load_json(JOBS_PATH)
    records = data.get('jobs', {})
    if not isinstance(records, dict):
        return
    with LOCK:
        for job_id, item in list(records.items())[-JOB_JOURNAL_LIMIT:]:
            if not isinstance(job_id, str) or not re.fullmatch(r'[a-f0-9]{32}', job_id):
                continue
            if not isinstance(item, dict):
                continue
            state = item.get('state', '')
            if state not in ('queued', 'running', 'done', 'failed', 'interrupted'):
                continue
            try:
                percent = max(0.0, min(100.0, float(item.get('percent', 0) or 0)))
            except (TypeError, ValueError):
                percent = 0.0
            recovered = state in ('queued', 'running')
            path = str(item.get('path', ''))[:1024] if state == 'done' else ''
            if state == 'done' and (not path or not Path(path).is_file()):
                recovered = True
            if recovered:
                state = 'interrupted'
                message = ('補助ツールが再起動し、動画保存の追跡が中断されました。'
                           '保存先に完成ファイルがないか確認し、必要なら動画を再検出して再試行してください。')
                path = ''
            else:
                message = sanitize_diagnostic(str(item.get('message', '')))[:300]
            JOBS[job_id] = {'state': state, 'percent': percent, 'path': path,
                            'message': message, 'recovered': recovered}
        _persist_jobs(force=True)


def set_job(job_id: str, **changes) -> None:
    with LOCK:
        job = JOBS.get(job_id)
        if job is None:
            return
        previous_state = job.get('state')
        previous_percent = job.get('percent', 0) or 0
        if 'message' in changes:
            changes['message'] = sanitize_diagnostic(str(changes['message']))
        job.update(changes)
        # Queue reservation already marked the job running at 0 percent.
        # Save its first real progress immediately so an early crash does
        # not restore the reservation's zero-progress snapshot.
        _persist_jobs(force=(previous_state != job.get('state') or
                             (previous_percent == 0 and (job.get('percent', 0) or 0) > 0) or
                             job.get('state') in ('done', 'failed', 'interrupted')))


def _refresh_queue_locked() -> None:
    for position, (job_id, _args, _kwargs) in enumerate(PENDING_DOWNLOADS, 1):
        job = JOBS.get(job_id)
        if job:
            job.update(state='queued', phase='waiting', queuePosition=position,
                       message=f'待機中（{position}番目）・同時保存は3本まで')
    _persist_jobs(force=True)


def _execute_queued_download(job_id, args, kwargs) -> None:
    try:
        run_download(job_id, *args, **kwargs)
    except Exception as exc:
        set_job(job_id, state='failed', message='保存処理エラー: ' + sanitize_diagnostic(str(exc)))
    finally:
        with LOCK:
            job = JOBS.get(job_id, {})
            if job.get('state') in ('queued', 'running'):
                set_job(job_id, state='failed', message='保存処理が完了状態を返さず終了しました。')
            RUNNING_DOWNLOADS.discard(job_id)
            _start_pending_locked()


def _start_pending_locked() -> None:
    # Reserve slots atomically, even when requests come from different windows.
    while PENDING_DOWNLOADS and len(RUNNING_DOWNLOADS) < MAX_CONCURRENT_DOWNLOADS:
        job_id, args, kwargs = PENDING_DOWNLOADS.popleft()
        if JOBS.get(job_id, {}).get('state') != 'queued':
            continue
        RUNNING_DOWNLOADS.add(job_id)
        set_job(job_id, state='running', phase='preparing', queuePosition=0,
                message='動画を取得する準備をしています...')
        try:
            worker = threading.Thread(target=_execute_queued_download,
                                      args=(job_id, args, kwargs), daemon=True,
                                      name='VidDockDownload-' + job_id[:8])
            worker.start()
        except Exception as exc:
            RUNNING_DOWNLOADS.discard(job_id)
            set_job(job_id, state='failed', message='保存処理を開始できません: ' + sanitize_diagnostic(str(exc)))
    _refresh_queue_locked()


def enqueue_download(job_id, url, quality, **kwargs) -> None:
    with LOCK:
        PENDING_DOWNLOADS.append((job_id, (url, quality), kwargs))
        _start_pending_locked()


def parse_download_progress(line: str) -> dict | None:
    if not line.startswith('VDPROGRESS:'):
        return None
    fields = line[len('VDPROGRESS:'):].split('|')
    if len(fields) != 6:
        return None
    def number(raw):
        try:
            value = float(raw.strip().replace('%', ''))
            return value if math.isfinite(value) and value >= 0 else None
        except (ValueError, TypeError):
            return None
    percent, speed, eta, received, total, estimate = map(number, fields)
    result = {'phase': 'downloading', 'speedBytes': speed,
              'etaSeconds': eta, 'bytesReceived': received or 0,
              'totalBytes': total or estimate or 0, 'totalEstimated': not bool(total)}
    if percent is not None:
        result['percent'] = min(99.0, percent)
    result['message'] = '動画データを取得しています...'
    return result


def normalize_tokyomotion_url(raw: str) -> str:
    if not isinstance(raw, str) or len(raw) > 2000:
        raise ValueError('TokyoMotionのURLが不正です。')
    parsed = urlparse(raw)
    if parsed.scheme != 'https' or parsed.username or parsed.password or parsed.port is not None:
        raise ValueError('HTTPSのTokyoMotion URLを指定してください。')
    if (parsed.hostname or '').lower() not in ('tokyomotion.net', 'www.tokyomotion.net'):
        raise ValueError('TokyoMotionの動画ページだけ対応しています。')
    if not re.fullmatch(r'/video/\d+/[^/?#]*', parsed.path):
        raise ValueError('TokyoMotionの動画ページを開いてください。')
    return f'https://www.tokyomotion.net{parsed.path}'


def normalize_media_url(raw: str) -> str:
    """User-initiated media candidates only. Block loopback and direct IP targets."""
    if not isinstance(raw, str) or len(raw) > 3500:
        raise ValueError('メディアURLが不正です。')
    p = urlparse(raw)
    host = p.hostname or ''
    if p.scheme != 'https' or not host or p.username or p.password or p.port is not None:
        raise ValueError('メディアURLは有効なHTTPSアドレスにしてください。')
    if host.lower() in ('localhost', 'localhost.localdomain') or host.lower().endswith(('.localhost', '.local', '.internal')):
        raise ValueError('ローカルアドレスへの保存は許可しません。')
    try:
        ipaddress.ip_address(host.strip('[]'))
    except ValueError:
        if not re.fullmatch(r'[a-z0-9.-]+', host.lower()) or '.' not in host:
            raise ValueError('メディアURLのホスト名が不正です。')
    else:
        raise ValueError('IPアドレスへの直接アクセスは許可しません。')
    return raw


def ffmpeg_location() -> str | None:
    configured = load_json(Path(__file__).with_name('tools.json')).get('ffmpeg')
    if configured and Path(configured).is_file(): return str(Path(configured).parent)
    # ffmpeg.exe/ffprobe.exeを helper/bin に置いた場合も自動検出する。
    local = Path(__file__).with_name('bin') / ('ffmpeg.exe' if os.name == 'nt' else 'ffmpeg')
    if local.is_file():
        return str(local.parent)
    binary = shutil.which('ffmpeg')
    return str(Path(binary).parent) if binary else None


def ffmpeg_binary() -> str | None:
    location = ffmpeg_location()
    if not location:
        return None
    executable = 'ffmpeg.exe' if os.name == 'nt' else 'ffmpeg'
    path = Path(location) / executable
    return str(path) if path.is_file() else shutil.which('ffmpeg')


def ffprobe_binary() -> str | None:
    configured = load_json(Path(__file__).with_name('tools.json')).get('ffprobe')
    if configured and Path(configured).is_file(): return configured
    location = ffmpeg_location()
    if not location:
        return None
    executable = 'ffprobe.exe' if os.name == 'nt' else 'ffprobe'
    path = Path(location) / executable
    return str(path) if path.is_file() else shutil.which('ffprobe')


def media_codecs(source: Path) -> tuple[str, str] | None:
    probe = ffprobe_binary()
    if not probe:
        return None
    process = subprocess.run([probe, '-v', 'error', '-show_entries',
                              'stream=codec_type,codec_name', '-of', 'json', str(source)],
                             capture_output=True, text=True, timeout=30)
    if process.returncode != 0:
        return None
    streams = json.loads(process.stdout).get('streams', [])
    video = next((it.get('codec_name','') for it in streams if it.get('codec_type')=='video'), '')
    audio = next((it.get('codec_name','') for it in streams if it.get('codec_type')=='audio'), '')
    return video, audio


def ensure_mp4(source: Path) -> Path:
    """Publish only a playable .mp4. Never rename TS/WebM data to .mp4."""
    ffmpeg = ffmpeg_binary()
    if not ffmpeg:
        raise RuntimeError('MP4変換にはFFmpegが必要です。helper/binにffmpeg.exeとffprobe.exeを置き、セットアップを再実行してください。')
    codecs = media_codecs(source)
    # If ffprobe is missing, force a codec conversion to ensure playback compatibility.
    compatible = bool(codecs and codecs[0] == 'h264' and codecs[1] in ('aac',''))
    if source.suffix.lower() == '.mp4' and compatible:
        return source
    converted = source.with_name(source.stem + '.watari-converted.mp4')
    command = [ffmpeg, '-hide_banner', '-loglevel', 'error', '-nostdin', '-y', '-i', str(source),
               '-map', '0:v:0', '-map', '0:a?', '-sn', '-dn']
    if codecs and codecs[0] == 'h264':
        command += ['-c:v', 'copy']
    else:
        command += ['-c:v', 'libx264', '-preset', 'medium', '-crf', '19', '-pix_fmt', 'yuv420p']
    if codecs and codecs[1] in ('aac', ''):
        command += ['-c:a', 'copy']
    else:
        command += ['-c:a', 'aac', '-b:a', '192k']
    command += ['-movflags', '+faststart', str(converted)]
    options = {'capture_output': True, 'text': True}
    if os.name == 'nt':
        options['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    result = subprocess.run(command, **options)
    if result.returncode or not converted.is_file() or converted.stat().st_size < 1024:
        raise RuntimeError('MP4変換に失敗しました: ' + (result.stderr or '')[-350:])
    return converted


def choose_final_file(stage: Path) -> Path:
    """Temporary audio/video tracks MUST NOT be published."""
    files = [p for p in stage.iterdir() if p.is_file() and p.suffix.lower() in ('.mp4', '.mkv', '.webm', '.mov', '.ts')]
    if len(files) != 1:
        raise RuntimeError(f'結合後の動画が1件になりませんでした（候補: {len(files)} 件）。FFmpegを確認してください。')
    return files[0]


def unique_destination(name: str, folder: Path) -> Path:
    out = folder / name
    if not out.exists():
        return out
    base, suffix = out.stem, out.suffix
    for i in range(1, 1000):
        alt = folder / f'{base} ({i}){suffix}'
        if not alt.exists():
            return alt
    raise RuntimeError('同名ファイルが多すぎます。')




def verified_request_context(context: dict | None) -> dict[str, str]:
    """Allowlist harmless playback headers; no cookies, auth tokens or secrets."""
    if context is None:
        return {}
    if not isinstance(context, dict) or len(context) > 8:
        raise ValueError('Invalid playback context')
    mapping = {'referer':'Referer', 'origin':'Origin',
               'user-agent':'User-Agent', 'accept-language':'Accept-Language'}
    result = {}
    for name, raw in context.items():
        name = str(name).lower()
        if name not in mapping or not isinstance(raw, str) or len(raw) > 700 or re.search(r'[\r\n\x00]',raw):
            continue
        if name in ('referer','origin'):
            target = urlparse(raw)
            if target.scheme not in ('http','https') or not target.hostname or target.username or target.password:
                continue
            if name == 'origin' and (target.path not in ('','/') or target.query or target.fragment):
                continue
        result[mapping[name]] = raw
    return result


def media_identity(raw: str) -> str:
    """Ignore expiring signatures without collapsing distinct video IDs."""
    url = urlparse(raw)
    volatile = {'expires','expire','expiration','token','signature','sig','auth','hdntl','hdnts',
                'policy','key-pair-id','x-amz-signature','x-amz-date','x-amz-expires',
                'x-amz-credential','x-amz-algorithm','x-amz-security-token'}
    stable = [(k,v) for k,v in parse_qsl(url.query,keep_blank_values=True)
              if k.lower() not in volatile]
    return urlunparse(url._replace(query=urlencode(sorted(stable)),fragment=''))


def sanitize_diagnostic(message: str) -> str:
    """Never store signed media URLs, cookies, or secrets in the saved UI history."""
    value = re.sub(r'https?://[^\s\]\)<>"\']+', '[media-url]', message)
    value = re.sub(r'(?i)(?:cookie|authorization|token|signature|password)\s*[:=]\s*[^\s,;]+',
                   '[private-value]', value)
    return value[:310]

def run_download(job_id: str, url: str, quality: str, *, site: str = 'youtube', media_url: str = '', folder: str = DEFAULT_FOLDER, key: str = '', request_context: dict | None = None, fragment_concurrency: int | None = None) -> None:
    fragments = fragment_concurrency if fragment_concurrency in (1, 2, 4, 8) else get_fragment_concurrency()
    command = yt_dlp_command()
    if not command:
        set_job(job_id, state='failed', message='yt-dlpが未インストールです。VidDockSetup.cmdで修復してください。')
        return
    ffmpeg = ffmpeg_location()
    if not ffmpeg:
        set_job(job_id, state='failed', message='MP4保存にはFFmpegが必要です。VidDockSetup.cmdで修復してください。')
        return
    extra_headers = verified_request_context(request_context)
    target = QUALITY[quality]
    height = f'[height<={target}]' if target else ''
    fmt = f'bv{height}+ba/b{height}/b'
    try:
        destination_folder = get_destination(folder)
        destination_folder.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='.viddock_work_', dir=destination_folder) as tempdir:
            stage = Path(tempdir)
            result_tail: list[str] = []
            source = None
            retry_reason = ''
            for attempt in range(2 if site in ('tokyomotion', 'media') else 1):
                impersonate = attempt == 1
                if impersonate:
                    if not wait_for_impersonation_setup():
                        with LOCK:
                            installing = IMPERSONATION_STATUS['installing']
                            installation_error = IMPERSONATION_STATUS['error']
                        detail = ('curl_cffiのインストール中です。少し待って再試行してください。' if installing else
                                  'curl_cffiが必要です。VidDockSetup.cmdで依存関係を修復してください。'
                                  + (' 詳細: ' + installation_error[:125] if installation_error else ''))
                        set_job(job_id, state='failed', message=detail)
                        return
                    if not browser_transport_available(command):
                        set_job(job_id, state='failed', message=(
                            'yt-dlpでChrome互換通信を利用できません。curl_cffiの導入有無ではなく、'
                            'このPython環境での対応状況を確認してください。'))
                        return
                    reason = 'Cloudflareの判定を検出。' if retry_reason == 'cloudflare' else 'HLS再生リストが403で拒否されました。'
                    set_job(job_id, state='running', percent=0, message=reason +
                            'ページ・再生リスト・分割動画を同じChrome互換通信で1回再試行しています...')
                work_dir = stage / ('retry' if impersonate else 'initial')
                work_dir.mkdir()
                args = command + [
                    '--ignore-config', '--no-playlist', '--no-overwrites', '--newline',
                    '--no-keep-video', '--no-write-thumbnail', '--no-write-info-json',
                    '--no-write-subs', '--no-write-auto-subs', '--no-exec',
                    '--format', fmt, '--paths', str(work_dir),
                    '--output', '%(title).150B [%(id)s].%(ext)s',
                    '--ffmpeg-location', ffmpeg, '--merge-output-format', 'mp4/mkv'
                ]
                if site in ('tokyomotion', 'media'):
                    # Prefer the actual player request. Top-level page is just
                    # a fallback if the browser did not expose its Referer.
                    extra_headers.setdefault('Referer', url)
                    for name, value in extra_headers.items():
                        # Let curl_cffi choose the UA matching its TLS profile.
                        # Referer, Origin and Accept-Language remain unchanged.
                        if impersonate and name == 'User-Agent':
                            continue
                        args += ['--add-header', f'{name}:{value}']
                deno = load_json(Path(__file__).with_name('tools.json')).get('deno')
                if deno and Path(deno).is_file():
                    args += ['--js-runtimes', 'deno:' + deno]
                args += impersonation_arguments(impersonate)
                args += ['--concurrent-fragments', str(fragments), '--no-colors',
                         '--progress-delta', '0.7', '--progress-template',
                         'download:VDPROGRESS:%(progress._percent_str)s|%(progress.speed)s|%(progress.eta)s|%(progress.downloaded_bytes)s|%(progress.total_bytes)s|%(progress.total_bytes_estimate)s']
                args.append(media_url or url)
                if not impersonate:
                    set_job(job_id, state='running', message='動画データを取得しています...', percent=0)
                result_tail = []
                cloudflare_blocked = False
                hls_blocked = False
                kwargs = {'stdin': subprocess.DEVNULL, 'stdout': subprocess.PIPE,
                          'stderr': subprocess.STDOUT, 'text': True,
                          'encoding': 'utf-8', 'errors': 'replace', 'bufsize': 1}
                if os.name == 'nt':
                    kwargs['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
                process = subprocess.Popen(args, **kwargs)
                assert process.stdout is not None
                for raw in process.stdout:
                    line = raw.strip()
                    if not line:
                        continue
                    structured = parse_download_progress(line)
                    if structured is not None:
                        set_job(job_id, **structured)
                        continue
                    result_tail.append(line)
                    result_tail = result_tail[-16:]
                    if cloudflare_challenge(line):
                        cloudflare_blocked = True
                    if hls_forbidden(line):
                        hls_blocked = True
                    progress = re.search(r'\[download\]\s+(\d+(?:\.\d+)?)%', line)
                    if progress:
                        set_job(job_id, percent=min(99.0, float(progress.group(1))), message=line[:190])
                    elif '[Merger]' in line or '[VideoRemuxer]' in line:
                        set_job(job_id, phase='converting', speedBytes=None, etaSeconds=None, message='映像と音声を1ファイルに結合しています...')
                exitcode = process.wait()
                getattr(process.stdout, 'close', lambda: None)()
                if exitcode == 0:
                    source = choose_final_file(work_dir)
                    break
                if (cloudflare_blocked or hls_blocked) and not impersonate and site in ('tokyomotion', 'media'):
                    retry_reason = 'cloudflare' if cloudflare_blocked else 'hls403'
                    continue
                detail = next((line for line in reversed(result_tail) if 'ERROR:' in line),
                              result_tail[-1] if result_tail else '')
                if impersonate and (hls_blocked or cloudflare_blocked or re.search(r'403|Forbidden', detail, re.I)):
                    set_job(job_id, state='failed', message=(
                        'Chrome互換通信でも動画配信元が403を返しました。'
                        '再試行は1回で停止しました。ブラウザのセッション条件などが別途必要な可能性があります。 / '
                        + sanitize_diagnostic(detail)[:130]))
                    return
                if cloudflare_blocked:
                    detail = ('Cloudflareが通信を拒否しました。公式impersonate方式でも取得できませんでした。'
                              'サイト側の制限がある場合は保存できません。 / ' + detail[:140])
                elif site == 'tokyomotion' and re.search(r'(403|Forbidden)', detail, re.I):
                    detail = ('配信元がアクセスを拒否しました（HTTP 403）。再生ページを開き直してください。'
                              ' サイトのアクセス制限がある場合は保存できません。 / ' + detail[:140])
                elif site == 'tokyomotion':
                    detail += ' / 動画を再生し直し、再検出してください。'
                set_job(job_id, state='failed', message='取得エラー: ' + sanitize_diagnostic(detail))
                return
            if source is None:
                set_job(job_id, state='failed', message='動画の保存データを取得できませんでした。')
                return
            set_job(job_id, phase='waiting_conversion', speedBytes=None, etaSeconds=None,
                    message='MP4仕上げ待ち（変換は1本ずつ）', percent=99)
            with CONVERSION_LOCK:
                set_job(job_id, phase='converting', message='MP4へ変換・最適化しています...', percent=99)
                source = ensure_mp4(source)
            destination = unique_destination(source.name.replace('.watari-converted.mp4', '.mp4'),
                                             destination_folder)
            shutil.move(str(source), str(destination))
            save_success(key, destination, quality)
            set_job(job_id, state='done', percent=100, path=str(destination),
                    message='保存完了（1ファイル） · ' + str(destination))
    except Exception as exc:
        set_job(job_id, state='failed', message='実行エラー: '+sanitize_diagnostic(str(exc)))


class Handler(BaseHTTPRequestHandler):
    server_version = 'VidDock/1.9.5'
    def log_message(self, format_string, *args):
        if not self.path.startswith('/api/job/'):
            status_log('[Watari Helper] ' + (format_string % args))

    def _origin(self) -> str | None:
        value = self.headers.get('Origin', '')
        return value if EXTENSION_ORIGIN_RE.fullmatch(value) else None

    def _headers(self, status: int, *, json_type: bool = True):
        self.send_response(status)
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Cache-Control', 'no-store')
        if json_type:
            self.send_header('Content-Type', 'application/json; charset=utf-8')
        origin = self._origin()
        if origin:
            self.send_header('Access-Control-Allow-Origin', origin)
            self.send_header('Vary', 'Origin')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type, X-Watari-Token')
            self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            if self.headers.get('Access-Control-Request-Private-Network') == 'true':
                self.send_header('Access-Control-Allow-Private-Network', 'true')

    def _answer(self, status: int, body: dict):
        content = json.dumps(body, ensure_ascii=False).encode('utf-8')
        self._headers(status)
        self.send_header('Content-Length', str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def _authorized(self) -> bool:
        # Bound to 127.0.0.1; also require loopback peer and exact Host to guard DNS rebinding.
        if self.client_address[0] not in ('127.0.0.1', '::1'):
            self._answer(403, {'ok': False, 'code': 'NOT_LOOPBACK', 'error': 'ローカルPC以外からの接続はできません。'})
            return False
        if self.headers.get('Host', '').lower() != f'{HOST}:{PORT}':
            self._answer(403, {'ok': False, 'code': 'BAD_HOST', 'error': '接続先ホストが一致しません。127.0.0.1:18763 へ接続してください。'})
            return False
        # Chrome MV3's privileged service worker fetch may omit Origin entirely.
        # Reject any *present* non-extension origin so ordinary web pages are blocked.
        origin = self.headers.get('Origin', '')
        if origin and not EXTENSION_ORIGIN_RE.fullmatch(origin):
            self._answer(403, {'ok': False, 'code': 'BAD_ORIGIN', 'error': 'Chrome拡張以外の送信元から接続されました。'})
            return False
        if not re.fullmatch(r'[A-Fa-f0-9]{48}', self.headers.get('X-Watari-Token', '')) or not hmac.compare_digest(self.headers.get('X-Watari-Token', ''), self.server.pairing_key):
            self._answer(401, {'ok': False, 'code': 'INVALID_TOKEN', 'error': '連携キーが補助ツール側と一致しません。設定画面のキーを確認してください。'})
            return False
        return True

    def do_OPTIONS(self):
        if not self._origin():
            self._answer(403, {'ok': False, 'error': '不正な接続元です。'})
            return
        self._headers(204, json_type=False)
        self.end_headers()

    def do_GET(self):
        if not self._authorized():
            return
        if self.path == '/api/status':
            self._answer(200, {'ok': True, 'version': '1.9.5', 'ytdlp': yt_dlp_command() is not None,
                               'ffmpeg': ffmpeg_binary() is not None, 'ffprobe': ffprobe_binary() is not None,
                               'impersonation': impersonation_available(),
                               'impersonationInstalling': IMPERSONATION_STATUS['installing'],
                               'impersonationError': IMPERSONATION_STATUS['error'][:200],
                               'folder': get_folder(), 'pid': os.getpid(), 'instanceId': INSTANCE_ID,
                               'launchId': LAUNCH_ID, **dependency_versions(),
                               'activeDownloads': sum(j.get('state') in ('queued','running') for j in list(JOBS.values())),
                               'runningDownloads': len(RUNNING_DOWNLOADS), 'queuedDownloads': len(PENDING_DOWNLOADS), 'maxConcurrent': 3})
            return
        if self.path == '/api/settings':
            self._answer(200, {'ok': True, 'folder': get_folder(), 'maxConcurrent': 3, 'fragmentConcurrency': get_fragment_concurrency()})
            return
        if self.path == '/api/update/status':
            self._answer(200, {'ok': True, **updater.status()})
            return
        if self.path == '/api/update/check':
            try:
                self._answer(200, {'ok': True, **updater.check_update()})
            except (RuntimeError, ValueError, OSError) as exc:
                self._answer(400, {'ok': False, 'error': str(exc)})
            return
        if self.path.startswith('/api/job/'):
            job_id = self.path.split('/')[3]
            if not re.fullmatch(r'[a-f0-9]{32}', job_id):
                self._answer(400, {'ok': False, 'error': 'ジョブIDが不正です。'})
                return
            with LOCK:
                info = dict(JOBS.get(job_id, {}))
            if not info:
                self._answer(404, {'ok': False, 'code': 'JOB_UNKNOWN',
                                   'error': 'ジョブの記録がありません。補助ツールが別のインストール先から起動していないか確認してください。',
                                   'instanceId': INSTANCE_ID})
            else:
                self._answer(200, {'ok': True, **{k:v for k,v in info.items() if k != 'key'},
                                   'instanceId': INSTANCE_ID})
            return
        self._answer(404, {'ok': False, 'error': '不明なAPIです。'})

    def do_POST(self):
        if not self._authorized():
            return
        if self.path not in ('/api/download', '/api/settings', '/api/update/apply'):
            self._answer(404, {'ok': False, 'error': '不明なAPIです。'})
            return
        if self.path == '/api/update/apply':
            with LOCK:
                if any(j.get('state') in ('queued','running') for j in JOBS.values()):
                    self._answer(409, {'ok':False,'error':'保存完了後に更新してください。'}); return
                try: updater.start_update()
                except RuntimeError as exc:
                    self._answer(409, {'ok':False,'error':str(exc)}); return
            self._answer(200, {'ok':True,'state':'running'}); return
        try: size = int(self.headers.get('Content-Length', '0'))
        except ValueError: size = 0
        if size <= 0 or size > 8192 or self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
            self._answer(400, {'ok': False, 'error': '不正なJSONリクエストです。'})
            return
        try:
            data = json.loads(self.rfile.read(size).decode('utf-8'))
            if not isinstance(data, dict): raise ValueError('JSON object required')
            if self.path == '/api/settings':
                folder = validate_folder(data.get('folder', ''))
                fragments = data.get('fragmentConcurrency', get_fragment_concurrency())
                if type(fragments) is not int or fragments not in (1, 2, 4, 8):
                    raise ValueError('分割取得数は1・2・4・8から選択してください。')
                with LOCK:
                    store_json(CONFIG_PATH, {**load_json(CONFIG_PATH), 'folder': folder,
                                             'fragmentConcurrency': fragments})
                self._answer(200, {'ok': True, 'folder': folder, 'fragmentConcurrency': fragments})
                return
            site = str(data.get('site', 'youtube'))
            if site not in ('youtube', 'tokyomotion', 'media'):
                raise ValueError('指定されたサイトには対応していません。')
            url = (normalize_youtube_url(str(data.get('url', ''))) if site == 'youtube'
                   else normalize_tokyomotion_url(str(data.get('url', ''))) if site == 'tokyomotion'
                   else normalize_media_url(str(data.get('url', ''))))
            media_url = normalize_media_url(data.get('mediaUrl', '')) if site in ('tokyomotion','media') and data.get('mediaUrl') else ''
            if site == 'media' and not media_url:
                raise ValueError('動画の取得URLがありません。')
            request_context = verified_request_context(data.get('requestContext'))
            quality = str(data.get('quality', 'best'))
            if quality not in QUALITY:
                raise ValueError('指定された画質は無効です。')
            key = f'{site}:{url}' if site != 'media' else f'media:{media_identity(media_url)}'
            with LOCK:
                if updater.ACTIVE or updater.load(updater.JOURNAL).get('phase') in ('applying','awaiting_restart'):
                    self._answer(409, {'ok':False,'error':'更新中です。完了までお待ちください。'}); return
                for existing_id, existing in JOBS.items():
                    if existing.get('key') == key and existing['state'] in ('queued', 'running', 'done'):
                        if existing['state'] != 'done' or (Path(existing.get('path', '')).is_file() and Path(existing.get('path','')).suffix.lower() == '.mp4'):
                            self._answer(200, {'ok': True, 'jobId': existing_id, 'duplicate': True, 'state': existing['state']})
                            return
                previous = SAVED.get(key)
                if previous and Path(previous.get('path', '')).is_file() and Path(previous.get('path', '')).suffix.lower() == '.mp4':
                    job_id = uuid.uuid4().hex
                    JOBS[job_id] = {'state': 'done', 'percent': 100, 'key': key,
                                    'path': previous['path'], 'message': 'すでに保存済みです'}
                    _persist_jobs(force=True)
                    self._answer(200, {'ok': True, 'jobId': job_id, 'duplicate': True, 'state': 'done'})
                    return
                if len(PENDING_DOWNLOADS) >= MAX_PENDING_JOBS:
                    self._answer(429, {'ok': False, 'error': '待機列が200件に達しました。完了後に追加してください。'})
                    return
                if len(JOBS) > 100:
                    old = [key for key, val in JOBS.items() if val['state'] in ('done', 'failed')]
                    for old_id in old[:50]:
                        JOBS.pop(old_id, None)
                job_id = uuid.uuid4().hex
                JOBS[job_id] = {'key': key, 'state': 'queued', 'percent': 0, 'message': '開始待ちです。'}
                enqueue_download(job_id, url, quality, site=site, media_url=media_url,
                                 folder=get_folder(), key=key, request_context=request_context,
                                 fragment_concurrency=get_fragment_concurrency())
                accepted = dict(JOBS[job_id])
            self._answer(200, {'ok': True, 'jobId': job_id, 'state': accepted['state'],
                               'queuePosition': accepted.get('queuePosition', 0),
                               'message': accepted.get('message', '')})
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._answer(400, {'ok': False, 'error': str(exc)})



def should_shutdown_for_restart() -> bool:
    """Only an OLD helper exits for a NEW version request.

    A restart.request left over from the previous helper must not kill
    the freshly started helper. A duplicate/stale request is not sufficient
    to trigger another restart.
    """
    try:
        desired = updater.RESTART.read_text(encoding='ascii').strip()
        return updater.version_tuple(desired) > updater.version_tuple(updater.VERSION)
    except (OSError, UnicodeError, ValueError):
        return False


def main():
    if not yt_dlp_command():
        status_log('注意: yt-dlp が見つかりません。起動はできますが動画保存前に導入してください。')
        status_log('例: py -3 -m pip install -U "yt-dlp[default,curl-cffi]"')
    status_log('補助ツール起動中 / DRM解除機能なし')
    load_saved()
    load_jobs()
    status_log('保存先: ' + str(get_destination()))
    status_log('連携キーはインストーラーから確認してください。')
    status_log('ローカルの設定で連携キーを使用します。')
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    server.pairing_key = read_key()
    # Start serving /api/status before any network-backed dependency repair.
    # Updating packages during the supervisor's restart verification can
    # prevent a healthy new process from being observed and cause rollback.
    def post_start_dependency_repair():
        time.sleep(6)
        # Keep optional pip installations away from ongoing downloads.
        # If a challenge actually requires the optional module, the download
        # worker can explicitly request setup through wait_for_impersonation_setup.
        while True:
            with LOCK:
                busy = any(j.get('state') in ('queued', 'running') for j in JOBS.values())
            if not busy:
                break
            time.sleep(2)
        schedule_impersonation_setup()
    threading.Thread(target=post_start_dependency_repair, daemon=True,
                     name='VidDockPostStartRepair').start()
    def restart_monitor():
        import time
        while True:
            time.sleep(1)
            with LOCK:
                idle = not any(j.get('state') in ('queued','running') for j in JOBS.values())
                if not updater.ACTIVE and idle and should_shutdown_for_restart():
                    server.shutdown(); return
    threading.Thread(target=restart_monitor, daemon=True).start()
    status_log(f'Listening on http://{HOST}:{PORT} (localhost only)')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        status_log('停止します。')
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
