'use strict';
const $ = id => document.getElementById(id);
const installedVersion = chrome.runtime.getManifest().version;
document.querySelector('.version-tag').textContent = 'v' + installedVersion;
const HELPER = 'http://127.0.0.1:18763';
const HELPER_HISTORY = 'watari_helper_jobs_v1';
const BROWSER_HISTORY = 'watari_download_history_v1';
const view = { tab:null, items:[], poster:'', drm:false, blob:false, token:'', folder:'VidDock',
  history:{}, helperHistory:{}, loading:false, helperReady:false, inflight:false, lastItemKey:'' };

function el(tag, cls='', content='') {
  const node = document.createElement(tag); node.className = cls; node.textContent = content; return node;
}
function button(text, cls, action) {
  const node=el('button',cls,text); node.type='button'; node.addEventListener('click',action); return node;
}
function notice(text, kind='') {
  const node=$('notice'); node.hidden=!text; node.textContent=text; node.className='notice'+(kind?' '+kind:'');
}
function host(u) { try { return new URL(u).hostname; } catch { return ''; } }
function source(u) { try { const v=new URL(u);return v.hostname+' '+v.pathname.slice(0,65); } catch {return u;} }
function thumbnail(url, title, tag) {
  const box=el('div','thumbnail'); const fallback=el('span','placeholder','▶'); box.append(fallback);
  if (url && /^https?:\/\//i.test(url)) {
    const img=document.createElement('img');img.alt=title;img.loading='lazy';img.referrerPolicy='no-referrer';
    img.onload=()=>{fallback.hidden=true;};img.onerror=()=>img.remove();img.src=url;box.append(img);
  }
  box.append(el('span','thumb-mark',tag));return box;
}
function youtubeId(url) {
  try {
    const u=new URL(url);
    const id=/(^|\.)(youtube\.com|youtube-nocookie\.com)$/.test(u.hostname) ?
      (u.pathname==='/watch' ? u.searchParams.get('v') : /^\/(shorts|embed|live)\//.test(u.pathname)?u.pathname.split('/')[2]:'') :
      ['youtu.be','www.youtu.be'].includes(u.hostname) ? u.pathname.split('/')[1] : '';
    return /^[A-Za-z0-9_-]{11}$/.test(id||'')?id:null;
  } catch {return null;}
}
function isTokyo(url) { try { const u=new URL(url);return /^(www\.)?tokyomotion\.net$/.test(u.hostname)&&/^\/video\/\d+\//.test(u.pathname); } catch {return false;} }
function browserKey(type,url) {
  try {const u=new URL(url);u.hash='';if(/\.(mp4|mkv|mov|webm|m3u8|m3u)$/i.test(u.pathname))u.search='';
    else ['token','expires','expire','signature','sig','auth','hdntl','hdnts'].forEach(k=>u.searchParams.delete(k));
    return type+':'+u.href;
  } catch{return type+':'+url;}
}
function stale(info) {
  return info && ((info.state==='preparing' && Date.now()-(info.updatedAt||0)>20*60*1000) ||
    (info.state==='running' && Date.now()-(info.updatedAt||0)>12*60*60*1000));
}
function stateName(info) {
  if (!info)return '';
  if(stale(info))return '前の処理が中断されました（再試行可能）';
  if (info.state==='done')return '✓ 保存済み';
  if (info.state==='preparing')return '準備中...';
  if (info.state==='interrupted')return '保存中断（再試行できます）';
  if (info.state==='queued')return info.queuePosition?`待機中（${info.queuePosition}番目）`:'待機中';
  if (info.state==='running')return `${transferLabel(info)} ${Math.round(transferPercent(info))}%`;
  return info.state==='failed'?'保存失敗':'';
}
function helperKey(site,url){return site+':'+url;}
function completedMp4(info){return info?.state==='done' && /\.mp4$/i.test(info.path||'');}
function canBlock(info){return info&&!stale(info)&&['running','queued','preparing'].includes(info.state) || completedMp4(info);}
function currentStatus(){
  const url=view.tab?.url||''; const id=youtubeId(url);
  if(id)return view.helperHistory[helperKey('youtube','https://www.youtube.com/watch?v='+id)]||null;
  if(isTokyo(url))return view.helperHistory[helperKey('tokyomotion',new URL(url).origin+new URL(url).pathname)]||null;
  const playing=view.items.find(v=>v.playing)||view.items[0];
  if(!playing)return null;
  return view.helperHistory[helperKey('media',playing.url)]||view.history[browserKey('direct',playing.url)]||null;
}
// One stable row per transfer, independent from the currently selected tab.
const activeDownloadStates = new Set(['preparing','queued','running']);
const transferRows = new Map();
function transferState(info){
  if(info.connectionLost && activeDownloadStates.has(info.state))return 'reconnecting';
  if(info.state==='done')return 'done';
  if(info.state==='failed'||info.state==='interrupted')return info.state;
  if(info.state==='queued'||info.state==='preparing')return 'queued';
  if(info.phase==='waiting_conversion')return 'waiting_conversion';
  if(info.phase==='converting')return 'converting';
  if(/変換|最適化|結合|Merger|VideoRemuxer/i.test(info.message||''))return 'converting';
  return 'running';
}
function transferLabel(info){
  return ({done:'保存完了',failed:'保存失敗',interrupted:'中断',queued:'待機中',waiting_conversion:'変換待ち',converting:'変換・結合中',running:'保存中',reconnecting:'再接続中'})[transferState(info)];
}
function transferPercent(info){
  if(info.state==='done')return 100;
  const value=Number(info.percent);
  return Number.isFinite(value)?Math.max(0,Math.min(99,value)):0;
}
function transferEntries(){
  const all=[];
  for(const [engine,history] of [['helper',view.helperHistory],['browser',view.history]]){
    for(const [key,info] of Object.entries(history)){
      if(!info||!['preparing','queued','running','done','failed','interrupted'].includes(info.state))continue;
      all.push({engine,key,info,id:engine+':'+(info.jobId||info.downloadId||key)});
    }
  }
  // Refreshed signed URLs can refer to the same helper job. Render it once.
  const unique=new Map();
  for(const entry of all){const old=unique.get(entry.id);if(!old||(entry.info.updatedAt||0)>(old.info.updatedAt||0))unique.set(entry.id,entry);}
  // Updating progress must not continuously reorder all the cards.
  return [...unique.values()].sort((a,b)=>(a.info.createdAt||a.info.startedAt||0)-(b.info.createdAt||b.info.startedAt||0)||a.id.localeCompare(b.id));
}
function bytesLabel(value){
  if(!Number.isFinite(value)||value<0)return '';
  if(value>=1073741824)return (value/1073741824).toFixed(2)+' GB';
  if(value>=1048576)return (value/1048576).toFixed(1)+' MB';
  return Math.round(value/1024)+' KB';
}
function downloadRow(entry){
  let row=transferRows.get(entry.id);
  if(!row){
    const node=el('article','transfer-card');node.dataset.transferId=entry.id;
    const head=el('div','transfer-head'),art=el('div','transfer-art','▶');
    const name=el('div','transfer-name'),title=el('strong','transfer-title'),origin=el('span','transfer-origin');
    name.append(title,origin);head.append(art,name);
    const statusLine=el('div','transfer-status-line'),state=el('strong','transfer-state'),pct=el('span','transfer-percent');
    statusLine.append(state,pct);
    const bar=el('div','bar transfer-bar'),fill=el('div','transfer-fill');bar.append(fill);
    bar.setAttribute('role','progressbar');bar.setAttribute('aria-valuemin','0');bar.setAttribute('aria-valuemax','100');
    const detail=el('p','transfer-detail');
    node.append(head,statusLine,bar,detail);
    row={node,art,title,origin,state,pct,bar,fill,detail,imageUrl:''};transferRows.set(entry.id,row);
  }
  const {info}=entry,state=transferState(info),percent=transferPercent(info);
  row.node.dataset.state=state;row.title.textContent=info.title||'動画';row.title.title=info.title||'動画';
  row.origin.textContent=host(info.pageUrl||info.url||'')||(entry.engine==='helper'?'補助ツール':'Chrome');
  row.state.textContent=state==='queued'&&info.queuePosition?`待機中（${info.queuePosition}番目）`:transferLabel(info);
  row.pct.textContent=state==='queued'?'—':['converting','waiting_conversion'].includes(state)?'最終処理':`${Math.round(percent)}%`;
  row.bar.setAttribute('aria-label',(info.title||'動画')+' '+transferLabel(info));
  row.bar.setAttribute('aria-valuenow',String(Math.round(percent)));
  row.fill.style.width=percent+'%';
  row.bar.classList.toggle('indeterminate',state==='converting'||state==='waiting_conversion'||state==='queued'||state==='reconnecting');
  const bytes=Number(info.totalBytes)>0?`${bytesLabel(Number(info.bytesReceived)||0)} / ${bytesLabel(Number(info.totalBytes))}`:'';
  const speed=Number.isFinite(info.speedBytes)&&info.speedBytes>0?bytesLabel(info.speedBytes)+'/s':'';
  const eta=Number.isFinite(info.etaSeconds)&&info.etaSeconds>=0?'残り約'+(info.etaSeconds<60?Math.ceil(info.etaSeconds)+'秒':Math.ceil(info.etaSeconds/60)+'分'):'';
  const metrics=state==='running'?[speed,eta,bytes].filter(Boolean).join(' · '):'';
  row.detail.textContent=info.connectionLost?'接続を確認しています。保存結果はまだ確定していません。':state==='done'?'MP4を保存しました':(metrics||info.message||'取得を開始しています…');
  row.detail.title=info.message||'';
  if(info.thumbnail && row.imageUrl!==info.thumbnail && /^https?:\/\//i.test(info.thumbnail)){
    row.imageUrl=info.thumbnail;row.art.textContent='▶';
    const img=document.createElement('img');img.alt='';img.loading='lazy';img.referrerPolicy='no-referrer';
    img.onload=()=>row.art.classList.add('has-image');img.onerror=()=>{img.remove();row.art.classList.remove('has-image');};
    img.src=info.thumbnail;row.art.append(img);
  }
  return row.node;
}
function arrangeRows(parent,entries){
  const wanted=new Set(entries.map(e=>e.id));
  for(const child of [...parent.children])if(!wanted.has(child.dataset.transferId))child.remove();
  entries.forEach((entry,index)=>{
    const node=downloadRow(entry);
    if(parent.children[index]!==node)parent.insertBefore(node,parent.children[index]||null);
  });
}
function renderTransfers(){
  const entries=transferEntries();
  const active=entries.filter(e=>activeDownloadStates.has(e.info.state));
  const recent=entries.filter(e=>!activeDownloadStates.has(e.info.state)).sort((a,b)=>(b.info.updatedAt||0)-(a.info.updatedAt||0)).slice(0,40);
  $('globalStatus').hidden=!entries.length;
  const converting=active.filter(e=>transferState(e.info)==='converting').length;
  const waiting=active.filter(e=>e.info.state==='queued').length;
  const running=active.length-waiting;
  $('globalStatusText').textContent=active.length?`保存中 ${running}/3件 · 待機 ${waiting}件`:'ダウンロード';
  $('globalStatusSub').textContent=active.length?(converting?`うち ${converting}件が変換・結合中 · タブを移動しても確認できます`:'同時3本まで・待機分は空き次第自動開始'):'進行中の保存はありません';
  $('activeCount').textContent=String(active.length);
  $('transferEmpty').hidden=active.length>0;
  arrangeRows($('activeDownloads'),active);
  $('recentDownloads').hidden=!recent.length;
  const completed=recent.filter(e=>e.info.state==='done').length;
  const failed=recent.length-completed;
  $('recentSummary').textContent=`最近の結果 · 完了 ${completed}件${failed?` / 失敗・中断 ${failed}件`:''}`;
  arrangeRows($('recentDownloadList'),recent);
  const retained=new Set([...active,...recent].map(e=>e.id));
  for(const [id] of transferRows)if(!retained.has(id))transferRows.delete(id);
}
function showStatus(){
  renderTransfers();
  const status=currentStatus(),best=$('bestDownload');
  if(canBlock(status)){
    best.textContent=status.state==='done'?'✓ 保存済み（重複防止中）':`${transferLabel(status)} ${Math.round(transferPercent(status))}%`;
    best.disabled=true;
  }else{best.textContent='↓ 最高画質で保存';best.disabled=view.inflight;}
  for(const node of document.querySelectorAll('[data-status-key]')){
    const info=(node.dataset.statusEngine==='helper'?view.helperHistory:view.history)[node.dataset.statusKey];
    node.textContent=canBlock(info)?stateName(info):(node.dataset.idleLabel||'MP4で保存');
    if(node.tagName==='BUTTON')node.disabled=!!canBlock(info);
  }
}
function resumeHelperPolling(){
  for(const [key,info] of Object.entries(view.helperHistory)){
    if(info?.jobId && activeDownloadStates.has(info.state))void pollHelper(key);
  }
}

async function fetchHistory(){
  const data=await chrome.storage.local.get([HELPER_HISTORY,BROWSER_HISTORY]);
  view.history=data[BROWSER_HISTORY]||{};view.helperHistory=data[HELPER_HISTORY]||{};showStatus();resumeHelperPolling();
}
async function send(type, data={}){
  const reply=await chrome.runtime.sendMessage({type,...data});
  if(!reply?.ok){const error=Error(reply?.error||'処理に失敗しました。');error.code=reply?.code;throw error;}return reply;
}
async function helper(path, method='GET', data){
  const result = await send('HELPER_REQUEST',{path,method,...(data?{data}:{})});
  return result.value;
}
async function saveHelperInfo(key,patch,expectedJobId){
  const response=await send('PATCH_HELPER_HISTORY',{key,patch,expectedJobId});
  if(response.record)view.helperHistory[key]=response.record;
  showStatus();return response.record;
}
async function syncHelper(){
  // Native Messaging provides the local pairing token, never a website.
  const result=await helper('/api/status');
  if(!/^1\.(?:[5-9]|[1-9][0-9])\.\d+$/.test(result.version||''))throw Error(`旧補助ツール（${result.version||'不明'}）です。VidDockSetup.cmdを実行してください。`);
  if(!result.ytdlp)throw Error('yt-dlpが見つかりません。コマンド py -3 -m pip install -U "yt-dlp[default]" を実行してください。');
  if(!result.ffmpeg)throw Error('FFmpegが見つかりません。VidDockSetup.cmdを再実行して必要なツールを修復してください。');
  const saved=await helper('/api/settings');
  view.folder=saved.folder; $('saveFolder').value=saved.folder;
  $('fragmentConcurrency').value=String(saved.fragmentConcurrency||4);
  $('currentFolder').textContent='Downloads / '+saved.folder;
  await send('SET_SETTINGS',{folder:saved.folder});
  view.helperReady=true;
  const impersonationText=result.impersonation?'curl_cffi OK':
    result.impersonationInstalling?'curl_cffi導入中（Cloudflare対応を準備中）':
    'curl_cffi未導入（VidDockSetup.cmdで修復）';
  $('helperStatus').textContent=`接続OK · v${result.version} · yt-dlp ${result.ytdlpVersion||'利用可'} · FFmpeg OK · ${impersonationText}`;
  $('helperStatus').className='helper-status connected';return true;
}
async function checkHelper(){
  view.helperReady=false;
  $('helperStatus').textContent='接続確認中...';
  try {return await syncHelper();}
  catch(e){view.helperReady=false;$('helperStatus').textContent=e.message;$('helperStatus').className='helper-status error';return false;}
}
async function runHelper(site,url,quality='best',mediaUrl='',snapshot=null){
  const page=snapshot||{tab:{...view.tab},items:view.items.slice(),poster:view.poster};
  const canonical=site==='youtube'?'https://www.youtube.com/watch?v='+youtubeId(url):site==='tokyomotion'?'https://www.tokyomotion.net'+new URL(url).pathname:mediaUrl;
  const key=helperKey(site,canonical);
  view.inflight=true;showStatus();
  try{
    if(!await checkHelper())throw Error($('helperStatus').textContent);
    const item=page.items.find(item=>item.url===mediaUrl);
    const requestContext=item?.requestContext||{};
    const result=await helper('/api/download','POST',{site,url,quality,mediaUrl,requestContext});
    const old=view.helperHistory[key];
    if(!result.duplicate||old?.jobId!==result.jobId){
      await saveHelperInfo(key,{jobId:result.jobId,title:page.tab?.title||item?.label||'動画',url,pageUrl:page.tab?.url||url,thumbnail:item?.thumbnail||page.poster||'',path:result.path||'',state:result.state||'running',queuePosition:result.queuePosition||0,percent:result.state==='done'?100:0,connectionLost:false,message:result.message||(result.duplicate?'同じ動画は二重保存しません。':'動画を取得しています…')});
    }
    notice(result.duplicate?'同じ動画は二重に保存しません。':'保存一覧に追加しました。','success');
    void pollHelper(key);
  }catch(e){notice(e.message,'error');$('helperSettings').open=true;}
  finally{view.inflight=false;showStatus();}
}
const polling=new Map();
async function pollHelper(key){
  const jobId=view.helperHistory[key]?.jobId;
  if(!jobId||polling.get(key)===jobId)return;
  polling.set(key,jobId);let failures=0;
  try{
    while(view.helperHistory[key]?.jobId===jobId){
      const prior=view.helperHistory[key];
      if(TERMINAL_UI_STATES.has(prior.state)&&!prior.connectionLost)return;
      let result;
      try{result=await helper('/api/job/'+encodeURIComponent(jobId));failures=0;}
      catch(e){
        if(view.helperHistory[key]?.jobId!==jobId)return;
        if(e.code==='JOB_UNKNOWN'||/ジョブ(の記録がありません|が見つかりません)/.test(e.message||'')){
          await saveHelperInfo(key,{state:'interrupted',connectionLost:false,message:'補助ツールにジョブの記録がありません。保存先を確認して再試行してください。'},jobId);return;
        }
        failures++;
        await saveHelperInfo(key,{connectionLost:true,message:'接続を確認しています。ダウンロードの完了・失敗はまだ未確認です。'},jobId);
        await new Promise(r=>setTimeout(r,failures<3?2000:8000));continue;
      }
      if(view.helperHistory[key]?.jobId!==jobId)return;
      await saveHelperInfo(key,{state:result.state,phase:result.phase||'',queuePosition:result.queuePosition||0,speedBytes:result.speedBytes??null,etaSeconds:result.etaSeconds??null,bytesReceived:result.bytesReceived||0,totalBytes:result.totalBytes||0,totalEstimated:!!result.totalEstimated,percent:result.percent||0,path:result.path||'',message:result.message||'',connectionLost:false},jobId);
      if(TERMINAL_UI_STATES.has(result.state))return;
      await new Promise(r=>setTimeout(r,1400));
    }
  }catch(e){console.warn('Download status update failed:',e.message);}
  finally{if(polling.get(key)===jobId)polling.delete(key);}
}
const TERMINAL_UI_STATES=new Set(['done','failed','interrupted']);

async function runMedia(item){
  // TokyoMotion often rejects extension-origin range probes with HTTP 403.
  // Use the native helper with the original video-page Referer for all media
  // candidates, including MP4. This is not a DRM or permission bypass.
  if(isTokyo(view.tab?.url||'')){
    if(!['mp4','webm','hls','mov','mkv'].includes(item.type)){
      notice('未対応の動画形式です。','error');return;
    }
    return runHelper('tokyomotion',view.tab.url,'best',item.url);
  }
  if(item.type==='mp4')return runBrowser(item);
  if(!['hls','webm','mov','mkv'].includes(item.type)){notice('この動画形式は未対応です','error');return;}
  if(!view.tab?.url?.startsWith('https://')){notice('MP4変換にはHTTPSページが必要です。','error');return;}
  return runHelper('media',view.tab.url,'best',item.url);
}
async function runBrowser(item){
  // Direct MP4 joins the same native queue; a browser path cannot bypass the cap.
  const page={tab:{...view.tab},items:view.items.slice(),poster:view.poster};
  if(!item.url.startsWith('https://')||!page.tab?.url?.startsWith('https://')){
    notice('この待機列はHTTPS動画に対応しています。HTTPSの再生ページで再検出してください。','error');return;
  }
  return runHelper('media',page.tab.url,'best',item.url,page);
}
function selectBest(items){
  const usable=items.filter(x=>['mp4','webm','hls','mov','mkv'].includes(x.type));
  return usable.sort((a,b)=>{
    const score=x=> (x.playing?100000000:0)+(x.height||0)*2000+(x.width||0)+
      (x.type==='hls'?200:x.type==='mp4'?150:x.type==='webm'?110:0);
    return score(b)-score(a);
  })[0]||null;
}
async function bestDownload(){
  if(!view.tab||view.inflight)return;
  if(youtubeId(view.tab.url))return runHelper('youtube','https://www.youtube.com/watch?v='+youtubeId(view.tab.url));
  if(isTokyo(view.tab.url)){
    const item=selectBest(view.items);return runHelper('tokyomotion',view.tab.url,'best',item?.url||'');
  }
  const item=selectBest(view.items);
  if(!item){notice('動画が見つかりません。再生後に再検出してください。','error');return;}
  await runMedia(item);
}
function renderCard(item,index){
  const key=browserKey(item.type==='hls'?'hls':'direct',item.url);
  const tokyo=isTokyo(view.tab?.url||'');
  const siteKey=tokyo?'https://www.tokyomotion.net'+new URL(view.tab.url).pathname:'';
  const info=tokyo?view.helperHistory[helperKey('tokyomotion',siteKey)]:
    view.helperHistory[helperKey('media',item.url)]||(item.type==='mp4'?view.history[key]:null);
  const card=el('article','media-card');
  card.append(thumbnail(item.thumbnail||view.poster,item.label||'動画',item.height?item.height+'p':item.type.toUpperCase()));
  const title=el('div','media-title');title.append(el('strong','',item.label||`動画候補 ${index+1}`));
  title.append(el('span','format '+(item.type==='hls'?'hls':''),item.type.toUpperCase()));card.append(title);
  card.append(el('div','source',source(item.url)));
  const tags=el('div','tags');if(item.playing)tags.append(el('span','playing','● 再生中'));
  if(item.height)tags.append(el('span','',item.height+'p'));if(info)tags.append(el('span','',stateName(info)));card.append(tags);
  const actions=el('div','card-actions');actions.append(el('small','',item.type==='dash'?'DASHは未対応':item.type==='hls'?'HLS · 自動で最高画質':'直接動画'));
  const saving=canBlock(info);
  const b=button(item.type==='dash'?'未対応':saving?stateName(info):'MP4で保存','primary',()=>void runMedia(item));
  if(item.type!=='dash'){b.dataset.statusKey=tokyo?helperKey('tokyomotion',siteKey):helperKey('media',item.url);b.dataset.statusEngine='helper';b.dataset.idleLabel='MP4で保存';}
  b.disabled=item.type==='dash'||!!saving;actions.append(b);card.append(actions);return card;
}
function showSiteCard(site, url, qualityOptions){
  const container=$(site==='youtube'?'youtubeArea':'tokyoArea');container.replaceChildren();container.hidden=false;
  const card=el('article','youtube-card');const id=youtubeId(url);
  card.append(thumbnail(view.poster||(id?'https://i.ytimg.com/vi/'+id+'/hqdefault.jpg':''),view.tab.title,site==='youtube'?'YOUTUBE':'SITE'));
  card.append(el('div','youtube-heading',view.tab.title||'動画'));
  card.append(el('div','source',site==='youtube'?'YouTube · 非DRM':'TokyoMotion · 非DRMのストリーム'));
  const select=document.createElement('select');select.setAttribute('aria-label',site==='youtube'?'画質選択':'取得先');
  if(site==='youtube'){
    [['best','最高画質'],['1080','1080p以下'],['720','720p以下'],['480','480p以下'],['360','360p以下']].forEach(([v,label])=>{
      const o=document.createElement('option');o.value=v;o.textContent=label;select.append(o);
    });
  }else{
    const o=document.createElement('option');o.value='';o.textContent='ページから解析';select.append(o);
    qualityOptions.slice(0,25).forEach((it,i)=>{const opt=document.createElement('option');opt.value=it.url;
      opt.textContent=`${it.type.toUpperCase()} ${it.height||''}p · 候補 ${i+1}`;select.append(opt);});
    if(qualityOptions.length)select.selectedIndex=1;
  }
  const controls=el('div','youtube-controls');controls.append(select);card.append(controls);
  const actions=el('div','card-actions');actions.append(el('small','',site==='youtube'?'yt-dlp + FFmpeg':'候補の検出後に保存'));
  const key=helperKey(site,site==='youtube'?'https://www.youtube.com/watch?v='+id:'https://www.tokyomotion.net'+new URL(url).pathname);
  const info=view.helperHistory[key];const blocked=canBlock(info);
  const b=button(blocked?stateName(info):'この設定で保存','primary',()=>void runHelper(site,url,site==='youtube'?select.value:'best',site==='tokyomotion'?select.value:''));
  b.dataset.statusKey=key;b.dataset.statusEngine='helper';b.dataset.idleLabel='この設定で保存';
  b.disabled=!!blocked;actions.append(b);card.append(actions);
  if(info){const state=el('div','yt-job');state.append(el('strong','',stateName(info)));
    const bar=el('div','bar');const fill=el('div','job-fill');fill.style.width=(info.percent||0)+'%';bar.append(fill);
    state.append(bar,el('div','job-detail',info.message||''));card.append(state);}
  if(site==='tokyomotion')card.append(el('div','helper-warning','動画を再生後に「再検出」してください。サイトの配信制限によっては保存できない場合があります。'));
  container.append(card);
}
function render(){
  const page=view.tab||{};const id=youtubeId(page.url||'');
  $('youtubeArea').hidden=!id;$('tokyoArea').hidden=!isTokyo(page.url||'');
  if(id)showSiteCard('youtube',page.url,[]);
  else if(isTokyo(page.url||''))showSiteCard('tokyomotion',page.url,view.items.filter(x=>['mp4','webm','hls','dash'].includes(x.type)));
  $('drmArea').hidden=!view.drm;
  $('itemCount').textContent=String(view.items.length);
  $('items').replaceChildren(...view.items.map(renderCard));
  $('empty').hidden=!!view.items.length||!!id||isTokyo(page.url||'');
  $('summary').textContent=`${view.items.length}件の候補を検出${view.drm?' · DRM検出':''}`;
  showStatus();
}
async function scan(){
  if(view.loading)return;view.loading=true;$('rescan').disabled=true;
  try{
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(!tab?.id)throw Error('動画ページのタブを選択してください。');
    const changed=view.tab?.id!==tab.id||view.tab?.url!==tab.url;
    view.tab=tab;$('pageTitle').textContent=tab.title||'名称のないページ';$('pageDomain').textContent=host(tab.url||'');
    if(changed){view.poster='';view.drm=false;view.blob=false;notice('');}
    try{
      const response=await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},func:scanPageVideos});
      const data=response.map(x=>x.result).filter(Boolean);
      view.drm=data.some(x=>x.hasDRM);view.blob=data.some(x=>x.hasBlobVideo);
      view.poster=data.find(x=>x.pagePoster)?.pagePoster||'';
      const records=data.flatMap(x=>x.records||[]);
      if(records.length)await send('ADD_PAGE_MEDIA',{tabId:tab.id,records});
    }catch{/* protected page */}
    const {items}=await send('GET_MEDIA',{tabId:tab.id});
    view.items=items.sort((a,b)=>Number(b.playing)-Number(a.playing)||b.seenAt-a.seenAt);
    await fetchHistory();render();
  }catch(e){notice(e.message,'error');}
  finally{view.loading=false;$('rescan').disabled=false;}
}
async function saveSettings(){
  try{
    const folder=$('saveFolder').value.trim();
    // Update the authoritative helper first; do not leave settings split on failure.
    await helper('/api/settings','POST',{folder,fragmentConcurrency:Number($('fragmentConcurrency').value)});
    const stored=await send('SET_SETTINGS',{folder});
    view.folder=stored.folder;
    $('saveFolder').value=stored.folder;
    $('currentFolder').textContent='Downloads / '+stored.folder;
    notice('設定を保存しました。分割取得数は次に追加する動画から適用します。','success');
  }catch(e){notice('保存先の変更に失敗しました: '+e.message,'error');}
}

async function pollBrowserProgress(){
  try{await send('REFRESH_BROWSER_TRANSFERS');}catch{/* Retry on next refresh. */}
}
$('rescan').addEventListener('click',()=>void scan());
$('bestDownload').addEventListener('click',()=>void bestDownload());
$('saveFolderButton').addEventListener('click',()=>void saveSettings());
$('saveToken').addEventListener('click',async()=>{
  view.token=$('helperToken').value.trim();await chrome.storage.local.set({helperToken:view.token});await checkHelper();
});
$('checkHelper').addEventListener('click',()=>void checkHelper());
chrome.tabs.onActivated.addListener(()=>void scan());
chrome.tabs.onUpdated.addListener((id,change)=>{if(id===view.tab?.id&&(change.status==='complete'||change.url))void scan();});
chrome.storage.onChanged.addListener((changes,area)=>{
  if(area!=='local')return;
  if(changes[BROWSER_HISTORY])view.history=changes[BROWSER_HISTORY].newValue||{};
  if(changes[HELPER_HISTORY])view.helperHistory=changes[HELPER_HISTORY].newValue||{};
  if(changes[BROWSER_HISTORY]||changes[HELPER_HISTORY]){showStatus();resumeHelperPolling();}
});
(async()=>{
  const data=await chrome.storage.local.get(['helperToken']);
  view.token=data.helperToken||'';$('helperToken').value=view.token;
  const s=await send('GET_SETTINGS');view.folder=s.folder;$('saveFolder').value=s.folder;
  $('currentFolder').textContent='Downloads / '+s.folder;
  void checkHelper();
  await scan();
  resumeHelperPolling();
  void pollBrowserProgress();
  setInterval(()=>void scan(),9000);
  setInterval(()=>void pollBrowserProgress(),1400);
})().catch(e=>notice(e.message,'error'));


// Private GitHub update workflow. All GitHub authentication stays on localhost helper.
let checkedUpdate = null;
let updatePolling = false;
function updateText(value, error = false) {
  const e = $('updateInfo'); e.textContent = value; e.className = 'help' + (error ? ' error' : '');
}
async function checkUpdates() {
  $('checkUpdates').disabled = true;
  $('applyUpdate').hidden = true;
  updateText('更新を確認しています...');
  try {
    const data = await helper('/api/update/check');
    checkedUpdate = data;
    $('updateInstalled').textContent = `v${data.currentVersion}`;
    if (data.available) {
      updateText(`v${data.latestVersion} が利用できます。${data.notes || ''}`);
      $('applyUpdate').hidden = false;
    } else updateText('最新版です。');
  } catch (error) { updateText(error.message, true); }
  finally { $('checkUpdates').disabled = false; }
}
async function applyUpdate() {
  if (!checkedUpdate?.available || updatePolling) return;
  if (!confirm(`v${checkedUpdate.latestVersion}に更新します。保存中の動画がないことを確認してください。`)) return;
  $('applyUpdate').disabled = true; $('checkUpdates').disabled = true;
  $('updateProgress').hidden = false;
  updateText('アップデートを開始しています...');
  try {
    await helper('/api/update/apply', 'POST', {});
    updatePolling = true;
    for (let attempt=0; attempt<100; attempt++) {
      await new Promise(resolve => setTimeout(resolve, 1200));
      let state;
      try { state = await helper('/api/update/status'); }
      catch(e) { if(attempt<95) {updateText('補助ツールの再起動を待っています...');continue;} throw e; }
      if (state.state==='failed') throw new Error(state.message || '更新に失敗しました。');
      $('updateProgressBar').style.width = Math.max(0,Math.min(100,state.percent||0))+'%';
      updateText(state.message || '更新中...');
      if (state.state==='done' && state.version===checkedUpdate.latestVersion) {
        updateText('更新完了。Chrome拡張機能を再読み込みします。');
        setTimeout(()=>chrome.runtime.reload(), 900);
        return;
      }
    }
    throw new Error('更新状況の確認がタイムアウトしました。');
  } catch (error) { updateText(error.message, true); }
  finally {
    updatePolling = false; $('applyUpdate').disabled = false; $('checkUpdates').disabled = false;
  }
}
$('updateInstalled').textContent = 'v' + installedVersion;
$('checkUpdates').addEventListener('click',()=>void checkUpdates());
$('applyUpdate').addEventListener('click',()=>void applyUpdate());

// Automatic checks only; applying always requires user confirmation.
(async()=>{
  const previous=await chrome.storage.local.get('watariLastUpdateCheck');
  if(Date.now()-(previous.watariLastUpdateCheck||0)>6*60*60*1000){
    await chrome.storage.local.set({watariLastUpdateCheck:Date.now()});
    await checkUpdates();
  }
})().catch(()=>{});
